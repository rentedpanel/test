# MemoryLab Pro — Educational FPS Research Laboratory

## 📌 QUICK CONFIGURATION REFERENCE (প্যাকেজ নাম ও অফসেট কনফিগারেশন গাইড)

> [!IMPORTANT]
> **গেম পরিবর্তন করা বা ডাম্প থেকে নতুন অফসেট বসানোর জন্য শুধুমাত্র নিচের নির্দিষ্ট ফাইলগুলো ব্যবহার করবেন:**
>
> 1. **গেমের প্যাকেজ নাম বসানোর লোকেশন:**  
>    📂 **ফাইলের নাম:** [`GameConfig.kt`](file:///c:/Users/Sajala/Downloads/test%20(1)/app/src/main/java/com/memorylab/mods/config/GameConfig.kt)  
>    📍 **পাথ:** `app/src/main/java/com/memorylab/mods/config/GameConfig.kt`  
>    📝 **লাইন ৩০:** `const val TARGET_PACKAGE_NAME: String = "com.edgemake.firestrike"`  
>    📝 **লাইন ৩৫:** `const val TARGET_GAME_NAME: String = "Fire Strike Retro"`  
>    *(এখানে শুধু প্যাকেজ নাম পরিবর্তন করলেই পুরো অ্যাপ, ব্যাকগ্রাউন্ড সার্ভিস ও ড্যাশবোর্ডে অটো আপডেট হয়ে যাবে)*
>
> 2. **Kotlin / UI অফসেট বসানোর লোকেশন:**  
>    📂 **ফাইলের নাম:** [`Il2cppOffsets.kt`](file:///c:/Users/Sajala/Downloads/test%20(1)/app/src/main/java/com/memorylab/mods/offsets/Il2cppOffsets.kt)  
>    📍 **পাথ:** `app/src/main/java/com/memorylab/mods/offsets/Il2cppOffsets.kt`  
>    📝 **বিবরণ:** ফ্লোটিং মেনু ও স্ক্রিনের জন্য ক্যামেরা, প্লেয়ার, হেলথ ও স্কেলিটন অফসেট এখানে বসাবেন।
>
> 3. **C++17 নেটিভ অফসেট বসানোর লোকেশন:**  
>    📂 **ফাইলের নাম:** [`memory_offsets.h`](file:///c:/Users/Sajala/Downloads/test%20(1)/app/src/main/cpp/memory_offsets.h)  
>    📍 **পাথ:** `app/src/main/cpp/memory_offsets.h`  
>    📝 **বিবরণ:** নেটিভ C++ মেমরি ট্রাভার্সাল ও RVA ক্যালকুলেশনের জন্য স্ট্রাকচার অফসেট এখানে বসাবেন।
>
> 4. **ডাম্প ফাইল থেকে অফসেট খোঁজার গাইড:**  
>    📂 **ফাইলের নাম:** [`offset_reference_guide.txt`](file:///c:/Users/Sajala/Downloads/test%20(1)/offset_reference_guide.txt)  
>    📍 **পাথ:** `offset_reference_guide.txt` (প্রজেক্টের রুট ফোল্ডারে)  
>    📝 **বিবরণ:** `dump.txt` ফাইলে কোন কোন ক্লাস এবং মেথড সার্চ করতে হবে তার সম্পূর্ণ রেফারেন্স লিস্ট।

---

### 🔄 গেম প্যাকেজ নাম পরিবর্তন করার বিস্তারিত গাইড (How to Update Game Package Name)

ভবিষ্যতে যদি আপনারা গেমের প্যাকেজ নাম পরিবর্তন করেন (যেমন: `com.edgemake.firestrike` এর পরিবর্তে `com.mycompany.myfpsgame`), তবে **MemoryLab Pro অ্যাপের আর কোনো ফাইল বা কোড ঘাঁটতে হবে না!** শুধুমাত্র নিচের দুটি উপায়ের যেকোনো একটি ব্যবহার করবেন:

#### পদ্ধতি ১: কোডে স্থায়ীভাবে পরিবর্তন (Permanent Code Update)
1. ওপেন করুন: [`app/src/main/java/com/memorylab/mods/config/GameConfig.kt`](file:///c:/Users/Sajala/Downloads/test%20(1)/app/src/main/java/com/memorylab/mods/config/GameConfig.kt)
2. লাইন ৩০ ও ৩৫-এ আপনার নতুন গেমের নাম ও প্যাকেজ বসিয়ে দিন:
   ```kotlin
   const val TARGET_PACKAGE_NAME: String = "আপনার.নতুন.গেমের.প্যাকেজ"
   const val TARGET_GAME_NAME: String = "আপনার গেমের টাইটেল"
   ```
3. ব্যাস! আর কোনো ফাইলে হাত দিতে হবে না। `SimulationEngine`, `FloatingWindowMenu`, এবং `DashboardScreen` অটোমেটিক্যালি এই প্যাকেজটি ব্যবহার করবে।

#### পদ্ধতি ২: অ্যাপ চালু থাকা অবস্থায় কোড না বদলেই পরিবর্তন (Live Runtime Update)
1. ফোনে MemoryLab Pro অ্যাপটি ওপেন করুন।
2. হোম স্ক্রিনের (Dashboard) **Target Game Profile** কার্ডে একটি টেক্সট ইনপুট বক্স রয়েছে।
3. সেখানে আপনার নতুন গেমের প্যাকেজ নাম লিখে **"Update"** বাটনে ট্যাপ করুন। অ্যাপ রিস্টার্ট বা রিকম্পাইল ছাড়াই সরাসরি কার্যকর হয়ে যাবে!

> [!NOTE]
> **অন্য কোনো ফাইলে প্যাকেজ নাম হার্ডকোড করা নেই:**  
> `AndroidManifest.xml` বা কোনো সার্ভিস ফাইলের ভেতরে কোনো হার্ডকোডেড গেম প্যাকেজ নাম রাখা হয়নি। সমস্ত ব্যাকগ্রাউন্ড সার্ভিস ও ডেটা লিসেনার সেন্ট্রালি `GameConfig.activePackage` থেকে নাম পড়ে নেয়।

---

## 1. Executive Summary

**MemoryLab Pro** is an educational Android FPS research platform and visualization laboratory. It provides real-time 3D world-to-screen projection mathematics, high-performance zero-allocation Android Canvas rendering for ESP research, an interactive synthetic FPS arena powered by `SimulationEngine`, a dual-layer floating overlay system, IL2CPP runtime architecture analysis, and telemetry diagnostics.

The suite is structured as a clean, modular Android application:
* **MemoryLab Pro** (`com.memorylab.mods` in `:app`) — Primary dashboard, 3D projection engine, ESP visualizer, floating overlay service, native C++17 JNI bridge, diagnostics, and performance monitor.

---

## 2. Safety and Ethical Boundaries

MemoryLab Pro is strictly an **educational and research laboratory**.
* **Zero live memory writing or arbitrary process-memory scanning.**
* **Zero code injection or DLL/SO hooking.**
* **Zero third-party game modification or anti-cheat tampering.**
* All entity data and camera matrices are generated synthetically or provided through explicit, validated Android IPC protocols.

---

## 3. Project Architecture

```text
MemoryLab/
├── metadata.json                               # Platform identity and capabilities
├── AGENTS.md                                   # Study guidelines & collaboration principles for AI agents
├── settings.gradle.kts                         # Multi-project Gradle root configuration
├── build.gradle.kts                            # Root plugin definitions
├── README.md                                   # Comprehensive research documentation
├── offset_reference_guide.txt                  # Step-by-step search guide for dump.txt classes
└── app/                                        # Primary Module: MemoryLab Pro
    ├── build.gradle.kts                        # App module build configuration (CMake C++17)
    └── src/
        └── main/
            ├── AndroidManifest.xml             # Manifest, permissions, service definitions
            ├── cpp/                            # C++17 Native Module
            │   ├── CMakeLists.txt              # CMake build script
            │   ├── memory_lab.h / .cpp         # Native laboratory lifecycle
            │   ├── projection_native.h / .cpp  # Native 3D world-to-screen projection
            │   ├── simulation_engine.h / .cpp  # Native synthetic entity generator
            │   └── root_diagnostic.h / .cpp    # Native benign security diagnostic
            ├── java/com/memorylab/mods/
            │   ├── config/                     # Dedicated folder for target game package configuration
            │   │   └── GameConfig.kt           # Central target game package & IPC configuration
            │   ├── offsets/                    # Dedicated folder for reverse-engineering dump offsets
            │   │   └── Il2cppOffsets.kt        # Dump file offsets (methods, player fields, bones)
            │   ├── Vec3.kt, Vec4.kt, Mat4.kt   # 3D vector and matrix math engine
            │   ├── Projection.kt               # World-to-screen perspective projection
            │   ├── ArenaEntity.kt              # Immutable entity snapshot & skeleton model
            │   ├── CameraData.kt               # Camera position, orientation & matrices
            │   ├── NativeMemory.kt             # JNI loader with pure-math fallback
            │   ├── RootDiagnostic.kt           # Benign root and security state checker
            │   ├── OperationLog.kt             # Diagnostic logging system
            │   ├── PerformanceMonitor.kt       # Real-time FPS, latency & memory tracker
            │   ├── SimulationEngine.kt         # Controlled FPS simulation & IPC provider
            │   ├── EspController.kt            # State holder for ESP toggles and sliders
            │   ├── EspRenderer.kt              # Zero-allocation Canvas drawing engine
            │   ├── EspCanvasView.kt            # Hardware-accelerated custom view
            │   ├── FloatingOverlayService.kt   # Foreground service dual-layer overlay
            │   ├── MainActivity.kt             # Scaffold & navigation container
            │   └── ui/
            │       ├── DashboardScreen.kt      # Main telemetry overview & actions
            │       ├── EspLabScreen.kt         # 3D arena canvas & camera controls
            │       ├── OverlayControlsSheet.kt # Unified overlay menu (Sections A & B)
            │       ├── DiagnosticsScreen.kt    # JNI, math & root diagnostics
            │       ├── PerformanceScreen.kt    # Real-time telemetry dashboard
            │       ├── Il2cppResearchScreen.kt # IL2CPP internals educational guide
            │       └── theme/Theme.kt          # Material 3 dark charcoal & cyan theme
            └── res/                            # Drawables, mipmaps, strings, themes
```

---

## 4. 3D Mathematics and Coordinate System

* **World Space**: Right-handed Cartesian coordinate system ($+X$ right, $+Y$ up, $+Z$ forward).
* **View Matrix**: Look-At matrix transforming world coordinates into camera eye space.
* **Projection Matrix**: Perspective frustum matrix with field-of-view $\theta$, aspect ratio $W/H$, near plane $N=0.1$, and far plane $F=500$.
* **Near-Plane Rejection**: Points with clip coordinate $W \le 0.01$ are culled to prevent reverse-projection artifacts.
* **Screen Mapping**:
  $$\text{screenX} = \frac{\text{ndcX} + 1}{2} \times \text{width}$$
  $$\text{screenY} = \frac{1 - \text{ndcY}}{2} \times \text{height} \quad (\text{Y inverted for Android Canvas})$$

---

## 5. Dual-Layer Floating Overlay Design

1. **Interactive Layer**: A draggable, expandable floating button (`WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE`) allowing interactive control of ESP parameters without closing the target activity.
2. **Visual ESP Layer**: A full-screen canvas view with `WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE` ensuring that touch events pass freely to underlying applications.
