package com.memorylab.mods.nativebridge

import com.memorylab.mods.*

/**
 * Single-Process Native Simulation controller helper.
 * Line limit: < 150 lines.
 */
object NativeSimulationEngine {

    private val reusableLiveBuffer = FloatArray(1024)
    private val reusableViewBuffer = FloatArray(16)
    private val reusableProjBuffer = FloatArray(16)

    fun updateStep(deltaSec: Float, targetCount: Int, camYaw: Float, camPitch: Float, camDist: Float, camFov: Float, aspect: Float) {
        if (!NativeMemory.isLoaded()) return
        try {
            NativeMemory.nativeUpdateSimulationStep(deltaSec, targetCount, camYaw, camPitch, camDist, camFov, aspect)
        } catch (_: Throwable) {}
    }

    fun getLiveEntities(cameraPos: Vec3): List<ArenaEntity> {
        if (!NativeMemory.isLoaded()) return emptyList()
        val list = mutableListOf<ArenaEntity>()
        try {
            val count = NativeMemory.nativeGetLiveEntities(reusableLiveBuffer)
            if (count > 0) {
                val stride = 10
                for (i in 0 until count) {
                    val offset = i * stride
                    if (offset + stride > reusableLiveBuffer.size) break

                    val id = reusableLiveBuffer[offset + 0].toInt()
                    val posX = reusableLiveBuffer[offset + 1]
                    val posY = reusableLiveBuffer[offset + 2]
                    val posZ = reusableLiveBuffer[offset + 3]
                    val headY = reusableLiveBuffer[offset + 4]
                    val footY = reusableLiveBuffer[offset + 5]
                    val hp = reusableLiveBuffer[offset + 6]
                    val maxHp = reusableLiveBuffer[offset + 7]
                    val teamInt = reusableLiveBuffer[offset + 8].toInt()
                    val isVis = reusableLiveBuffer[offset + 9] > 0.5f

                    val worldPos = Vec3(posX, posY, posZ)
                    val dist = cameraPos.distanceTo(worldPos)
                    val entity = ArenaEntity(
                        id = id,
                        name = if (teamInt == 0) "ALPHA-${id % 100}" else "BRAVO-${id % 100}",
                        worldPos = worldPos,
                        headPos = Vec3(posX, headY, posZ),
                        footPos = Vec3(posX, footY, posZ),
                        health = hp, maxHealth = maxHp,
                        team = if (teamInt == 0) TeamCategory.ALPHA else TeamCategory.BRAVO,
                        isVisible = isVis, distance = dist
                    )
                    if (entity.isValid()) list.add(entity)
                }
            }
        } catch (_: Throwable) {}
        return list.sortedBy { it.distance }
    }

    fun getCameraMatrices(): Pair<Mat4, Mat4>? {
        if (!NativeMemory.isLoaded()) return null
        return try {
            val ok = NativeMemory.nativeGetCameraMatrices(reusableViewBuffer, reusableProjBuffer)
            if (ok) Pair(Mat4(reusableViewBuffer.clone()), Mat4(reusableProjBuffer.clone())) else null
        } catch (_: Throwable) { null }
    }
}
