package com.memorylab.mods.main

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Navigation screen routes for MemoryLab Pro.
 * Line limit: < 150 lines.
 */
sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    data object Visuals : Screen("visuals", "Visuals", Icons.Default.Visibility)
    data object Engine : Screen("engine", "Engine", Icons.Default.Tune)
    data object Metrics : Screen("metrics", "Metrics", Icons.Default.Speed)
    data object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}
