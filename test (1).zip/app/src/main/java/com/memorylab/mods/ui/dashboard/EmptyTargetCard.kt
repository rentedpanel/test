package com.memorylab.mods.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.*

/**
 * Material Design 3 Card displayed when no target application is selected (`hasGame == false`).
 * Features a prominent "+ Add Game" button in the center.
 */
@Composable
fun EmptyTargetCard(
    onAddGameClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, AccentPurple.copy(alpha = 0.25f), RoundedCornerShape(16.dp)),
        colors   = CardDefaults.cardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier            = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier         = Modifier
                    .size(64.dp)
                    .background(AccentPurple.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector        = Icons.Default.SportsEsports,
                    contentDescription = null,
                    tint               = AccentPurple,
                    modifier           = Modifier.size(34.dp)
                )
            }
            Text(
                text       = "No App Selected",
                fontSize   = 17.sp,
                fontWeight = FontWeight.Bold,
                color      = TextPrimary
            )
            Text(
                text       = "Select any application installed on this device.\nMemoryLab will connect its research engine to that app.",
                fontSize   = 12.sp,
                color      = TextSecondary,
                lineHeight = 16.sp
            )
            Button(
                onClick  = onAddGameClick,
                colors   = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                shape    = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("+ Add Game", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}
