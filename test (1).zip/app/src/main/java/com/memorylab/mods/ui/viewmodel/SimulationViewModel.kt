package com.memorylab.mods.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.memorylab.mods.EspController
import com.memorylab.mods.EspSettings
import com.memorylab.mods.SimulationEngine
import com.memorylab.mods.engine.*
import com.memorylab.mods.service.OverlayController
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Official Android Architecture Component ViewModel for MemoryLab Pro.
 * Provides a clean, lifecycle-aware Unidirectional Data Flow (UDF) layer
 * connecting Jetpack Compose UI screens with the underlying 3D simulation engine.
 */
class SimulationViewModel : ViewModel() {

    // Reactive StateFlow properties exposed to UI
    val sceneSnapshot: StateFlow<ResearchSceneSnapshot> = SimulationEngine.currentSnapshot
    val sessionState: StateFlow<SessionState> = SimulationEngine.sessionState
    val connectionState: StateFlow<ConnectionState> = SimulationEngine.connectionState
    val dataSourceMode: StateFlow<DataSourceMode> = SimulationEngine.dataSourceMode
    val espSettings: StateFlow<EspSettings> = EspController.settings
    val isOverlayServiceRunning: StateFlow<Boolean> = OverlayController.isServiceRunning
    val isOverlayExpanded: StateFlow<Boolean> = OverlayController.isOverlayExpanded

    /**
     * Starts the research simulation session.
     */
    fun startSession() {
        SimulationEngine.startSession()
    }

    /**
     * Pauses the research simulation session.
     */
    fun pauseSession() {
        SimulationEngine.pauseSession()
    }

    /**
     * Stops the research simulation session.
     */
    fun stopSession() {
        SimulationEngine.stopSession()
    }

    /**
     * Changes the active data source mode (Synthetic, IPC Bridge, or Root Memory Reader).
     */
    fun setDataSourceMode(mode: DataSourceMode) {
        SimulationEngine.setDataSourceMode(mode)
    }

    /**
     * Connects to target test process via IPC broadcast.
     */
    fun connectTarget(context: Context) {
        viewModelScope.launch {
            SimulationEngine.connectTarget(context)
        }
    }

    /**
     * Disconnects from target test process.
     */
    fun disconnectTarget() {
        SimulationEngine.disconnectTarget()
    }

    /**
     * Toggles the background floating window overlay service.
     */
    fun toggleOverlayService(context: Context) {
        if (OverlayController.canDrawOverlays(context)) {
            if (isOverlayServiceRunning.value) {
                OverlayController.stopOverlayService(context)
            } else {
                OverlayController.startOverlayService(context)
            }
        }
    }

    /**
     * Updates visual ESP settings in a thread-safe manner (automatically persists to storage).
     */
    fun updateEspSettings(transform: (EspSettings) -> EspSettings) {
        EspController.updateSettings(transform)
    }
}
