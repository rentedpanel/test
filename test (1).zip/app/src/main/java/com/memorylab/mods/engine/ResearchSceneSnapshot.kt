package com.memorylab.mods.engine

import com.memorylab.mods.ArenaEntity
import com.memorylab.mods.CameraData

/**
 * Immutable snapshot of the entire FPS research scene (Entities + Camera).
 * Line limit: < 150 lines.
 */
data class ResearchSceneSnapshot(
    val entities: List<ArenaEntity> = emptyList(),
    val camera: CameraData = CameraData(),
    val timestamp: Long = System.currentTimeMillis(),
    val isExternalSource: Boolean = false
)
