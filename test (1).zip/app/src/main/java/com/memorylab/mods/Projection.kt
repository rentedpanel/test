package com.memorylab.mods

import android.graphics.RectF
import android.opengl.Matrix

/**
 * 2D Projected screen coordinate with depth and validity flags.
 */
data class ScreenPoint(
    val x: Float,
    val y: Float,
    val depth: Float,
    val isValid: Boolean = true
)

/**
 * 3D World-to-Screen Projection Engine for Android Canvas ESP visualization.
 * Leverages standard Android SDK hardware-accelerated android.opengl.Matrix utilities.
 */
object Projection {
    private val localViewProj = ThreadLocal.withInitial { FloatArray(16) }
    private val localInVec = ThreadLocal.withInitial { FloatArray(4) }
    private val localClip = ThreadLocal.withInitial { FloatArray(4) }

    fun worldToScreen(
        worldPos: Vec3,
        viewMatrix: Mat4,
        projMatrix: Mat4,
        screenWidth: Float,
        screenHeight: Float,
        fovScale: Float = 1.0f
    ): ScreenPoint? {
        if (!worldPos.isValid() || screenWidth <= 0f || screenHeight <= 0f) {
            return null
        }

        val viewProj = localViewProj.get()!!
        Matrix.multiplyMM(viewProj, 0, projMatrix.data, 0, viewMatrix.data, 0)

        val inVec = localInVec.get()!!
        inVec[0] = worldPos.x; inVec[1] = worldPos.y; inVec[2] = worldPos.z; inVec[3] = 1.0f

        val clip = localClip.get()!!
        Matrix.multiplyMV(clip, 0, viewProj, 0, inVec, 0)
        val clipW = clip[3]

        // Near-plane clipping & behind-camera rejection
        if (clipW <= 0.01f) {
            return null
        }

        // Normalized Device Coordinates (NDC)
        val ndcX = (clip[0] / clipW) * fovScale
        val ndcY = (clip[1] / clipW) * fovScale

        // Frustum culling margin
        if (ndcX < -3.0f || ndcX > 3.0f || ndcY < -3.0f || ndcY > 3.0f) {
            return null
        }

        // Map NDC [-1, 1] to Android 2D Screen Canvas coordinates
        val screenX = (ndcX + 1.0f) * 0.5f * screenWidth
        val screenY = (1.0f - ndcY) * 0.5f * screenHeight

        if (screenX.isNaN() || screenY.isNaN() || screenX.isInfinite() || screenY.isInfinite()) {
            return null
        }

        // Absolute Coordinate Gating: Reject points that collapse to (0,0) or extreme offscreen bounds
        if (screenX <= 0f && screenY <= 0f) {
            return null
        }
        if (screenX < -screenWidth * 0.5f || screenX > screenWidth * 1.5f ||
            screenY < -screenHeight * 0.5f || screenY > screenHeight * 1.5f) {
            return null
        }

        return ScreenPoint(screenX, screenY, clipW)
    }

    /**
     * Compute 2D bounding rectangle on screen from 3D head and foot points using standard RectF.
     */
    fun calculateScreenBox(
        headScreen: ScreenPoint,
        footScreen: ScreenPoint,
        aspectRatio: Float = 0.55f
    ): ScreenBox? {
        if (!headScreen.isValid || !footScreen.isValid) return null
        if (headScreen.x <= 0f && headScreen.y <= 0f) return null
        if (footScreen.x <= 0f && footScreen.y <= 0f) return null

        val height = footScreen.y - headScreen.y
        if (height <= 2f || height > 4000f || height.isNaN()) return null

        val width = height * aspectRatio
        val left = headScreen.x - width * 0.5f
        val top = headScreen.y
        val right = left + width
        val bottom = footScreen.y

        if (left.isNaN() || top.isNaN() || right.isNaN() || bottom.isNaN()) return null

        // Strict Target-Locked Alignment: Discard box if defaulting near (0,0)
        if (left <= 0f && top <= 0f) return null

        return ScreenBox(
            left = left,
            top = top,
            right = right,
            bottom = bottom,
            width = width,
            height = height,
            depth = headScreen.depth
        )
    }
}

/**
 * Screen bounding box wrapping standard android.graphics.RectF.
 */
data class ScreenBox(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val width: Float,
    val height: Float,
    val depth: Float
) {
    val rectF: RectF get() = RectF(left, top, right, bottom)
    fun centerX(): Float = (left + right) * 0.5f
    fun centerY(): Float = (top + bottom) * 0.5f
}
