package com.memorylab.mods.config

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Represents a single user-installed, launchable application discovered
 * by the Android PackageManager.
 *
 * @param label       Human-readable display name shown in the picker list
 * @param packageName Android package identifier (e.g. "com.example.game")
 * @param icon        Launcher icon Bitmap — null if icon could not be loaded
 */
data class InstalledAppInfo(
    val label: String,
    val packageName: String,
    val icon: Bitmap?
)

/**
 * =========================================================================
 *                    INSTALLED APP PICKER HELPER
 * =========================================================================
 *
 * Provides a coroutine-safe helper to enumerate all launchable applications
 * installed on the device using standard Android PackageManager APIs.
 *
 * Usage:
 *   LaunchedEffect(Unit) {
 *       appList = AppPickerHelper.getInstalledApps(context)
 *   }
 *
 * This function is always executed on the IO dispatcher so it never
 * blocks the Compose main thread even on devices with hundreds of apps.
 */
object AppPickerHelper {

    /**
     * Queries PackageManager for all applications that have a launchable
     * main Activity (i.e. appear in the device launcher).
     *
     * Results are sorted alphabetically by label, case-insensitive.
     * System apps with no launcher are automatically excluded.
     *
     * @param context  Any valid Android context
     * @return         Sorted list of [InstalledAppInfo]
     */
    suspend fun getInstalledApps(context: Context): List<InstalledAppInfo> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager

            // Query for all apps that have a LAUNCHER category main activity
            val mainIntent = android.content.Intent(android.content.Intent.ACTION_MAIN, null)
            mainIntent.addCategory(android.content.Intent.CATEGORY_LAUNCHER)

            val resolveInfoList = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.queryIntentActivities(
                        mainIntent,
                        PackageManager.ResolveInfoFlags.of(0L)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    pm.queryIntentActivities(mainIntent, 0)
                }
            } catch (e: Exception) {
                emptyList()
            }

            resolveInfoList
                .mapNotNull { resolveInfo ->
                    try {
                        val appInfo: ApplicationInfo = resolveInfo.activityInfo.applicationInfo
                        val label = resolveInfo.loadLabel(pm).toString()
                        val pkg   = appInfo.packageName
                        val icon  = safeLoadIcon(resolveInfo.loadIcon(pm))
                        InstalledAppInfo(label = label, packageName = pkg, icon = icon)
                    } catch (_: Exception) {
                        null
                    }
                }
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
        }

    /**
     * Safely converts any Drawable (including AdaptiveIconDrawable on API 26+)
     * to a software-backed Bitmap suitable for use in Compose ImageBitmap.
     */
    fun bitmapFromDrawable(drawable: Drawable?): Bitmap? = safeLoadIcon(drawable)

    fun safeLoadIcon(drawable: Drawable?): Bitmap? {
        if (drawable == null) return null
        return try {
            when {
                drawable is BitmapDrawable && drawable.bitmap != null -> {
                    drawable.bitmap
                }
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                        drawable is AdaptiveIconDrawable -> {
                    val size = 96
                    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bmp)
                    drawable.setBounds(0, 0, size, size)
                    drawable.draw(canvas)
                    bmp
                }
                else -> {
                    val width  = drawable.intrinsicWidth.takeIf  { it > 0 } ?: 96
                    val height = drawable.intrinsicHeight.takeIf { it > 0 } ?: 96
                    val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bmp)
                    drawable.setBounds(0, 0, width, height)
                    drawable.draw(canvas)
                    bmp
                }
            }
        } catch (_: Exception) {
            null
        }
    }
}
