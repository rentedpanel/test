package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

/**
 * Vertical sidebar navigation bar with tabs.
 * Line limit: < 150 lines.
 */
@Composable
fun FloatingSidebar(
    selectedTab: OverlayTab,
    onTabSelect: (OverlayTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(40.dp)
            .fillMaxHeight()
            .background(MockupSidebarBg)
            .padding(vertical = 4.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        OverlayTab.entries.forEach { tab ->
            val isSelected = tab == selectedTab
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) MockupAccentPurple else Color.Transparent)
                    .clickable { onTabSelect(tab) },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector        = tab.icon,
                    contentDescription = tab.title,
                    tint               = if (isSelected) Color.White else Color.White.copy(alpha = 0.45f),
                    modifier           = Modifier.size(16.dp)
                )
            }
        }
    }
}
