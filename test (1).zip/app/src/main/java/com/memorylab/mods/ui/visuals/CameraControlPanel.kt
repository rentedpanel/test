package com.memorylab.mods.ui.visuals

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.SimulationEngine
import com.memorylab.mods.ui.components.AppSleekSlider
import com.memorylab.mods.ui.theme.AccentCyan
import com.memorylab.mods.ui.theme.DarkSurface
import com.memorylab.mods.ui.theme.DarkSurfaceVariant
import com.memorylab.mods.ui.theme.TextSecondary

/**
 * Collapsible Camera Controls Panel.
 * Line limit: < 150 lines.
 */
@Composable
fun CameraControlPanel(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        colors   = CardDefaults.cardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("Camera FOV: ${SimulationEngine.cameraFov.toInt()}°", fontSize = 12.sp, color = TextSecondary)
            AppSleekSlider(
                value              = SimulationEngine.cameraFov,
                onValueChange      = { SimulationEngine.cameraFov = it; SimulationEngine.updateCameraMatrix() },
                valueRange         = 40f..120f,
                activeTrackColor   = AccentCyan,
                inactiveTrackColor = DarkSurfaceVariant,
                thumbColor         = AccentCyan
            )
        }
    }
}
