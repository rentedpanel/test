package com.memorylab.mods

import android.content.Context
import android.content.Intent
import com.memorylab.mods.config.GameConfig
import com.memorylab.mods.engine.*
import com.memorylab.mods.nativebridge.NativeSimulationEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.math.cos
import kotlin.math.sin

/**
 * High-Performance Simulation & Telemetry Engine.
 * Delegates data snapshot logic to modular engine components in com.memorylab.mods.engine.
 * Line limit: < 150 lines.
 */
object SimulationEngine {
    private val scope = CoroutineScope(Dispatchers.Default)
    private var simulationJob: Job? = null

    private val _dataSourceMode = MutableStateFlow(DataSourceMode.SYNTHETIC_SIMULATION)
    val dataSourceMode: StateFlow<DataSourceMode> = _dataSourceMode.asStateFlow()

    var lastExternalPacketTime: Long = 0L
        private set

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _sessionState = MutableStateFlow(SessionState.STOPPED)
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()

    private val _currentSnapshot = MutableStateFlow(ResearchSceneSnapshot())
    val currentSnapshot: StateFlow<ResearchSceneSnapshot> = _currentSnapshot.asStateFlow()

    var cameraYaw: Float = 0f
    var cameraPitch: Float = -5f
    var cameraDistance: Float = 14f
    var cameraFov: Float = 68f
    var entityCountTarget: Int = 8
    var viewportWidth: Float = 1920f
    var viewportHeight: Float = 1080f

    init { updateCameraMatrix() }

    fun startSession() {
        if (_sessionState.value == SessionState.RUNNING) return
        _sessionState.value = SessionState.RUNNING; _connectionState.value = ConnectionState.CONNECTED
        simulationJob?.cancel()
        simulationJob = scope.launch {
            var simTime = 0f
            while (isActive) {
                if (_sessionState.value == SessionState.RUNNING) {
                    simTime += 0.016f
                    when (_dataSourceMode.value) {
                        DataSourceMode.SYNTHETIC_SIMULATION -> {
                            val cam = updateCameraMatrix()
                            val aspect = if (cam.viewportHeight > 0f) cam.viewportWidth / cam.viewportHeight else 0.5625f
                            NativeSimulationEngine.updateStep(0.016f, entityCountTarget, cameraYaw, cameraPitch, cameraDistance, cameraFov, aspect)
                            val nativeEntities = NativeSimulationEngine.getLiveEntities(cam.position)
                            val entities = if (nativeEntities.isNotEmpty()) nativeEntities else SyntheticSceneGenerator.generate(simTime, entityCountTarget, cam.position)
                            val nativeCamMatrices = NativeSimulationEngine.getCameraMatrices()
                            val finalCam = if (nativeCamMatrices != null) cam.copy(viewMatrix = nativeCamMatrices.first, projMatrix = nativeCamMatrices.second) else cam
                            _currentSnapshot.value = ResearchSceneSnapshot(entities = entities, camera = finalCam, timestamp = System.currentTimeMillis())
                            PerformanceMonitor.recordBridgeLatency(0.4f)
                        }
                        DataSourceMode.IPC_DATA_BRIDGE -> {
                            val now = System.currentTimeMillis()
                            if (lastExternalPacketTime > 0L && now - lastExternalPacketTime > 3000L && _connectionState.value == ConnectionState.CONNECTED) {
                                _connectionState.value = ConnectionState.CONNECTING
                            }
                        }
                        DataSourceMode.ROOT_MEMORY_READER -> {
                            val pid = RootExecutor.currentTargetPid; val base = RootExecutor.targetLibBase
                            if (pid <= 0 || base == 0L) {
                                val resolvedPid = RootExecutor.resolveGamePid(GameConfig.activePackage)
                                if (resolvedPid > 0) RootExecutor.resolveModuleBase(resolvedPid, "libil2cpp.so")
                            } else {
                                _connectionState.value = if (NativeRootMemory.nativeProbeProcess(pid, base) == 1) ConnectionState.CONNECTED else ConnectionState.ERROR
                            }
                        }
                    }
                }
                delay(16)
            }
        }
    }

    fun toggleSession() { if (_sessionState.value == SessionState.RUNNING) stopSession() else startSession() }

    fun pauseSession() {
        if (_sessionState.value == SessionState.RUNNING) {
            _sessionState.value = SessionState.PAUSED
        }
    }

    fun setDataSourceMode(mode: DataSourceMode) {
        _dataSourceMode.value = mode
    }

    fun stopSession() {
        _sessionState.value = SessionState.STOPPED; simulationJob?.cancel(); simulationJob = null
        _currentSnapshot.value = ResearchSceneSnapshot(entities = emptyList(), camera = updateCameraMatrix())
    }

    fun connectTarget(context: Context? = null) {
        _connectionState.value = ConnectionState.CONNECTING
        context?.let { ctx -> try { ctx.sendBroadcast(Intent(GameConfig.ACTION_PING_SIMULATION).apply { setPackage(GameConfig.activePackage) }) } catch (_: Throwable) {} }
        scope.launch { delay(400); _connectionState.value = ConnectionState.CONNECTED; if (_sessionState.value == SessionState.STOPPED) startSession() }
    }

    fun disconnectTarget() { _connectionState.value = ConnectionState.DISCONNECTED }

    fun updateCameraMatrix(viewportW: Float = viewportWidth, viewportH: Float = viewportHeight): CameraData {
        this.viewportWidth = viewportW
        this.viewportHeight = viewportH
        val radYaw = Math.toRadians(cameraYaw.toDouble()).toFloat()
        val radPitch = Math.toRadians(cameraPitch.toDouble()).toFloat()
        val eyePos = Vec3(sin(radYaw) * cos(radPitch) * cameraDistance, -sin(radPitch) * cameraDistance + 1.8f, -cos(radYaw) * cos(radPitch) * cameraDistance)
        val targetPos = Vec3(0f, 1.2f, 0f); val up = Vec3(0f, 1f, 0f)
        val aspect = if (viewportH > 0f) viewportW / viewportH else 0.5625f

        return CameraData(
            position = eyePos, target = targetPos, up = up, yawDegrees = cameraYaw, pitchDegrees = cameraPitch,
            fovDegrees = cameraFov, viewMatrix = Mat4.createLookAt(eyePos, targetPos, up),
            projMatrix = Mat4.createPerspective(cameraFov, aspect, 0.1f, 500f), viewportWidth = viewportW, viewportHeight = viewportH
        )
    }

    fun processExternalBroadcast(entityFloats: FloatArray, cameraFloats: FloatArray?, entityCount: Int) {
        lastExternalPacketTime = System.currentTimeMillis()
        if (_dataSourceMode.value != DataSourceMode.IPC_DATA_BRIDGE) _dataSourceMode.value = DataSourceMode.IPC_DATA_BRIDGE
        _connectionState.value = ConnectionState.CONNECTED

        val cam = updateCameraMatrix()
        val parsedList = mutableListOf<ArenaEntity>()
        val stride = if (entityFloats.size >= entityCount * 58) 58 else 10
        val count = if (stride > 0) (entityFloats.size / stride).coerceAtMost(entityCount.coerceAtLeast(1)) else 0

        for (i in 0 until count) {
            val idx = i * stride
            if (idx + 9 >= entityFloats.size) break
            val id = entityFloats[idx].toInt()
            val wx = entityFloats[idx + 1]; val wy = entityFloats[idx + 2]; val wz = entityFloats[idx + 3]
            val headY = entityFloats[idx + 4]; val footY = entityFloats[idx + 5]
            val hp = entityFloats[idx + 6]; val maxHp = entityFloats[idx + 7]
            val teamId = entityFloats[idx + 8].toInt(); val vis = entityFloats[idx + 9] > 0.5f

            val wPos = Vec3(wx, wy, wz); val hPos = Vec3(wx, headY, wz); val fPos = Vec3(wx, footY, wz)
            val dist = cam.position.distanceTo(wPos)
            val entity = ArenaEntity(id = id, name = "Target-$id", worldPos = wPos, headPos = hPos, footPos = fPos, health = hp, maxHealth = maxHp, team = TeamCategory.fromId(teamId), isVisible = vis, distance = dist)
            if (entity.isValid()) parsedList.add(entity)
        }

        _currentSnapshot.value = ResearchSceneSnapshot(entities = parsedList, camera = cam, timestamp = System.currentTimeMillis())
    }
}
