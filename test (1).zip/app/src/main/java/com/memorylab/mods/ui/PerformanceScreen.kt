package com.memorylab.mods.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.memorylab.mods.PerformanceMonitor
import com.memorylab.mods.ui.components.*
import com.memorylab.mods.ui.performance.*
import com.memorylab.mods.ui.theme.*

/**
 * Real-time Performance Telemetry screen.
 * Delegates layout rendering to modular subcomponents in ui.performance.
 * Uses unified AppDesignSystem components. Line count strictly <= 150 lines.
 */
@Composable
fun PerformanceScreen() {
    val metrics by PerformanceMonitor.metrics.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        AppPageHeader(
            title    = "Real-Time Telemetry",
            subtitle = "Performance Monitor"
        )

        Spacer(modifier = Modifier.height(16.dp))

        FpsHeroCard(metrics = metrics)

        Spacer(modifier = Modifier.height(14.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TelemetryCard("Render Duration", "${String.format("%.2f", metrics.frameRenderTimeMs)} ms", "Hardware Canvas", AccentCyan, Modifier.weight(1f))
            TelemetryCard("Bridge Latency", "${String.format("%.2f", metrics.bridgeLatencyMs)} ms", "IPC Loop Rate", AccentPurple, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TelemetryCard("Draw Calls / Frame", "${metrics.drawCalls}", "Zero-allocation batch", HealthGreen, Modifier.weight(1f))
            TelemetryCard("Active Entities", "${metrics.activeEntitiesCount}", "Frustum evaluated", AccentCyan, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(14.dp))

        HeapMemoryCard(metrics = metrics)

        Spacer(modifier = Modifier.height(28.dp))
    }
}

