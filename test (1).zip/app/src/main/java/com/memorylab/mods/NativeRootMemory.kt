package com.memorylab.mods

import android.content.Context
import android.util.Log

/**
 * Native Root Memory JNI Bridge (C++17 / NDK).
 * Line limit: < 150 lines.
 */
object NativeRootMemory {

    private const val TAG = "NativeRootMemory"

    init {
        try {
            System.loadLibrary("memorylab_native")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to load memorylab_native: ${t.message}")
        }
    }

    @JvmStatic external fun nativeInitLogger(logDirPath: String): Boolean

    fun initLogger(context: Context): Boolean {
        return try {
            val path = context.filesDir.absolutePath
            val ok = nativeInitLogger(path)
            if (ok) Log.i(TAG, "Native audit logger initialized at: $path/MemoryLab_Audit.txt")
            ok
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to initialize native logger: ${t.message}")
            false
        }
    }

    @JvmStatic external fun nativeFindProcessPid(packageName: String): Int
    @JvmStatic external fun nativeGetModuleBase(pid: Int, moduleName: String): Long
    @JvmStatic external fun nativeReadMemoryBytes(pid: Int, address: Long, outBuf: ByteArray, size: Int): Boolean
    @JvmStatic external fun nativeReadMemoryFloats(pid: Int, address: Long, outBuf: FloatArray, count: Int): Boolean
    @JvmStatic external fun nativeProbeProcess(pid: Int, libil2cppBase: Long): Int
    @JvmStatic external fun nativeAttachToProcess(packageName: String): Int
    @JvmStatic external fun nativeGetAttachmentStatus(outStatus: IntArray): Boolean
    @JvmStatic external fun nativeGetStatusMessage(): String
    @JvmStatic external fun nativeReadLiveEntities(outBuffer: FloatArray): Int

    fun getStateName(stateOrdinal: Int): String = when (stateOrdinal) {
        -1 -> "ERROR"
        0  -> "DETACHED"
        1  -> "PID_RESOLVED"
        2  -> "BASE_RESOLVED"
        3  -> "DOMAIN_FOUND"
        4  -> "CLASS_RESOLVED"
        5  -> "FULLY_ATTACHED"
        else -> "UNKNOWN ($stateOrdinal)"
    }
}
