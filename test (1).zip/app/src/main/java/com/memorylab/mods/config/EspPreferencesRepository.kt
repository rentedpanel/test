package com.memorylab.mods.config

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.memorylab.mods.EspSettings
import com.memorylab.mods.TracerOrigin

/**
 * Robust Preferences Repository for persisting ESP settings and toggles.
 * Ensures user configurations (Box on/off, HP bar on/off, skeleton, opacity, etc.)
 * are securely saved in Android private storage and restored across app restarts.
 */
class EspPreferencesRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREF_FILE_NAME,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val TAG = "EspPreferencesRepo"
        private const val PREF_FILE_NAME = "memorylab_esp_preferences"

        // Preference Keys
        private const val KEY_ESP_ENABLED = "pref_esp_enabled"
        private const val KEY_SHOW_BOUNDING_BOX = "pref_show_bounding_box"
        private const val KEY_SHOW_HP_BAR = "pref_show_hp_bar"
        private const val KEY_SHOW_DISTANCE = "pref_show_distance"
        private const val KEY_SHOW_TRACER_LINE = "pref_show_tracer_line"
        private const val KEY_HIGHLIGHT_NEAREST = "pref_highlight_nearest"

        private const val KEY_BOX_THICKNESS = "pref_box_thickness"
        private const val KEY_TEXT_SIZE = "pref_text_size"
        private const val KEY_MAX_VISIBLE = "pref_max_visible_entities"
        private const val KEY_TRACER_ORIGIN = "pref_tracer_origin"
        private const val KEY_ESP_OPACITY = "pref_esp_opacity"
        private const val KEY_RENDER_DISTANCE = "pref_render_distance"
        private const val KEY_UPDATE_FREQ = "pref_update_frequency_hz"

        @Volatile
        private var INSTANCE: EspPreferencesRepository? = null

        fun getInstance(context: Context): EspPreferencesRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: EspPreferencesRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    /**
     * Loads the saved EspSettings from SharedPreferences, falling back to default values.
     */
    fun loadSettings(): EspSettings {
        return try {
            val originStr = prefs.getString(KEY_TRACER_ORIGIN, TracerOrigin.TOP.name) ?: TracerOrigin.TOP.name
            val origin = try {
                TracerOrigin.valueOf(originStr)
            } catch (_: Exception) {
                TracerOrigin.TOP
            }

            EspSettings(
                espEnabled = prefs.getBoolean(KEY_ESP_ENABLED, true),
                showBoundingBox = prefs.getBoolean(KEY_SHOW_BOUNDING_BOX, false),
                showHpBar = prefs.getBoolean(KEY_SHOW_HP_BAR, false),
                showDistance = prefs.getBoolean(KEY_SHOW_DISTANCE, false),
                showTracerLine = prefs.getBoolean(KEY_SHOW_TRACER_LINE, false),
                highlightNearest = prefs.getBoolean(KEY_HIGHLIGHT_NEAREST, false),

                boxThickness = prefs.getFloat(KEY_BOX_THICKNESS, 2.5f),
                textSize = prefs.getFloat(KEY_TEXT_SIZE, 12f),
                maxVisibleEntities = prefs.getInt(KEY_MAX_VISIBLE, 10),
                tracerOrigin = origin,
                espOpacity = prefs.getFloat(KEY_ESP_OPACITY, 0.95f),
                renderDistance = prefs.getFloat(KEY_RENDER_DISTANCE, 60f),
                updateFrequencyHz = prefs.getInt(KEY_UPDATE_FREQ, 60)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error loading saved settings, reverting to default: ${e.message}")
            EspSettings()
        }
    }

    /**
     * Persists the given EspSettings asynchronously using SharedPreferences.apply().
     */
    fun saveSettings(settings: EspSettings) {
        try {
            prefs.edit().apply {
                putBoolean(KEY_ESP_ENABLED, settings.espEnabled)
                putBoolean(KEY_SHOW_BOUNDING_BOX, settings.showBoundingBox)
                putBoolean(KEY_SHOW_HP_BAR, settings.showHpBar)
                putBoolean(KEY_SHOW_DISTANCE, settings.showDistance)
                putBoolean(KEY_SHOW_TRACER_LINE, settings.showTracerLine)
                putBoolean(KEY_HIGHLIGHT_NEAREST, settings.highlightNearest)

                putFloat(KEY_BOX_THICKNESS, settings.boxThickness)
                putFloat(KEY_TEXT_SIZE, settings.textSize)
                putInt(KEY_MAX_VISIBLE, settings.maxVisibleEntities)
                putString(KEY_TRACER_ORIGIN, settings.tracerOrigin.name)
                putFloat(KEY_ESP_OPACITY, settings.espOpacity)
                putFloat(KEY_RENDER_DISTANCE, settings.renderDistance)
                putInt(KEY_UPDATE_FREQ, settings.updateFrequencyHz)
                apply()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error persisting settings: ${e.message}")
        }
    }

    /**
     * Clears all saved preferences and reverts to default values.
     */
    fun resetDefaults() {
        prefs.edit().clear().apply()
    }
}
