package com.memorylab.mods.view

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.memorylab.mods.CameraData
import com.memorylab.mods.Projection
import com.memorylab.mods.Vec3

/**
 * Utility to render 3D Ground Arena Grid on Canvas.
 * Line limit: < 150 lines.
 */
object ArenaGridDrawer {
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#22334455")
        strokeWidth = 1.2f
    }

    fun draw(canvas: Canvas, camera: CameraData, w: Float, h: Float): Int {
        var calls = 0
        val gridSize = 20f
        val step = 4f

        var x = -gridSize
        while (x <= gridSize) {
            val p1 = Projection.worldToScreen(Vec3(x, 0f, -gridSize), camera.viewMatrix, camera.projMatrix, w, h)
            val p2 = Projection.worldToScreen(Vec3(x, 0f, gridSize), camera.viewMatrix, camera.projMatrix, w, h)
            if (p1 != null && p2 != null) {
                canvas.drawLine(p1.x, p1.y, p2.x, p2.y, gridPaint)
                calls++
            }
            x += step
        }

        var z = -gridSize
        while (z <= gridSize) {
            val p1 = Projection.worldToScreen(Vec3(-gridSize, 0f, z), camera.viewMatrix, camera.projMatrix, w, h)
            val p2 = Projection.worldToScreen(Vec3(gridSize, 0f, z), camera.viewMatrix, camera.projMatrix, w, h)
            if (p1 != null && p2 != null) {
                canvas.drawLine(p1.x, p1.y, p2.x, p2.y, gridPaint)
                calls++
            }
            z += step
        }
        return calls
    }
}
