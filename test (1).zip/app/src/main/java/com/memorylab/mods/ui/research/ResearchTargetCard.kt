package com.memorylab.mods.ui.research

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.*

/**
 * Active target game card for settings/research screen.
 * Line limit: < 150 lines.
 */
@Composable
fun ResearchTargetCard(
    gameName: String,
    packageName: String,
    isInstalled: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("APPLICATION PROFILE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AccentCyan)
            Spacer(modifier = Modifier.height(6.dp))
            Text(gameName.ifEmpty { "No App Selected" }, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(packageName.ifEmpty { "Select application in dashboard" }, fontSize = 11.sp, color = TextSecondary)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text     = if (isInstalled) "✓ Application Installed" else "⚠ Application Not Found",
                fontSize = 11.sp,
                color    = if (isInstalled) HealthGreen else AccentPurple,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
