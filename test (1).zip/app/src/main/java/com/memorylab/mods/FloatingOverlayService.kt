package com.memorylab.mods

import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.Recomposer
import androidx.compose.ui.platform.AndroidUiDispatcher
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.app.ServiceCompat
import androidx.lifecycle.*
import androidx.savedstate.*
import com.memorylab.mods.service.OverlayController
import com.memorylab.mods.service.OverlayNotificationHelper
import com.memorylab.mods.ui.FloatingWindowMenu
import com.memorylab.mods.ui.theme.MemoryLabTheme
import kotlinx.coroutines.*

/**
 * Production-grade Persistent Foreground Service for Floating Overlay.
 * Line limit: < 150 lines.
 */
class FloatingOverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner, ComponentCallbacks2 {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val appViewModelStore = ViewModelStore()
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = appViewModelStore

    private var windowManager: WindowManager? = null
    private var espOverlayView: View? = null
    private var floatingMenuView: View? = null
    private var espParams: WindowManager.LayoutParams? = null
    private var menuLayoutParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        registerComponentCallbacks(this)

        val notification = OverlayNotificationHelper.createNotification(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, OverlayNotificationHelper.NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(OverlayNotificationHelper.NOTIFICATION_ID, notification)
        }
        OverlayController.setServiceState(true)
        setupOverlays()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateOverlayLayouts()
    }

    private fun updateOverlayLayouts() {
        val wm = windowManager ?: return
        
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val screenWidth = dm.widthPixels
        val screenHeight = dm.heightPixels

        espParams?.let { p ->
            p.width = WindowManager.LayoutParams.MATCH_PARENT; p.height = WindowManager.LayoutParams.MATCH_PARENT
            try { espOverlayView?.let { wm.updateViewLayout(it, p) } } catch (_: Exception) {}
        }
        menuLayoutParams?.let { p ->
            p.x = p.x.coerceIn(10, (screenWidth - 100).coerceAtLeast(10))
            p.y = p.y.coerceIn(10, (screenHeight - 100).coerceAtLeast(10))
            try { floatingMenuView?.let { wm.updateViewLayout(it, p) } } catch (_: Exception) {}
        }
    }

    private fun applyCutoutMode(params: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            @Suppress("DEPRECATION")
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun setupOverlays() {
        if (!OverlayController.canDrawOverlays(this)) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

        espParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN, PixelFormat.TRANSLUCENT
        ).also { applyCutoutMode(it) }

        try {
            val canvasView = EspCanvasView(this)
            espOverlayView = canvasView
            wm.addView(canvasView, espParams)
        } catch (_: Exception) {}

        menuLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START; x = 30; y = 120
            applyCutoutMode(this)
        }

        try {
            val composeView = ComposeView(this).apply {
                setViewTreeLifecycleOwner(this@FloatingOverlayService)
                setViewTreeViewModelStoreOwner(this@FloatingOverlayService)
                setViewTreeSavedStateRegistryOwner(this@FloatingOverlayService)
                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
                val recomposer = Recomposer(AndroidUiDispatcher.CurrentThread)
                setParentCompositionContext(recomposer)
                serviceScope.launch(AndroidUiDispatcher.CurrentThread) { recomposer.runRecomposeAndApplyChanges() }
                setContent {
                    MemoryLabTheme {
                        FloatingWindowMenu(
                            initialVisible = true, isExternalWindow = true,
                            onDragDelta = { dx, dy ->
                                menuLayoutParams?.let { params ->
                                    params.x += dx.toInt(); params.y += dy.toInt()
                                    try { wm.updateViewLayout(this@apply, params) } catch (_: Exception) {}
                                }
                            },
                            onClose = { stopSelf() }
                        )
                    }
                }
            }
            floatingMenuView = composeView
            wm.addView(floatingMenuView, menuLayoutParams)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        
        unregisterComponentCallbacks(this)
        serviceScope.cancel()
        espOverlayView?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        floatingMenuView?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        appViewModelStore.clear()
        OverlayController.setServiceState(false)
    }
}
