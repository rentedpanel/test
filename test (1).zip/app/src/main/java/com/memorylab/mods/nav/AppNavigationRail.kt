package com.memorylab.mods.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.main.Screen
import com.memorylab.mods.ui.theme.*

/**
 * Official Material Design 3 Sidebar Navigation Rail.
 * Replaces bottom navigation bar for a professional system desktop/mobile tool UI.
 * Line limit: < 150 lines.
 */
@Composable
fun AppNavigationRail(
    currentScreen: Screen,
    navigationItems: List<Screen>,
    isRootGranted: Boolean,
    onScreenSelect: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationRail(
        modifier       = modifier.fillMaxHeight(),
        containerColor = DarkSurface,
        contentColor   = TextPrimary,
        header         = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier            = Modifier.padding(top = 16.dp, bottom = 16.dp)
            ) {
                Icon(Icons.Default.Memory, contentDescription = "Logo", tint = AccentCyan, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(if (isRootGranted) HealthGreen else Color(0xFFFFA502), androidx.compose.foundation.shape.CircleShape)
                )
            }
        }
    ) {
        Column(
            modifier            = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            navigationItems.forEach { screen ->
                val selected = currentScreen.route == screen.route
                NavigationRailItem(
                    selected = selected,
                    onClick  = { onScreenSelect(screen) },
                    icon     = {
                        BadgedBox(badge = {}) {
                            Icon(screen.icon, contentDescription = screen.title)
                        }
                    },
                    label    = { Text(screen.title, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                    colors   = NavigationRailItemDefaults.colors(
                        selectedIconColor   = AccentCyan,
                        selectedTextColor   = AccentCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                        indicatorColor      = DarkSurfaceVariant
                    )
                )
            }
        }
    }
}

