package com.memorylab.mods.ui.visuals

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ArenaEntity
import com.memorylab.mods.engine.ResearchSceneSnapshot
import com.memorylab.mods.ui.theme.*

/**
 * Entity telemetry list component for Visuals Studio.
 * Line limit: < 150 lines.
 */
@Composable
fun EntityTelemetryList(
    snapshot: ResearchSceneSnapshot,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(snapshot.entities, key = { it.id }) { entity ->
            EntityItemRow(entity = entity)
        }
    }
}

@Composable
fun EntityItemRow(entity: ArenaEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier              = Modifier.fillMaxWidth().padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(entity.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Pos: (${entity.worldPos.x.toInt()}, ${entity.worldPos.y.toInt()}, ${entity.worldPos.z.toInt()})", fontSize = 10.sp, color = TextSecondary)
            }
            Text("HP: ${entity.health.toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = HealthGreen)
        }
    }
}
