package com.memorylab.mods.config

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Secure Target Game Preference Utility.
 * Line limit: < 150 lines.
 */
object GameConfig {
    private const val PREFS_NAME     = "memorylab_game_config_prefs"
    private const val KEY_PACKAGE    = "pref_game_package"
    private const val KEY_NAME       = "pref_game_name"
    private const val KEY_MODULE     = "pref_game_module"
    private const val KEY_CONFIGURED = "pref_is_configured"

    const val DEFAULT_MODULE_NAME: String = "libil2cpp.so"
    const val ACTION_PING_SIMULATION = "com.memorylab.mods.action.PING_SIMULATION"
    const val FALLBACK_ACTION_PING_SIMULATION = "com.memorylab.mods.ACTION_PING_SIMULATION"
    const val ACTION_SIMULATION_DATA = "com.memorylab.mods.action.SIMULATION_DATA"
    const val FALLBACK_ACTION_SIMULATION_DATA = "com.memorylab.mods.ACTION_SIMULATION_DATA"

    private var appContext: Context? = null

    private val _currentPackage    = MutableStateFlow("")
    val currentPackage: StateFlow<String> = _currentPackage.asStateFlow()

    private val _currentGameName   = MutableStateFlow("")
    val currentGameName: StateFlow<String> = _currentGameName.asStateFlow()

    private val _currentModuleName = MutableStateFlow(DEFAULT_MODULE_NAME)
    val currentModuleName: StateFlow<String> = _currentModuleName.asStateFlow()

    private val _isConfigured = MutableStateFlow(false)
    val isConfiguredState: StateFlow<Boolean> = _isConfigured.asStateFlow()

    var activePackage: String
        get() = _currentPackage.value
        set(value) { setTargetPackage(packageName = value) }

    var activeName: String
        get() = _currentGameName.value
        set(value) { setTargetPackage(packageName = _currentPackage.value, gameName = value) }

    var activeModule: String
        get() = _currentModuleName.value
        set(value) { setTargetPackage(packageName = _currentPackage.value, moduleName = value) }

    var hasGame: Boolean
        get() = _isConfigured.value && _currentPackage.value.isNotEmpty()
        set(configured) {
            _isConfigured.value = configured
            appContext?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)?.edit()?.putBoolean(KEY_CONFIGURED, configured)?.apply()
        }

    var isConfigured: Boolean
        get() = hasGame
        set(value) { hasGame = value }

    fun init(context: Context) {
        appContext = context.applicationContext
        loadConfig(context)
    }

    fun loadConfig(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedPkg   = prefs.getString(KEY_PACKAGE, "") ?: ""
        val savedName  = prefs.getString(KEY_NAME, "") ?: ""
        val savedMod   = prefs.getString(KEY_MODULE, DEFAULT_MODULE_NAME) ?: DEFAULT_MODULE_NAME
        val configured = prefs.getBoolean(KEY_CONFIGURED, savedPkg.isNotEmpty())

        _currentPackage.value    = savedPkg
        _currentGameName.value   = savedName
        _currentModuleName.value = savedMod
        _isConfigured.value      = configured && savedPkg.isNotEmpty()
    }

    fun setTargetPackage(
        packageName: String,
        gameName: String = _currentGameName.value,
        moduleName: String = _currentModuleName.value,
        isConfigured: Boolean = true,
        context: Context? = appContext
    ) {
        val trimmedPkg  = packageName.trim()
        val trimmedName = gameName.trim().ifEmpty { trimmedPkg }
        val trimmedMod  = moduleName.trim().ifEmpty { DEFAULT_MODULE_NAME }
        val configured  = isConfigured && trimmedPkg.isNotEmpty()

        _currentPackage.value    = trimmedPkg
        _currentGameName.value   = trimmedName
        _currentModuleName.value = trimmedMod
        _isConfigured.value      = configured

        (context ?: appContext)?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)?.edit()?.apply {
            putString(KEY_PACKAGE, trimmedPkg)
            putString(KEY_NAME, trimmedName)
            putString(KEY_MODULE, trimmedMod)
            putBoolean(KEY_CONFIGURED, configured)
            apply()
        }
    }

    fun clearTarget(context: Context? = appContext) {
        _currentPackage.value    = ""
        _currentGameName.value   = ""
        _currentModuleName.value = DEFAULT_MODULE_NAME
        _isConfigured.value      = false

        (context ?: appContext)?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)?.edit()?.apply {
            remove(KEY_PACKAGE); remove(KEY_NAME); remove(KEY_MODULE); remove(KEY_CONFIGURED); apply()
        }
    }

    fun isGameInstalled(context: Context, packageName: String = _currentPackage.value): Boolean {
        if (packageName.isBlank()) return false
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) { false }
    }

    fun launchGame(context: Context, packageName: String = _currentPackage.value): Boolean {
        if (packageName.isBlank()) return false
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else false
        } catch (_: Throwable) { false }
    }
}
