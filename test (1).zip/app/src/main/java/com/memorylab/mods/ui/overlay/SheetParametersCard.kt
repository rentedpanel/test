package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.CrosshairStyle
import com.memorylab.mods.EspController
import com.memorylab.mods.EspSettings
import com.memorylab.mods.ui.components.AppSleekSlider
import com.memorylab.mods.ui.components.AppStandardCard
import com.memorylab.mods.ui.theme.*

/**
 * Fine adjustment sliders, aim reticle selector, and render parameter card.
 * Line limit: < 150 lines.
 */
@Composable
fun SheetParametersCard(
    modifier: Modifier = Modifier
) {
    val settings by EspController.settings.collectAsState()

    AppStandardCard(modifier = modifier) {
        Text("Center Aim Reticle (Single Selection)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val entries = CrosshairStyle.entries
            val row1 = entries.take(2)
            val row2 = entries.drop(2)

            listOf(row1, row2).forEach { rowStyles ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    rowStyles.forEach { style ->
                        val isSelected = settings.crosshairStyle == style
                        FilterChip(
                            selected = isSelected,
                            onClick  = { EspController.setCrosshairStyle(style) },
                            label    = {
                                Text(
                                    text = style.displayName,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            },
                            colors   = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentCyan,
                                selectedLabelColor     = DarkBackground,
                                containerColor          = DarkSurfaceVariant,
                                labelColor              = TextPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text("Aim Reticle Size: ${settings.crosshairSize.toInt()} px", fontSize = 12.sp, color = TextSecondary)
        AppSleekSlider(
            value              = settings.crosshairSize,
            onValueChange      = { EspController.setCrosshairSize(it) },
            valueRange         = 6f..40f,
            activeTrackColor   = AccentCyan,
            inactiveTrackColor = DarkSurfaceVariant,
            thumbColor         = AccentCyan
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = DarkBorder)

        Text("Max Detection Range: ${settings.maxDistance.toInt()}m", fontSize = 12.sp, color = TextSecondary)
        AppSleekSlider(
            value              = settings.maxDistance,
            onValueChange      = { EspController.setMaxDistance(it) },
            valueRange         = 50f..500f,
            activeTrackColor   = AccentCyan,
            inactiveTrackColor = DarkSurfaceVariant,
            thumbColor         = AccentCyan
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text("Visual Scaling Factor: ${String.format("%.1f", settings.espScale)}x", fontSize = 12.sp, color = TextSecondary)
        AppSleekSlider(
            value              = settings.espScale,
            onValueChange      = { EspController.setEspScale(it) },
            valueRange         = 0.5f..2.0f,
            activeTrackColor   = AccentPurple,
            inactiveTrackColor = DarkSurfaceVariant,
            thumbColor         = AccentPurple
        )
    }
}


