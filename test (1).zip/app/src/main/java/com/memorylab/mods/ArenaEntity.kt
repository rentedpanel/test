package com.memorylab.mods

/**
 * 3D Bone joint structure for skeleton rendering in the research ESP visualizer.
 */
enum class TeamCategory(val id: Int, val displayName: String) {
    ALPHA(0, "Alpha (Red)"),
    BRAVO(1, "Bravo (Blue)"),
    NEUTRAL(2, "Neutral");

    companion object {
        fun fromId(id: Int): TeamCategory = entries.firstOrNull { it.id == id } ?: NEUTRAL
    }
}

/**
 * Immutable entity snapshot representing a simulated target in the 3D FPS research arena.
 */
data class ArenaEntity(
    val id: Int,
    val name: String,
    val worldPos: Vec3,
    val headPos: Vec3,
    val footPos: Vec3,
    val health: Float,
    val maxHealth: Float = 100f,
    val team: TeamCategory = TeamCategory.ALPHA,
    val isVisible: Boolean = true,
    val distance: Float = 0f,
    val animationPhase: Float = 0f,
    val timestamp: Long = System.currentTimeMillis()
) {
    val healthPercent: Float
        get() = (health / maxHealth.coerceAtLeast(1f)).coerceIn(0f, 1f)

    fun isValid(): Boolean {
        return id > 0 &&
               worldPos.isValid() &&
               headPos.isValid() &&
               footPos.isValid() &&
               health >= 0f &&
               maxHealth > 0f &&
               !distance.isNaN()
    }
}
