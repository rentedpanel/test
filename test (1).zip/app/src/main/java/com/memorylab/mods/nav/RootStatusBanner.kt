package com.memorylab.mods.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.*

/**
 * Top Root Status Banner displaying live SU privileges & kernel direct memory status.
 * Line limit: < 150 lines.
 */
@Composable
fun RootStatusBanner(
    isRootGranted: Boolean,
    targetPid: Int?,
    onCheckRoot: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color    = DarkSurfaceVariant,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier              = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector        = Icons.Default.Security,
                    contentDescription = null,
                    tint               = if (isRootGranted) HealthGreen else Color(0xFFFFA502),
                    modifier           = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text       = if (isRootGranted) "ROOT ACCESS GRANTED (SU / process_vm_readv)" else "ROOT REQUIRED FOR DIRECT RAM",
                    fontSize   = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color      = if (isRootGranted) HealthGreen else Color(0xFFFFA502)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (targetPid != null) {
                    AssistChip(
                        onClick = {},
                        label = { Text("PID $targetPid", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.Memory, null, modifier = Modifier.size(12.dp)) },
                        colors = AssistChipDefaults.assistChipColors(labelColor = AccentCyan, leadingIconContentColor = AccentCyan)
                    )
                }

                TextButton(onClick = onCheckRoot, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                    Text("Re-Check SU", fontSize = 10.sp, color = AccentCyan, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
