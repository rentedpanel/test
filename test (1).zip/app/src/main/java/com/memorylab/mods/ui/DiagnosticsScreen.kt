package com.memorylab.mods.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.*
import com.memorylab.mods.engine.*
import com.memorylab.mods.service.OverlayController
import com.memorylab.mods.ui.components.*
import com.memorylab.mods.ui.diagnostics.*
import com.memorylab.mods.ui.theme.*

/**
 * Engine Diagnostics & System Health screen.
 * Delegates layout rendering to modular subcomponents in ui.diagnostics.
 * Uses unified AppDesignSystem components. Line count strictly <= 150 lines.
 */
@Composable
fun DiagnosticsScreen() {
    val context  = LocalContext.current
    val logs by OperationLog.logs.collectAsState()
    val isOverlayRunning by OverlayController.isServiceRunning.collectAsState()
    val hasOverlayPermission = OverlayController.canDrawOverlays(context)

    var selectedLogLevel by remember { mutableStateOf<LogLevel?>(null) }

    val projectionVerification = remember {
        val view = Mat4.createLookAt(Vec3(0f, 0f, -10f), Vec3(0f, 0f, 0f))
        val proj = Mat4.createPerspective(60f, 16f / 9f, 0.1f, 100f)
        val center = Projection.worldToScreen(Vec3(0f, 0f, 0f), view, proj, 1920f, 1080f)
        val behind = Projection.worldToScreen(Vec3(0f, 0f, -20f), view, proj, 1920f, 1080f)
        center != null && behind == null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
    ) {
        AppPageHeader(
            title         = "Engine Health",
            subtitle      = "Diagnostics & Telemetry Logs",
            actionIcon    = Icons.Default.DeleteSweep,
            onActionClick = { OperationLog.clear() }
        )

        Spacer(modifier = Modifier.height(14.dp))

        DiagnosticSummaryCard(
            projectionVerification = projectionVerification,
            hasOverlayPermission   = hasOverlayPermission,
            isOverlayRunning       = isOverlayRunning
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Text("Filter:", fontSize = 11.sp, color = TextSecondary)
            FilterChip(
                selected = selectedLogLevel == null,
                onClick  = { selectedLogLevel = null },
                label    = { Text("ALL", fontSize = 10.sp) }
            )
            LogLevel.entries.forEach { level ->
                FilterChip(
                    selected = selectedLogLevel == level,
                    onClick  = { selectedLogLevel = if (selectedLogLevel == level) null else level },
                    label    = { Text(level.name, fontSize = 10.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LogListSection(logs = logs, selectedLogLevel = selectedLogLevel, modifier = Modifier.weight(1f))
    }
}

