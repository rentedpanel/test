package com.memorylab.mods.ui.dashboard

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.engine.ConnectionState
import com.memorylab.mods.ui.components.InstalledBadge
import com.memorylab.mods.ui.components.PidBadge
import com.memorylab.mods.ui.theme.*

/**
 * Standard Material Design 3 Active Target Card.
 * Uses official framework layout classes with perfectly spaced action buttons.
 */
@Composable
fun ActiveTargetCard(
    gameName: String,
    packageName: String,
    moduleName: String,
    gameIcon: ImageBitmap?,
    isInstalled: Boolean,
    targetPid: Int?,
    connectionState: ConnectionState,
    isOverlayRunning: Boolean,
    onLaunchGame: () -> Unit,
    onToggleFloating: () -> Unit,
    onRefresh: () -> Unit,
    onChangeGame: () -> Unit,
    onRemoveTarget: () -> Unit,
    onToggleIpc: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, AccentCyan.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
        colors   = CardDefaults.cardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Row: App Icon, Name, Package, and Well-Spaced Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // App Icon & Info
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        if (gameIcon != null) {
                            Image(
                                bitmap = gameIcon,
                                contentDescription = gameName,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        } else {
                            Icon(
                                Icons.Default.SportsEsports,
                                contentDescription = null,
                                tint = AccentPurple,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = gameName.ifEmpty { packageName },
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            InstalledBadge(isInstalled = isInstalled)
                        }
                        Text(
                            text = packageName,
                            fontSize = 11.sp,
                            color = AccentCyan,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Action Icon Buttons with generous, non-overlapping spacing
                Row(
                    modifier = Modifier.wrapContentWidth(unbounded = true),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledIconButton(
                        onClick = onRefresh,
                        modifier = Modifier.size(36.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = DarkSurfaceVariant)
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    FilledIconButton(
                        onClick = onChangeGame,
                        modifier = Modifier.size(36.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = AccentPurple.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            Icons.Default.SwapHoriz,
                            contentDescription = "Change Target",
                            tint = AccentPurple,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    FilledIconButton(
                        onClick = onRemoveTarget,
                        modifier = Modifier.size(36.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFFFF5252).copy(alpha = 0.2f))
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Remove Target",
                            tint = Color(0xFFFF5252),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Bottom Row: Standard Material 3 Launch Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onLaunchGame,
                    enabled = isInstalled,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFE17055),
                        contentColor = Color.White,
                        disabledContainerColor = Color(0xFFE17055).copy(alpha = 0.35f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        Icons.Default.SportsEsports,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isInstalled) "Launch Game" else "Not Installed",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }

                Button(
                    onClick = onToggleFloating,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isOverlayRunning) Color(0xFF00E676) else Color(0xFF6C5CE7),
                        contentColor = if (isOverlayRunning) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isOverlayRunning) Icons.Default.CheckCircle else Icons.Default.Bolt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isOverlayRunning) "Injector Active" else "Launch Injector",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
