package com.memorylab.mods

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PerformanceMetrics(
    val fps: Float = 60f,
    val frameRenderTimeMs: Float = 2.4f,
    val bridgeLatencyMs: Float = 1.1f,
    val activeEntitiesCount: Int = 0,
    val drawCalls: Int = 0,
    val heapMemoryUsedMb: Float = 0f,
    val heapMemoryTotalMb: Float = 0f,
    val lastUpdateTimestamp: Long = System.currentTimeMillis()
)

object PerformanceMonitor {

    private val _metrics = MutableStateFlow(PerformanceMetrics())
    val metrics: StateFlow<PerformanceMetrics> = _metrics.asStateFlow()

    private var frameCount = 0
    private var lastFpsTimestamp = System.currentTimeMillis()
    private var lastFrameTimestamp = System.currentTimeMillis()

    fun recordFrame(entityCount: Int, drawCallsCount: Int, renderDurationMs: Float) {
        frameCount++
        val now = System.currentTimeMillis()
        val elapsed = now - lastFpsTimestamp

        if (elapsed >= 500) {
            val calculatedFps = (frameCount * 1000f) / elapsed
            frameCount = 0
            lastFpsTimestamp = now

            val runtime = Runtime.getRuntime()
            val usedMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024f * 1024f)
            val totalMem = runtime.totalMemory() / (1024f * 1024f)

            _metrics.value = PerformanceMetrics(
                fps = calculatedFps,
                frameRenderTimeMs = renderDurationMs,
                bridgeLatencyMs = _metrics.value.bridgeLatencyMs,
                activeEntitiesCount = entityCount,
                drawCalls = drawCallsCount,
                heapMemoryUsedMb = usedMem,
                heapMemoryTotalMb = totalMem,
                lastUpdateTimestamp = now
            )
        }
    }

    fun recordBridgeLatency(latencyMs: Float) {
        _metrics.value = _metrics.value.copy(
            bridgeLatencyMs = latencyMs,
            lastUpdateTimestamp = System.currentTimeMillis()
        )
    }
}
