package com.memorylab.mods.offsets

/**
 * IL2CPP Dump Offsets & Structure Configuration.
 * Line limit: < 150 lines.
 */
object Il2cppOffsets {
    var is64Bit: Boolean = true

    val Camera = CameraOffsets
    val TransformOffsets = com.memorylab.mods.offsets.TransformOffsets
    val HealthOffsets = com.memorylab.mods.offsets.HealthOffsets

    object GameFacadeOffsets {
        const val CURRENT_LOCAL_PLAYER_RVA: Long = 0x07540158L
        const val CURRENT_LOCAL_PLAYER_OFFSET: Long = 0x0753C158L
        const val GET_LOCAL_PLAYER_OR_OBSERVER_RVA: Long = 0x0753DFBCL
        const val GET_LOCAL_PLAYER_OR_OBSERVER_OFFSET: Long = 0x07539FBCL
        const val CURRENT_MATCH_RVA: Long = 0x0753FD5CL
        const val CURRENT_MATCH_OFFSET: Long = 0x0753BD5CL
        const val IS_LOCAL_TEAMMATE_RVA: Long = 0x07540938L
        const val IS_LOCAL_TEAMMATE_OFFSET: Long = 0x0753C938L
        const val IS_SAME_TEAM_RVA: Long = 0x07540A50L
        const val IS_SAME_TEAM_OFFSET: Long = 0x0753CA50L
        const val CURRENT_LOCAL_TEAM_INDEX_RVA: Long = 0x07541628L
        const val CURRENT_LOCAL_TEAM_INDEX_OFFSET: Long = 0x0753D628L
    }
}
