package com.memorylab.mods.offsets

/**
 * Health & EP offsets for HP Indicator rendering.
 * Line limit: < 150 lines.
 */
object HealthOffsets {
    const val PLAYER_GET_CUR_HP_RVA: Long = 0x070E6FA8L
    const val PLAYER_GET_CUR_HP_OFFSET: Long = 0x070E2FA8L
    const val PLAYER_GET_MAX_HP_RVA: Long = 0x070E70A0L
    const val PLAYER_GET_MAX_HP_OFFSET: Long = 0x070E30A0L
    const val PLAYER_GET_CUR_EP_RVA: Long = 0x07137F44L
    const val PLAYER_GET_CUR_EP_OFFSET: Long = 0x07133F44L
    const val ATTACKABLE_IS_DEAD_RVA: Long = 0x0703C914L
    const val ATTACKABLE_IS_DEAD_OFFSET: Long = 0x07038914L
}
