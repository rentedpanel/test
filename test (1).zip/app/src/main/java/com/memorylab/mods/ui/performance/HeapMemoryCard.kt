package com.memorylab.mods.ui.performance

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.PerformanceMetrics
import com.memorylab.mods.ui.theme.*

/**
 * JVM Heap memory usage card.
 * Line limit: < 150 lines.
 */
@Composable
fun HeapMemoryCard(
    metrics: PerformanceMetrics,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("JVM HEAP MEMORY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentCyan)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Used: ${String.format("%.1f", metrics.heapMemoryUsedMb)} MB", fontSize = 13.sp, color = TextPrimary)
                Text("Total: ${String.format("%.1f", metrics.heapMemoryTotalMb)} MB", fontSize = 13.sp, color = TextSecondary)
            }

            Spacer(modifier = Modifier.height(8.dp))
            val memFraction = if (metrics.heapMemoryTotalMb > 0f) {
                (metrics.heapMemoryUsedMb / metrics.heapMemoryTotalMb).coerceIn(0f, 1f)
            } else 0f

            LinearProgressIndicator(
                progress   = { memFraction },
                modifier   = Modifier.fillMaxWidth().height(6.dp),
                color      = AccentPurple,
                trackColor = DarkSurfaceVariant
            )
        }
    }
}
