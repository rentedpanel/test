package com.memorylab.mods.ui.performance

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.PerformanceMetrics
import com.memorylab.mods.ui.theme.*

/**
 * FPS Hero Card showing current frame rate and progress indicator.
 * Line limit: < 150 lines.
 */
@Composable
fun FpsHeroCard(
    metrics: PerformanceMetrics,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier            = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("CURRENT RENDER RATE", fontSize = 11.sp, color = TextSecondary)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text       = "${String.format("%.1f", metrics.fps)} FPS",
                fontSize   = 38.sp,
                fontWeight = FontWeight.ExtraBold,
                color      = if (metrics.fps >= 50f) HealthGreen else AccentCyan
            )
            Text(
                text     = "Frame Render Budget: ${String.format("%.2f", metrics.frameRenderTimeMs)} ms / 16.6 ms",
                fontSize = 12.sp,
                color    = TextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))
            LinearProgressIndicator(
                progress   = { (metrics.fps / 60f).coerceIn(0f, 1f) },
                modifier   = Modifier.fillMaxWidth().height(8.dp),
                color      = HealthGreen,
                trackColor = DarkSurfaceVariant
            )
        }
    }
}
