package com.memorylab.mods.rendering

import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint

/**
 * Pre-allocated Paint instances for 60+ FPS zero-allocation Canvas drawing.
 * Line limit: < 150 lines.
 */
object EspPaints {
    val boxAlphaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#FF5252")
        strokeWidth = 2.5f
    }

    val boxBravoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#00E5FF")
        strokeWidth = 2.5f
    }

    val tracerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    val hpBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#CC1B1B24")
    }

    val hpFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 24f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }

    val dashedEffect = DashPathEffect(floatArrayOf(10f, 6f), 0f)
}
