package com.memorylab.mods

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LogLevel {
    INFO, SUCCESS, WARNING, ERROR, DEBUG
}

data class LogEntry(
    val timestamp: Long = System.currentTimeMillis(),
    val level: LogLevel,
    val tag: String,
    val message: String
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(timestamp))
}

/**
 * Thread-safe diagnostics and operations logger.
 * Dispatches to standard android.util.Log (Logcat) and maintains a reactive StateFlow for Compose UI.
 */
object OperationLog {

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private const val MAX_LOGS = 200

    init {
        info("System", "MemoryLab Pro Core initialized")
        info("Native", NativeMemory.getStatusSummary())
    }

    fun log(level: LogLevel, tag: String, message: String) {
        // Standard Android Logcat integration
        when (level) {
            LogLevel.INFO, LogLevel.SUCCESS -> Log.i(tag, message)
            LogLevel.WARNING -> Log.w(tag, message)
            LogLevel.ERROR -> Log.e(tag, message)
            LogLevel.DEBUG -> Log.d(tag, message)
        }

        val entry = LogEntry(level = level, tag = tag, message = message)
        _logs.update { current ->
            val updated = ArrayList<LogEntry>(current.size + 1)
            updated.add(entry)
            if (current.size >= MAX_LOGS) {
                updated.addAll(current.subList(0, MAX_LOGS - 1))
            } else {
                updated.addAll(current)
            }
            updated
        }
    }

    fun info(tag: String, message: String) = log(LogLevel.INFO, tag, message)
    fun success(tag: String, message: String) = log(LogLevel.SUCCESS, tag, message)
    fun warn(tag: String, message: String) = log(LogLevel.WARNING, tag, message)
    fun error(tag: String, message: String) = log(LogLevel.ERROR, tag, message)
    fun debug(tag: String, message: String) = log(LogLevel.DEBUG, tag, message)

    fun clear() {
        _logs.value = listOf(
            LogEntry(level = LogLevel.INFO, tag = "System", message = "Operation logs cleared")
        )
    }
}
