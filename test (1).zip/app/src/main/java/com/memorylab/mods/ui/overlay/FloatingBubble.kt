package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.memorylab.mods.engine.SessionState

/**
 * Clean circular floating logo button without any outer bounding box aura.
 */
@Composable
fun FloatingBubble(
    sessionState: SessionState,
    onExpand: () -> Unit,
    onDragDelta: ((Float, Float) -> Unit)?,
    onLocalDrag: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(48.dp)
            .shadow(8.dp, CircleShape)
            .clip(CircleShape)
            .background(MockupAccentPurple)
            .border(1.5.dp, Color.White.copy(alpha = 0.4f), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    if (onDragDelta != null) {
                        onDragDelta(dragAmount.x, dragAmount.y)
                    } else {
                        onLocalDrag(dragAmount.x, dragAmount.y)
                    }
                }
            }
            .clickable { onExpand() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Diamond,
            contentDescription = "Expand Floating Menu",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
        )

        if (sessionState == SessionState.RUNNING) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(MockupStatusGreen)
                    .border(1.5.dp, MockupAccentPurple, CircleShape)
            )
        }
    }
}
