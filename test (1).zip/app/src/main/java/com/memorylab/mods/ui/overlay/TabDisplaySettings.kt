package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.EspController
import com.memorylab.mods.SimulationEngine
import com.memorylab.mods.ui.theme.TextPrimary
import com.memorylab.mods.ui.theme.TextSecondary

/**
 * Display & Settings tab inside floating menu.
 * Line limit: < 150 lines.
 */
@Composable
fun TabDisplaySettings(modifier: Modifier = Modifier) {
    val activeDataSource by SimulationEngine.dataSourceMode.collectAsState()
    var batchRenderEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(6.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text("RENDER ENGINE SETTINGS", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MockupAccentPurple)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors   = CardDefaults.cardColors(containerColor = MockupCardBg),
            shape    = RoundedCornerShape(6.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                Text("DATA SOURCE MODE", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                Spacer(modifier = Modifier.height(2.dp))
                Text(activeDataSource.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MockupStatusGreen)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors   = CardDefaults.cardColors(containerColor = MockupCardBg),
            shape    = RoundedCornerShape(6.dp)
        ) {
            Row(
                modifier              = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Text("Batch Canvas Draw", fontSize = 10.sp, color = TextPrimary)
                Switch(
                    checked         = batchRenderEnabled,
                    onCheckedChange = { batchRenderEnabled = it },
                    modifier        = Modifier.scale(0.65f),
                    colors          = SwitchDefaults.colors(
                        checkedThumbColor   = MockupAccentPurple,
                        checkedTrackColor   = MockupTrackPurple.copy(alpha = 0.4f),
                        uncheckedThumbColor = MockupThumbOff,
                        uncheckedTrackColor = MockupTrackOff
                    )
                )
            }
        }
    }
}
