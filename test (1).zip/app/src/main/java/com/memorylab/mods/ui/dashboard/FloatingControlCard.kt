package com.memorylab.mods.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.components.AppOutlinedButton
import com.memorylab.mods.ui.components.AppStandardCard
import com.memorylab.mods.ui.theme.*

/**
 * Material 3 Card controlling Floating Window & System Overlay service.
 * Line limit: < 150 lines.
 */
@Composable
fun FloatingControlCard(
    isOverlayRunning: Boolean,
    onToggleFloatingWindow: () -> Unit,
    onNavigateToVisuals: () -> Unit,
    modifier: Modifier = Modifier
) {
    AppStandardCard(modifier = modifier) {
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier         = Modifier
                        .size(40.dp)
                        .background(AccentCyan.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector        = Icons.Default.Layers,
                        contentDescription = null,
                        tint               = AccentCyan,
                        modifier           = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text       = "Floating Window Engine",
                        fontSize   = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color      = TextPrimary
                    )
                    Text(
                        text       = if (isOverlayRunning) "Overlay Active — Drawing Visuals" else "Overlay Inactive",
                        fontSize   = 11.sp,
                        color      = if (isOverlayRunning) HealthGreen else TextSecondary
                    )
                }
            }

            Switch(
                checked         = isOverlayRunning,
                onCheckedChange = { onToggleFloatingWindow() },
                colors          = SwitchDefaults.colors(
                    checkedThumbColor   = Color.Black,
                    checkedTrackColor   = Color(0xFF00E676),
                    uncheckedThumbColor = TextSecondary,
                    uncheckedTrackColor = DarkSurfaceVariant
                )
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        AppOutlinedButton(
            text         = "Configure Visual Overlay Options",
            icon         = Icons.Default.Tune,
            onClick      = onNavigateToVisuals,
            modifier     = Modifier.fillMaxWidth()
        )
    }
}

