package com.memorylab.mods.engine

enum class DataSourceMode(val displayName: String) {
    SYNTHETIC_SIMULATION("Synthetic Simulation"),
    IPC_DATA_BRIDGE("IPC Data Bridge"),
    ROOT_MEMORY_READER("Root Memory Reader")
}

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR
}

enum class SessionState {
    STOPPED,
    RUNNING,
    PAUSED
}
