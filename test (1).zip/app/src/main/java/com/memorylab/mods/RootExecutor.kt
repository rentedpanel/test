package com.memorylab.mods

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream

/**
 * ============================================================================
 *                 ROOT SHELL EXECUTOR & PRIVILEGE MANAGER
 * ============================================================================
 * 
 * Manages interactive root execution via Android Superuser ('su'):
 * - Triggers root access permission grant dialogs (Magisk / KernelSU / APatch)
 * - Resolves game PID via 'pidof'
 * - Adjusts /proc/<pid>/mem permissions if needed for non-blocking read access
 */
object RootExecutor {

    var isRootGranted: Boolean = false
        private set

    var currentTargetPid: Int = -1
        private set

    var targetLibBase: Long = 0L
        private set

    /**
     * Executes a command via 'su' shell and returns stdout.
     */
    suspend fun executeSuCommand(command: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val process = Runtime.getRuntime().exec("su")
            val outputStream: OutputStream = process.outputStream
            outputStream.write("$command\nexit\n".toByteArray())
            outputStream.flush()
            outputStream.close()

            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            reader.close()

            val exitCode = process.waitFor()
            if (exitCode == 0) {
                Result.success(output.toString().trim())
            } else {
                Result.failure(Exception("Root command exited with code $exitCode"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Requests root access by verifying uid=0 from 'id'.
     */
    suspend fun requestRootAccess(): Boolean {
        val result = executeSuCommand("id")
        isRootGranted = result.isSuccess && (result.getOrNull()?.contains("uid=0") == true)
        if (isRootGranted) {
            OperationLog.success("RootExecutor", "Superuser permissions granted (Root Access ACTIVE)")
        } else {
            OperationLog.warn("RootExecutor", "Superuser permission denied or 'su' binary missing")
        }
        return isRootGranted
    }

    /**
     * Finds target game PID by scanning with native reader or fallback shell command.
     */
    suspend fun resolveGamePid(packageName: String): Int {
        // 1. Try native /proc scanner first (fastest, in-process)
        var pid = NativeRootMemory.nativeFindProcessPid(packageName)
        if (pid > 0) {
            currentTargetPid = pid
            OperationLog.info("RootExecutor", "Target PID resolved via C++ /proc scan: $pid")
            return pid
        }

        // 2. Fallback to shell 'pidof' via root
        val pidofResult = executeSuCommand("pidof $packageName")
        if (pidofResult.isSuccess) {
            val raw = pidofResult.getOrNull()?.split(" ")?.firstOrNull()?.trim()
            val parsed = raw?.toIntOrNull()
            if (parsed != null && parsed > 0) {
                currentTargetPid = parsed
                OperationLog.info("RootExecutor", "Target PID resolved via root pidof: $parsed")
                return parsed
            }
        }

        currentTargetPid = -1
        return -1
    }

    /**
     * Resolves the runtime base address of libil2cpp.so for the target PID.
     */
    suspend fun resolveModuleBase(pid: Int, moduleName: String = "libil2cpp.so"): Long {
        if (pid <= 0) return 0L

        // 1. Native /proc/<pid>/maps reader
        val base = NativeRootMemory.nativeGetModuleBase(pid, moduleName)
        if (base > 0L) {
            targetLibBase = base
            val hex = "0x" + base.toString(16).uppercase()
            OperationLog.success("RootExecutor", "$moduleName Base resolved: $hex (PID: $pid)")
            return base
        }

        // 2. Fallback via root shell grep on maps
        val grepResult = executeSuCommand("grep \"$moduleName\" /proc/$pid/maps | head -n 1 | cut -d'-' -f1")
        if (grepResult.isSuccess) {
            val hexStr = grepResult.getOrNull()?.trim()
            if (!hexStr.isNullOrEmpty()) {
                try {
                    val parsed = hexStr.toLong(16)
                    targetLibBase = parsed
                    OperationLog.success("RootExecutor", "$moduleName Base resolved via root shell: 0x$hexStr")
                    return parsed
                } catch (_: Exception) {}
            }
        }

        targetLibBase = 0L
        return 0L
    }

    /**
     * Ensures /proc/<pid>/mem read permissions if SELinux or Android restricts pread64.
     */
    suspend fun grantProcMemoryAccess(pid: Int): Boolean {
        if (pid <= 0) return false
        val cmd = "chmod 666 /proc/$pid/mem && chmod 666 /proc/$pid/maps"
        val res = executeSuCommand(cmd)
        return res.isSuccess
    }
}
