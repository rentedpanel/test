package com.memorylab.mods

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import com.memorylab.mods.engine.ResearchSceneSnapshot
import com.memorylab.mods.rendering.EspPaints
import kotlin.math.sin

/**
 * High-performance Android Canvas ESP Renderer for MemoryLab Pro.
 * Pre-allocates all Paint, Path, and RectF instances to achieve 60+ FPS zero-allocation rendering.
 * Line limit: < 150 lines.
 */
class EspRenderer {
    private val reusableBoxRect = RectF()
    private val reusableHpBgRect = RectF()
    private val reusableHpFillRect = RectF()

    fun render(canvas: Canvas, snapshot: ResearchSceneSnapshot, settings: EspSettings, viewWidth: Float, viewHeight: Float): Int {
        if (!settings.espEnabled || viewWidth <= 0f || viewHeight <= 0f) return 0
        var drawCalls = 0

        val alphaInt = (settings.espOpacity.coerceIn(0.1f, 1.0f) * 255).toInt()
        EspPaints.boxAlphaPaint.strokeWidth = settings.boxThickness
        EspPaints.boxBravoPaint.strokeWidth = settings.boxThickness
        EspPaints.textPaint.textSize = settings.textSize * (viewWidth / 400f).coerceIn(1.0f, 2.5f)

        val camera = snapshot.camera
        val viewMatrix = camera.viewMatrix ?: return 0
        val projMatrix = camera.projMatrix ?: return 0

        val tracerOriginX = viewWidth * 0.5f
        val tracerOriginY = when (settings.tracerOrigin) {
            TracerOrigin.TOP -> 0f
            TracerOrigin.CENTER -> viewHeight * 0.5f
            TracerOrigin.BOTTOM -> viewHeight
        }

        var renderedEntitiesCount = 0

        val maxDistanceCutoff = if (settings.maxDistance > 0f) settings.maxDistance else settings.renderDistance

        for (entity in snapshot.entities) {
            if (!entity.isValid() || entity.distance > maxDistanceCutoff) continue

            val headScreen = Projection.worldToScreen(entity.headPos, viewMatrix, projMatrix, viewWidth, viewHeight) ?: continue
            val footScreen = Projection.worldToScreen(entity.footPos, viewMatrix, projMatrix, viewWidth, viewHeight) ?: continue
            val box = Projection.calculateScreenBox(headScreen, footScreen) ?: continue
            if (box.left <= 0f && box.top <= 0f) continue

            renderedEntitiesCount++
            val primaryColor = if (entity.team == TeamCategory.ALPHA) Color.argb(alphaInt, 255, 61, 0) else Color.argb(alphaInt, 0, 229, 255)
            val currentBoxPaint = if (entity.team == TeamCategory.ALPHA) EspPaints.boxAlphaPaint else EspPaints.boxBravoPaint
            currentBoxPaint.color = primaryColor

            if (settings.showTracerLine) {
                EspPaints.tracerPaint.color = primaryColor
                EspPaints.tracerPaint.alpha = (alphaInt * 0.65f).toInt()
                val targetY = if (settings.tracerOrigin == TracerOrigin.TOP) box.top else footScreen.y
                val targetX = if (settings.tracerOrigin == TracerOrigin.TOP) box.centerX() else footScreen.x
                if (targetX > 0f && targetY > 0f) {
                    canvas.drawLine(tracerOriginX, tracerOriginY, targetX, targetY, EspPaints.tracerPaint)
                    drawCalls++
                }
            }

            if (settings.showBoundingBox) {
                reusableBoxRect.set(box.left, box.top, box.right, box.bottom)
                canvas.drawRect(reusableBoxRect, currentBoxPaint)
                drawCalls++
            }

            if (settings.showDistance) {
                EspPaints.textPaint.color = primaryColor
                EspPaints.textPaint.alpha = alphaInt
                canvas.drawText("${entity.distance.toInt()}m", box.centerX(), box.top - 6f, EspPaints.textPaint)
                drawCalls++
            }

            if (settings.showHpBar) {
                val barLeft = box.left - 7f
                val barRight = barLeft + 4.5f
                reusableHpBgRect.set(barLeft, box.top, barRight, box.bottom)
                canvas.drawRect(reusableHpBgRect, EspPaints.hpBgPaint)
                val fillTop = box.bottom - (box.bottom - box.top) * entity.healthPercent
                reusableHpFillRect.set(barLeft + 1f, fillTop, barRight - 1f, box.bottom - 1f)
                EspPaints.hpFillPaint.color = when {
                    entity.healthPercent > 0.6f -> Color.GREEN
                    entity.healthPercent > 0.25f -> Color.YELLOW
                    else -> Color.RED
                }
                canvas.drawRect(reusableHpFillRect, EspPaints.hpFillPaint)
                drawCalls += 2
            }
        }
        return drawCalls
    }
}
