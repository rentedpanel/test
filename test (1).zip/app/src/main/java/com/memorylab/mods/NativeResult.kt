package com.memorylab.mods

/**
 * Structured result model for native and IPC operations.
 */
data class NativeResult<T>(
    val success: Boolean,
    val errorCode: Int = 0,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val data: T? = null
) {
    companion object {
        fun <T> ok(data: T? = null, message: String = "Operation completed successfully"): NativeResult<T> {
            return NativeResult(success = true, errorCode = 0, message = message, data = data)
        }

        fun <T> error(code: Int, message: String): NativeResult<T> {
            return NativeResult(success = false, errorCode = code, message = message, data = null)
        }
    }
}
