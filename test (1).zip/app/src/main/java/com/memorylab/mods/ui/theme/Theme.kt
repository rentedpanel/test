package com.memorylab.mods.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF121218)
val DarkSurface = Color(0xFF1B1B24)
val DarkSurfaceVariant = Color(0xFF242432)
val AccentPurple = Color(0xFF7C4DFF)
val AccentCyan = Color(0xFF00E5FF)
val TeamRed = Color(0xFFFF5252)
val TeamBlue = Color(0xFF2979FF)
val HealthGreen = Color(0xFF00E676)
val TextPrimary = Color(0xFFEEEEF2)
val TextSecondary = Color(0xFFA0A0B2)
val DarkBorder = Color(0xFF2E2E40)
val TeamGreen = Color(0xFF00E676)

private val DarkColorScheme = darkColorScheme(
    primary = AccentCyan,
    secondary = AccentPurple,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    error = TeamRed
)

@Composable
fun MemoryLabTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
