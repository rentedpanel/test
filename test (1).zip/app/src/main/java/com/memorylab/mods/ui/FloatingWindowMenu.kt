package com.memorylab.mods.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.memorylab.mods.*
import com.memorylab.mods.ui.overlay.*
import kotlin.math.roundToInt

/**
 * Modern Material 3 Draggable Floating Window Overlay Menu.
 * Assembles subcomponents from com.memorylab.mods.ui.overlay.
 * Line count strictly <= 150 lines.
 */
@Composable
fun FloatingWindowMenu(
    modifier: Modifier = Modifier,
    initialVisible: Boolean = true,
    isExternalWindow: Boolean = false,
    onDragDelta: ((Float, Float) -> Unit)? = null,
    onClose: () -> Unit = {}
) {
    var isVisible by remember { mutableStateOf(initialVisible) }
    var isMinimized by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(OverlayTab.OVERVIEW) }

    var localOffsetX by remember { mutableFloatStateOf(16f) }
    var localOffsetY by remember { mutableFloatStateOf(60f) }

    val sessionState by SimulationEngine.sessionState.collectAsState()
    val metrics by PerformanceMonitor.metrics.collectAsState()
    val connectionState by SimulationEngine.connectionState.collectAsState()

    var isSidebarOpen by remember { mutableStateOf(false) }

    if (!isVisible) return

    val contentModifier = if (isExternalWindow) {
        modifier.wrapContentSize(Alignment.TopStart)
    } else {
        modifier.fillMaxSize().pointerInput(Unit) {}
    }

    BoxWithConstraints(modifier = contentModifier, contentAlignment = Alignment.TopStart) {
        val availableW = maxWidth
        val availableH = maxHeight

        val targetWidth = if (isExternalWindow) 280.dp else if (availableW > 0.dp && availableW < 2000.dp) availableW.coerceAtMost(300.dp).coerceAtLeast(260.dp) else 280.dp
        val targetHeight = if (isExternalWindow) 200.dp else if (availableH > 0.dp && availableH < 2000.dp) availableH.coerceAtMost(260.dp).coerceAtLeast(180.dp) else 200.dp

        val positionModifier = if (isExternalWindow) Modifier else Modifier.offset {
            IntOffset(localOffsetX.roundToInt(), localOffsetY.roundToInt())
        }

        if (isMinimized) {
            FloatingBubble(
                sessionState = sessionState,
                onExpand     = { isMinimized = false },
                onDragDelta  = onDragDelta,
                onLocalDrag  = { dx, dy -> localOffsetX += dx; localOffsetY += dy },
                modifier     = positionModifier
            )
        } else {
            Card(
                modifier = positionModifier
                    .width(targetWidth)
                    .height(targetHeight)
                    .shadow(12.dp, RoundedCornerShape(10.dp))
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, MockupCardBorder, RoundedCornerShape(10.dp)),
                colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MockupWindowBg)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    FloatingWindowHeader(
                        title       = "MemoryLab Pro",
                        onToggleSidebar = { isSidebarOpen = !isSidebarOpen },
                        onMinimize  = { isMinimized = true },
                        onClose     = { isVisible = false; onClose() },
                        onDragDelta = onDragDelta,
                        onLocalDrag = { dx, dy -> localOffsetX += dx; localOffsetY += dy }
                    )

                    Row(modifier = Modifier.fillMaxSize()) {
                        if (isSidebarOpen) {
                            FloatingSidebar(
                                selectedTab = selectedTab,
                                onTabSelect = { selectedTab = it; isSidebarOpen = false }
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .background(MockupWindowBg)
                        ) {
                            when (selectedTab) {
                                OverlayTab.OVERVIEW  -> TabOverview(sessionState, metrics, connectionState, { SimulationEngine.toggleSession() })
                                OverlayTab.TARGETING -> TabTargeting()
                                OverlayTab.VISUALS   -> TabVisuals()
                                OverlayTab.DISPLAY,
                                OverlayTab.SETTINGS  -> TabDisplaySettings()
                            }
                        }
                    }
                }
            }
        }
    }
}
