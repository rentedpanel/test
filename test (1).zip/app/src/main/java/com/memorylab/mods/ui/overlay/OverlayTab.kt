package com.memorylab.mods.ui.overlay

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

// Custom Color Palette for Floating Window & System Overlay
val MockupWindowBg      = Color(0xFF14141B)
val MockupSidebarBg     = Color(0xFF191922)
val MockupCardBg        = Color(0xFF20202C)
val MockupCardBorder    = Color(0xFF2A2A3A)
val MockupAccentPurple  = Color(0xFF6C5CE7)
val MockupTrackPurple   = Color(0xFFA29BFE)
val MockupTrackOff      = Color(0xFF323242)
val MockupThumbOff      = Color(0xFF6E6E82)
val MockupStatusGreen   = Color(0xFF00E676)
val MockupGreenCapsule  = Color(0xFF162B20)

enum class OverlayTab(val title: String, val icon: ImageVector) {
    OVERVIEW("Overview", Icons.Default.GridView),
    TARGETING("Targeting", Icons.Default.Adjust),
    VISUALS("Visuals", Icons.Default.Visibility),
    DISPLAY("Display", Icons.Default.Layers),
    SETTINGS("Settings", Icons.Default.RadioButtonUnchecked)
}
