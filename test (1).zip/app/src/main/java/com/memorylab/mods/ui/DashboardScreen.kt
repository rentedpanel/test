package com.memorylab.mods.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.memorylab.mods.*
import com.memorylab.mods.engine.*
import com.memorylab.mods.service.OverlayController
import com.memorylab.mods.config.AppPickerHelper
import com.memorylab.mods.config.GameConfig
import com.memorylab.mods.config.InstalledAppInfo
import com.memorylab.mods.main.Screen
import com.memorylab.mods.root.RootEngineCard
import com.memorylab.mods.root.RootShellController
import com.memorylab.mods.ui.components.AppHeaderBar
import com.memorylab.mods.ui.dashboard.*
import com.memorylab.mods.ui.theme.DarkBackground
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.activity.compose.rememberLauncherForActivityResult

/**
 * Material 3 Central Dashboard Screen for MemoryLab Pro.
 * Strictly <= 150 lines.
 */
@Composable
fun DashboardScreen(
    onToggleFloatingWindow: () -> Unit = {},
    onNavigateTo: (String) -> Unit
) {
    val sessionState     by SimulationEngine.sessionState.collectAsState()
    val connectionState  by SimulationEngine.connectionState.collectAsState()
    val isOverlayRunning by OverlayController.isServiceRunning.collectAsState()
    val isRootGranted    by RootShellController.isRootGranted.collectAsState()
    val activeEngine     by RootShellController.activeEngine.collectAsState()

    val context = LocalContext.current
    val scope   = rememberCoroutineScope()

    val targetPackage    by GameConfig.currentPackage.collectAsState()
    val targetGameName   by GameConfig.currentGameName.collectAsState()
    val targetModuleName by GameConfig.currentModuleName.collectAsState()
    val hasGame          = targetPackage.isNotEmpty()

    var isInstalled by remember(targetPackage) { mutableStateOf(GameConfig.isGameInstalled(context)) }
    var targetPid by remember(targetPackage) {
        mutableStateOf(try { NativeRootMemory.nativeFindProcessPid(targetPackage).takeIf { it > 0 } } catch (_: Throwable) { null })
    }

    var gameIcon by remember(targetPackage) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(targetPackage) {
        if (targetPackage.isNotEmpty()) {
            gameIcon = withContext(Dispatchers.IO) {
                try { AppPickerHelper.bitmapFromDrawable(context.packageManager.getApplicationIcon(targetPackage))?.asImageBitmap() } catch (_: Throwable) { null }
            }
        } else gameIcon = null
    }

    val pickAppLauncher = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val intentData = result.data
            val component  = intentData?.component
            val pkg = component?.packageName ?: intentData?.`package` ?: intentData?.data?.schemeSpecificPart
            if (!pkg.isNullOrEmpty()) {
                val pm = context.packageManager
                val label = try {
                    pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
                } catch (e: Exception) {
                    pkg
                }
                GameConfig.setTargetPackage(
                    packageName = pkg,
                    gameName    = label,
                    moduleName  = GameConfig.DEFAULT_MODULE_NAME,
                    context     = context
                )
                isInstalled = GameConfig.isGameInstalled(context)
                targetPid   = try { NativeRootMemory.nativeFindProcessPid(pkg).takeIf { it > 0 } } catch (_: Throwable) { null }
            }
        }
    }

    fun refreshStatus() {
        isInstalled = GameConfig.isGameInstalled(context)
        targetPid   = try { NativeRootMemory.nativeFindProcessPid(targetPackage).takeIf { it > 0 } } catch (_: Throwable) { null }
    }

    fun openPicker() {
        try {
            val mainIntent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
                addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            }
            val chooserIntent = android.content.Intent.createChooser(mainIntent, "Select Target Application")
            pickAppLauncher.launch(chooserIntent)
        } catch (e: Exception) {
            OperationLog.error("Picker", "Native app picker failed: ${e.message}")
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(DarkBackground).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        RootEngineCard(isRootGranted = isRootGranted, activeEngineName = activeEngine, onGrantSuClick = { scope.launch { RootShellController.requestSuPermission() } })
        Spacer(modifier = Modifier.height(16.dp))
        if (!hasGame) {
            EmptyTargetCard(onAddGameClick = { openPicker() })
        } else {
            ActiveTargetCard(
                gameName = targetGameName, packageName = targetPackage, moduleName = targetModuleName, gameIcon = gameIcon,
                isInstalled = isInstalled, targetPid = targetPid, connectionState = connectionState, isOverlayRunning = isOverlayRunning,
                onLaunchGame = { if (!GameConfig.launchGame(context)) refreshStatus() }, onToggleFloating = onToggleFloatingWindow,
                onRefresh = { refreshStatus() }, onChangeGame = { openPicker() }, onRemoveTarget = { GameConfig.clearTarget(context); gameIcon = null },
                onToggleIpc = { if (connectionState == ConnectionState.CONNECTED) SimulationEngine.disconnectTarget() else SimulationEngine.connectTarget(context) }
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        ActionGridSection(onNavigateTo = onNavigateTo)
        Spacer(modifier = Modifier.height(28.dp))
    }
}

