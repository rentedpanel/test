package com.memorylab.mods.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.*
import com.memorylab.mods.engine.*
import com.memorylab.mods.config.GameConfig
import com.memorylab.mods.ui.components.*
import com.memorylab.mods.ui.research.*
import com.memorylab.mods.ui.theme.*

/**
 * Game Settings & IL2CPP Research screen.
 * Modularized with subcomponents in ui.research.
 * Uses unified AppDesignSystem components. Line count strictly <= 150 lines.
 */
@Composable
fun Il2cppResearchScreen() {
    val context = LocalContext.current
    val targetPackage  by GameConfig.currentPackage.collectAsState()
    val targetGameName by GameConfig.currentGameName.collectAsState()
    val isInstalled = remember(targetPackage) { GameConfig.isGameInstalled(context) }
    val sessionState by SimulationEngine.sessionState.collectAsState()
    val snapshot     by SimulationEngine.currentSnapshot.collectAsState()
    val metrics      by PerformanceMonitor.metrics.collectAsState()

    var selectedFpsMode     by remember { mutableIntStateOf(60) }
    var hardwareSyncEnabled by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        AppPageHeader(
            title    = "Game Settings",
            subtitle = "IL2CPP & Application Settings"
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "SYSTEM & ENGINE STATUS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AccentCyan, letterSpacing = 1.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Overlay Status", sessionState.name, if (sessionState == SessionState.RUNNING) "Active (60 FPS)" else "Standby", if (sessionState == SessionState.RUNNING) HealthGreen else AccentPurple, Modifier.weight(1f))
            MetricCard("Active Entities", "${snapshot.entities.size}", "Tracked in range", AccentCyan, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Current FPS", String.format("%.0f", metrics.fps), "${String.format("%.1f", metrics.frameRenderTimeMs)}ms frame", HealthGreen, Modifier.weight(1f))
            MetricCard("Response Time", "${metrics.bridgeLatencyMs.toInt()} ms", "Sync latency", AccentCyan, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        ResearchTargetCard(gameName = targetGameName, packageName = targetPackage, isInstalled = isInstalled)

        Spacer(modifier = Modifier.height(16.dp))

        ResearchGraphicsCard(
            selectedFpsMode      = selectedFpsMode,
            onFpsChange          = { selectedFpsMode = it },
            hardwareSyncEnabled  = hardwareSyncEnabled,
            onHardwareSyncChange = { hardwareSyncEnabled = it }
        )

        Spacer(modifier = Modifier.height(28.dp))
    }
}

