package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.EspController
import com.memorylab.mods.EspSettings
import com.memorylab.mods.ui.components.AppStandardCard
import com.memorylab.mods.ui.theme.*

/**
 * Visual HUD & Radar Toggles card embedded directly on screen.
 * Line limit: < 150 lines.
 */
@Composable
fun SheetVisualTogglesCard(
    modifier: Modifier = Modifier
) {
    val settings by EspController.settings.collectAsState()

    AppStandardCard(modifier = modifier) {
        Text("Visual Overlay & Radar Toggles", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(modifier = Modifier.height(10.dp))

        ControlToggleRow("Master Visual Overlay", "Enable or disable all visual HUD elements", settings.espEnabled) {
            EspController.setEspEnabled(it)
        }
        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = DarkBorder)
        ControlToggleRow("2D Bounding Box", "Adaptive corner-bracket boxes", settings.showBoundingBox) {
            EspController.setBoundingBox(it)
        }
        ControlToggleRow("Health (HP) Bar", "Dynamic gradient health indicator", settings.showHpBar) {
            EspController.setHpBar(it)
        }
        ControlToggleRow("Distance Tag", "Metric distance to target position", settings.showDistance) {
            EspController.setDistance(it)
        }
        ControlToggleRow("Tracer Line", "Snapline from chosen screen origin", settings.showTracerLine) {
            EspController.setTracerLine(it)
        }
    }
}

@Composable
fun ControlToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier              = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 2,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked         = checked,
            onCheckedChange = onCheckedChange,
            modifier        = Modifier.scale(0.7f),
            colors          = SwitchDefaults.colors(
                checkedThumbColor   = Color.Black,
                checkedTrackColor   = AccentCyan,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = DarkSurfaceVariant
            )
        )
    }
}

