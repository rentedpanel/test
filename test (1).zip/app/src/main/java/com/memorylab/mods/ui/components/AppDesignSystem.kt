package com.memorylab.mods.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.*

/**
 * Unified Material Design 3 Design System for MemoryLab Pro.
 * Provides standardized headers, buttons, and cards used across all screens.
 * Line limit: < 150 lines.
 */
@Composable
fun AppPageHeader(
    title: String,
    subtitle: String,
    actionIcon: ImageVector? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier              = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text          = subtitle.uppercase(),
                fontSize      = 10.sp,
                fontWeight    = FontWeight.Bold,
                color         = AccentCyan,
                letterSpacing = 1.2.sp
            )
            Text(
                text       = title,
                fontSize   = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color      = TextPrimary
            )
        }
        if (actionIcon != null && onActionClick != null) {
            IconButton(
                onClick  = onActionClick,
                modifier = Modifier.background(DarkSurfaceVariant, androidx.compose.foundation.shape.CircleShape)
            ) {
                Icon(actionIcon, contentDescription = null, tint = AccentCyan)
            }
        }
    }
}

@Composable
fun AppPrimaryButton(
    text: String,
    icon: ImageVector? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color = AccentPurple,
    contentColor: Color = Color.White
) {
    Button(
        onClick  = onClick,
        enabled  = enabled,
        modifier = modifier.height(48.dp),
        colors   = ButtonDefaults.buttonColors(
            containerColor         = containerColor,
            contentColor           = contentColor,
            disabledContainerColor = containerColor.copy(alpha = 0.35f),
            disabledContentColor   = contentColor.copy(alpha = 0.4f)
        ),
        shape    = RoundedCornerShape(12.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(text = text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun AppOutlinedButton(
    text: String,
    icon: ImageVector? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    contentColor: Color = AccentCyan
) {
    OutlinedButton(
        onClick  = onClick,
        modifier = modifier.height(44.dp),
        colors   = ButtonDefaults.outlinedButtonColors(contentColor = contentColor),
        shape    = RoundedCornerShape(12.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(text = text, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }
}

@Composable
fun AppStandardCard(
    modifier: Modifier = Modifier,
    borderColor: Color = DarkBorder,
    content: @Composable ColumnScope.() -> Unit
) {
    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(16.dp)),
        colors   = CardDefaults.elevatedCardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSleekSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    activeTrackColor: Color = AccentPurple,
    inactiveTrackColor: Color = DarkSurfaceVariant,
    thumbColor: Color = AccentPurple
) {
    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        modifier = modifier.height(24.dp),
        thumb = {
            Box(
                modifier = Modifier
                    .size(13.dp)
                    .background(thumbColor, androidx.compose.foundation.shape.CircleShape)
            )
        },
        track = { sliderState ->
            SliderDefaults.Track(
                sliderState = sliderState,
                modifier = Modifier.height(4.dp),
                colors = SliderDefaults.colors(
                    activeTrackColor = activeTrackColor,
                    inactiveTrackColor = inactiveTrackColor
                )
            )
        }
    )
}
