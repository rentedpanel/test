package com.memorylab.mods.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.memorylab.mods.*
import com.memorylab.mods.ui.components.*
import com.memorylab.mods.ui.overlay.SheetParametersCard
import com.memorylab.mods.ui.overlay.SheetVisualTogglesCard
import com.memorylab.mods.ui.theme.*
import com.memorylab.mods.ui.visuals.*

/**
 * Visuals Studio (ESP Lab) screen.
 * Embeds canvas preview, visual toggles, and parameter sliders directly on page.
 * Strictly <= 150 lines.
 */
@Composable
fun EspLabScreen(
    onToggleFloatingWindow: () -> Unit = {}
) {
    val snapshot     by SimulationEngine.currentSnapshot.collectAsState()
    val sessionState by SimulationEngine.sessionState.collectAsState()
    val metrics      by PerformanceMonitor.metrics.collectAsState()

    var showCameraControls by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        AppPageHeader(
            title    = "Visuals Studio",
            subtitle = "ESP Canvas & Overlay Controls"
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            AppOutlinedButton(
                text         = if (showCameraControls) "Hide Camera" else "Camera Controls",
                icon         = Icons.Default.Videocam,
                onClick      = { showCameraControls = !showCameraControls },
                contentColor = if (showCameraControls) AccentCyan else TextSecondary
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Box(modifier = Modifier.fillMaxWidth().height(220.dp)) {
            VisualStudioCanvas(
                snapshot     = snapshot,
                sessionState = sessionState,
                metrics      = metrics,
                modifier     = Modifier.fillMaxSize()
            )
        }

        if (showCameraControls) {
            Spacer(modifier = Modifier.height(12.dp))
            CameraControlPanel()
        }

        Spacer(modifier = Modifier.height(14.dp))
        SheetVisualTogglesCard()

        Spacer(modifier = Modifier.height(14.dp))
        SheetParametersCard()

        Spacer(modifier = Modifier.height(14.dp))
        Box(modifier = Modifier.fillMaxWidth().height(180.dp)) {
            EntityTelemetryList(snapshot = snapshot, modifier = Modifier.fillMaxSize())
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}


