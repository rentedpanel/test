package com.memorylab.mods.ui.diagnostics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.LogEntry
import com.memorylab.mods.LogLevel
import com.memorylab.mods.ui.theme.AccentCyan
import com.memorylab.mods.ui.theme.HealthGreen
import com.memorylab.mods.ui.theme.TextPrimary
import com.memorylab.mods.ui.theme.TextSecondary

/**
 * Log list renderer component.
 * Line limit: < 150 lines.
 */
@Composable
fun LogListSection(
    logs: List<LogEntry>,
    selectedLogLevel: LogLevel?,
    modifier: Modifier = Modifier
) {
    val filteredLogs = if (selectedLogLevel == null) logs else logs.filter { it.level == selectedLogLevel }

    LazyColumn(
        modifier            = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(filteredLogs) { entry ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Text(
                    text       = "[${entry.level.name}] ",
                    fontSize   = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color      = when (entry.level) {
                        LogLevel.ERROR   -> androidx.compose.ui.graphics.Color(0xFFFF5252)
                        LogLevel.WARNING -> androidx.compose.ui.graphics.Color(0xFFFFA502)
                        LogLevel.INFO    -> HealthGreen
                        else           -> AccentCyan
                    }
                )
                Text(text = entry.message, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextPrimary)
            }
        }
    }
}
