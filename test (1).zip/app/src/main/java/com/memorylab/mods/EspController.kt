package com.memorylab.mods

import android.content.Context
import com.memorylab.mods.config.EspPreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class TracerOrigin(val displayName: String) {
    BOTTOM("Screen Bottom"),
    CENTER("Crosshair Center"),
    TOP("Screen Top")
}

enum class CrosshairStyle(val displayName: String) {
    CIRCLE("Circle (◯)"),
    PLUS("Plus (+)"),
    CIRCLE_PLUS("Circle + Plus (⊕)"),
    DOT_CIRCLE("Dot + Circle (⦿)")
}

data class EspSettings(
    // Toggles
    val espEnabled: Boolean = true,
    val showBoundingBox: Boolean = false,
    val showHpBar: Boolean = false,
    val showDistance: Boolean = false,
    val showTracerLine: Boolean = false,
    val highlightNearest: Boolean = false,

    // Aim Crosshair & Sliders
    val crosshairStyle: CrosshairStyle = CrosshairStyle.PLUS,
    val crosshairSize: Float = 14f,
    val maxDistance: Float = 200f,
    val espScale: Float = 1.0f,
    val boxThickness: Float = 2.5f,
    val textSize: Float = 12f,
    val maxVisibleEntities: Int = 10,
    val tracerOrigin: TracerOrigin = TracerOrigin.TOP,
    val espOpacity: Float = 0.95f,
    val renderDistance: Float = 60f,
    val updateFrequencyHz: Int = 60
)

object EspController {

    private var repository: EspPreferencesRepository? = null

    private val _settings = MutableStateFlow(EspSettings())
    val settings: StateFlow<EspSettings> = _settings.asStateFlow()

    /**
     * Initializes preferences storage and loads saved user settings.
     */
    fun init(context: Context) {
        if (repository == null) {
            val repo = EspPreferencesRepository.getInstance(context)
            repository = repo
            val saved = repo.loadSettings()
            _settings.value = saved
            OperationLog.info("EspController", "Restored persistent ESP settings from storage")
        }
    }

    fun updateSettings(transform: (EspSettings) -> EspSettings) {
        val updated = transform(_settings.value)
        _settings.value = updated
        repository?.saveSettings(updated)
    }

    fun setEspEnabled(enabled: Boolean) = updateSettings { it.copy(espEnabled = enabled) }
    fun setBoundingBox(show: Boolean) = updateSettings { it.copy(showBoundingBox = show) }
    fun setHpBar(show: Boolean) = updateSettings { it.copy(showHpBar = show) }
    fun setDistance(show: Boolean) = updateSettings { it.copy(showDistance = show) }
    fun setTracerLine(show: Boolean) = updateSettings { it.copy(showTracerLine = show) }
    fun setHighlightNearest(highlight: Boolean) = updateSettings { it.copy(highlightNearest = highlight) }

    fun setCrosshairStyle(style: CrosshairStyle) = updateSettings { it.copy(crosshairStyle = style) }
    fun setCrosshairSize(size: Float) = updateSettings { it.copy(crosshairSize = size) }
    fun setMaxDistance(dist: Float) = updateSettings { it.copy(maxDistance = dist) }
    fun setEspScale(scale: Float) = updateSettings { it.copy(espScale = scale) }
    fun setBoxThickness(thickness: Float) = updateSettings { it.copy(boxThickness = thickness) }
    fun setTextSize(size: Float) = updateSettings { it.copy(textSize = size) }
    fun setMaxVisibleEntities(max: Int) = updateSettings { it.copy(maxVisibleEntities = max) }
    fun setTracerOrigin(origin: TracerOrigin) = updateSettings { it.copy(tracerOrigin = origin) }
    fun setEspOpacity(opacity: Float) = updateSettings { it.copy(espOpacity = opacity) }
    fun setRenderDistance(dist: Float) = updateSettings { it.copy(renderDistance = dist) }
    fun setUpdateFrequency(hz: Int) = updateSettings { it.copy(updateFrequencyHz = hz) }
}

