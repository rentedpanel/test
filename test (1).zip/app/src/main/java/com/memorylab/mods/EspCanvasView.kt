package com.memorylab.mods

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.memorylab.mods.rendering.EspPaints
import com.memorylab.mods.view.ArenaGridDrawer
import com.memorylab.mods.view.EspRenderElement
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * High-performance hardware-accelerated custom View for drawing real-time transparent ESP 2D coordinates.
 * Line limit: < 150 lines.
 */
class EspCanvasView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val renderer = EspRenderer()
    private var viewScopeJob: Job? = null

    var customElementsList: List<EspRenderElement>? = null
        set(value) { field = value; invalidate() }

    var render3DArenaGrid: Boolean = false

    private val crosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.parseColor("#9900E5FF"); strokeWidth = 1.8f
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#FF00E5FF")
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        viewScopeJob?.cancel()
        viewScopeJob = CoroutineScope(Dispatchers.Main.immediate).launch {
            EspController.settings.distinctUntilChanged().collect { invalidate() }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        viewScopeJob?.cancel()
        viewScopeJob = null
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) SimulationEngine.updateCameraMatrix(w.toFloat(), h.toFloat())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val customList = customElementsList
        val snapshot = SimulationEngine.currentSnapshot.value
        val settings = EspController.settings.value

        if (!settings.espEnabled) {
            postInvalidateDelayed(150)
            return
        }

        val startTime = System.nanoTime()
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) {
            postInvalidateOnAnimation()
            return
        }
        var drawCalls = 0

        if (render3DArenaGrid && snapshot.camera.viewMatrix != null) {
            drawCalls += ArenaGridDrawer.draw(canvas, snapshot.camera, w, h)
        }

        crosshairPaint.strokeWidth = (settings.boxThickness * 0.7f).coerceAtLeast(1.2f)
        val cx = w * 0.5f; val cy = h * 0.5f; val sz = settings.crosshairSize
        when (settings.crosshairStyle) {
            CrosshairStyle.CIRCLE -> {
                canvas.drawCircle(cx, cy, sz, crosshairPaint)
                drawCalls += 1
            }
            CrosshairStyle.PLUS -> {
                canvas.drawLine(cx - sz, cy, cx + sz, cy, crosshairPaint)
                canvas.drawLine(cx, cy - sz, cx, cy + sz, crosshairPaint)
                drawCalls += 2
            }
            CrosshairStyle.CIRCLE_PLUS -> {
                canvas.drawCircle(cx, cy, sz, crosshairPaint)
                canvas.drawLine(cx - sz * 1.3f, cy, cx + sz * 1.3f, cy, crosshairPaint)
                canvas.drawLine(cx, cy - sz * 1.3f, cx, cy + sz * 1.3f, crosshairPaint)
                drawCalls += 3
            }
            CrosshairStyle.DOT_CIRCLE -> {
                canvas.drawCircle(cx, cy, sz, crosshairPaint)
                canvas.drawCircle(cx, cy, (sz * 0.28f).coerceAtLeast(2.5f), dotPaint)
                drawCalls += 2
            }
        }

        customList?.let { list ->
            for (i in list.indices) {
                val elem = list[i]
                if (elem.tracerFromX != null && elem.tracerFromY != null) {
                    EspPaints.tracerPaint.color = elem.teamColor
                    canvas.drawLine(elem.tracerFromX, elem.tracerFromY, (elem.left + elem.right) * 0.5f, elem.bottom, EspPaints.tracerPaint)
                    drawCalls++
                }
                if (elem.right > elem.left && elem.bottom > elem.top) {
                    EspPaints.boxBravoPaint.color = elem.teamColor
                    canvas.drawRect(elem.left, elem.top, elem.right, elem.bottom, EspPaints.boxBravoPaint)
                    drawCalls++
                }
                if (elem.label.isNotEmpty()) {
                    EspPaints.textPaint.color = elem.teamColor
                    canvas.drawText(elem.label, (elem.left + elem.right) * 0.5f, elem.top - 6f, EspPaints.textPaint)
                    drawCalls++
                }
            }
        }

        if (snapshot.entities.isNotEmpty()) {
            drawCalls += renderer.render(canvas, snapshot, settings, w, h)
        }

        val durationMs = (System.nanoTime() - startTime) / 1_000_000f
        PerformanceMonitor.recordFrame(snapshot.entities.size, drawCalls, durationMs)
        postInvalidateOnAnimation()
    }
}

@Composable
fun EspCanvasOverlay(
    modifier: Modifier = Modifier.fillMaxSize(),
    elements: List<EspRenderElement>? = null,
    renderGrid: Boolean = false
) {
    val settings by EspController.settings.collectAsState()
    if (!settings.espEnabled) return

    AndroidView(
        modifier = modifier,
        factory = { ctx -> EspCanvasView(ctx).apply { render3DArenaGrid = renderGrid; customElementsList = elements } },
        update = { view -> view.render3DArenaGrid = renderGrid; view.customElementsList = elements }
    )
}
