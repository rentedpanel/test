package com.memorylab.mods.offsets

/**
 * Camera & 3D Projection Offsets from Unity Engine.
 * Line limit: < 150 lines.
 */
object CameraOffsets {
    const val GET_MAIN_RVA: Long = 0x0A7EE7F0L
    const val GET_MAIN_OFFSET: Long = 0x0A7EA7F0L
    const val GET_CURRENT_RVA: Long = 0x0A7EE818L
    const val GET_CURRENT_OFFSET: Long = 0x0A7EA818L
    const val GET_WORLD_TO_CAMERA_MATRIX_RVA: Long = 0x0A7EDE5CL
    const val GET_WORLD_TO_CAMERA_MATRIX_OFFSET: Long = 0x0A7E9E5CL
    const val GET_PROJECTION_MATRIX_RVA: Long = 0x0A7EDF94L
    const val GET_PROJECTION_MATRIX_OFFSET: Long = 0x0A7E9F94L
    const val WORLD_TO_SCREEN_POINT_RVA: Long = 0x0A7EE474L
    const val WORLD_TO_SCREEN_POINT_OFFSET: Long = 0x0A7EA474L
    const val SCREEN_GET_WIDTH_RVA: Long = 0x0A7FC138L
    const val SCREEN_GET_WIDTH_OFFSET: Long = 0x0A7F8138L
    const val SCREEN_GET_HEIGHT_RVA: Long = 0x0A7FC160L
    const val SCREEN_GET_HEIGHT_OFFSET: Long = 0x0A7F8160L
}
