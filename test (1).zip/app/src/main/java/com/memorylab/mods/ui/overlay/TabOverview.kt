package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.*
import com.memorylab.mods.engine.*
import com.memorylab.mods.config.GameConfig
import com.memorylab.mods.ui.theme.TextPrimary
import com.memorylab.mods.ui.theme.TextSecondary

/**
 * Overview tab inside floating menu.
 * Line limit: < 150 lines.
 */
@Composable
fun TabOverview(
    sessionState: SessionState,
    metrics: PerformanceMetrics,
    connectionState: ConnectionState,
    onToggleEngine: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentPkg = GameConfig.currentPackage.value
    val currentName = GameConfig.currentGameName.value

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(6.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors   = CardDefaults.cardColors(containerColor = MockupCardBg),
            shape    = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                Text("SELECTED APPLICATION", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = currentName.ifEmpty { "No App Selected" },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                Text(
                    text = currentPkg.ifEmpty { "Select app in dashboard" },
                    fontSize = 9.sp,
                    color = MockupAccentPurple,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors   = CardDefaults.cardColors(containerColor = MockupCardBg),
            shape    = RoundedCornerShape(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ENGINE PERFORMANCE", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                    Text("${metrics.fps.toInt()} FPS", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = MockupStatusGreen)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("FRAME TIME", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                    Text(String.format("%.1f ms", metrics.frameRenderTimeMs), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            }
        }

        Button(
            onClick  = onToggleEngine,
            modifier = Modifier.fillMaxWidth().height(30.dp),
            contentPadding = PaddingValues(0.dp),
            colors   = ButtonDefaults.buttonColors(
                containerColor = if (sessionState == SessionState.RUNNING) Color(0xFFFF5252) else MockupAccentPurple
            ),
            shape    = RoundedCornerShape(8.dp)
        ) {
            Icon(
                if (sessionState == SessionState.RUNNING) Icons.Default.Stop else Icons.Default.PlayArrow,
                null,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                if (sessionState == SessionState.RUNNING) "Stop Engine" else "Start Engine",
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
    }
}
