package com.memorylab.mods.ui.diagnostics

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.AccentCyan
import com.memorylab.mods.ui.theme.HealthGreen
import com.memorylab.mods.ui.theme.TextPrimary
import com.memorylab.mods.ui.theme.TextSecondary

/**
 * Diagnostic status list item row.
 * Line limit: < 150 lines.
 */
@Composable
fun DiagnosticItem(
    label: String,
    status: String,
    isOk: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier          = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector        = if (isOk) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint               = if (isOk) HealthGreen else AccentCyan,
            modifier           = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(status, fontSize = 10.sp, color = TextSecondary)
        }
    }
}
