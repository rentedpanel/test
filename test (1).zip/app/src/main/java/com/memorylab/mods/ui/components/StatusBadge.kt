package com.memorylab.mods.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.HealthGreen

/**
 * Compact Material Design 3 Status Badge/Chip component.
 * Displays installation state, PID indicators, or system permission alerts.
 */
@Composable
fun StatusBadge(
    text: String,
    textColor: Color,
    backgroundColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(backgroundColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text       = text,
            fontSize   = 9.sp,
            fontWeight = FontWeight.Bold,
            color      = textColor
        )
    }
}

@Composable
fun InstalledBadge(isInstalled: Boolean, modifier: Modifier = Modifier) {
    StatusBadge(
        text            = if (isInstalled) "✓ INSTALLED" else "NOT FOUND",
        textColor       = if (isInstalled) HealthGreen else Color(0xFFFFA502),
        backgroundColor = if (isInstalled) HealthGreen.copy(alpha = 0.15f) else Color(0xFFFFA502).copy(alpha = 0.15f),
        modifier        = modifier
    )
}

@Composable
fun PidBadge(pid: Int, modifier: Modifier = Modifier) {
    StatusBadge(
        text            = "PID $pid",
        textColor       = Color(0xFF00E5FF),
        backgroundColor = Color(0xFF00E5FF).copy(alpha = 0.15f),
        modifier        = modifier
    )
}
