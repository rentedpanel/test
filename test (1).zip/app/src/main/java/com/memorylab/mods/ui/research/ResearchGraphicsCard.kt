package com.memorylab.mods.ui.research

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.*

/**
 * Graphics & FPS preferences card for research screen.
 * Line limit: < 150 lines.
 */
@Composable
fun ResearchGraphicsCard(
    selectedFpsMode: Int,
    onFpsChange: (Int) -> Unit,
    hardwareSyncEnabled: Boolean,
    onHardwareSyncChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = DarkSurface),
        shape    = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("GRAPHICS & FPS PROFILE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AccentCyan)
            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60, 90, 120).forEach { fps ->
                    FilterChip(
                        selected = selectedFpsMode == fps,
                        onClick  = { onFpsChange(fps) },
                        label    = { Text("${fps} FPS", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AccentPurple,
                            selectedLabelColor     = androidx.compose.ui.graphics.Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Column {
                    Text("Hardware Vsync", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Text("Synchronize with device refresh rate", fontSize = 10.sp, color = TextSecondary)
                }
                Switch(
                    checked         = hardwareSyncEnabled,
                    onCheckedChange = onHardwareSyncChange,
                    colors          = SwitchDefaults.colors(checkedThumbColor = androidx.compose.ui.graphics.Color.Black, checkedTrackColor = HealthGreen)
                )
            }
        }
    }
}
