package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.AccentCyan
import com.memorylab.mods.ui.theme.TextPrimary
import com.memorylab.mods.ui.theme.TextSecondary

/**
 * Top header of the bottom sheet overlay controls.
 * Line limit: < 150 lines.
 */
@Composable
fun SheetHeader(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier              = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text          = "GAMING ASSISTANT & HUD MENU",
                fontSize      = 11.sp,
                fontWeight    = FontWeight.Bold,
                color         = AccentCyan,
                letterSpacing = 1.2.sp
            )
            Text(
                text       = "Visual & HUD Controls",
                fontSize   = 18.sp,
                fontWeight = FontWeight.Bold,
                color      = TextPrimary
            )
        }
        IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
        }
    }
}
