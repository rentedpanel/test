package com.memorylab.mods.ui.visuals

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.memorylab.mods.*
import com.memorylab.mods.engine.*
import com.memorylab.mods.ui.theme.AccentCyan

/**
 * 3D Interactive Canvas Area for Visuals Studio.
 * Line limit: < 150 lines.
 */
@Composable
fun VisualStudioCanvas(
    snapshot: ResearchSceneSnapshot,
    sessionState: SessionState,
    metrics: PerformanceMetrics,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF0C0C12))
            .pointerInput(Unit) {
                detectDragGestures { _, dragAmount ->
                    SimulationEngine.cameraYaw   = (SimulationEngine.cameraYaw + dragAmount.x * 0.35f) % 360f
                    SimulationEngine.cameraPitch = (SimulationEngine.cameraPitch - dragAmount.y * 0.25f).coerceIn(-65f, 65f)
                    SimulationEngine.updateCameraMatrix()
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory  = { ctx -> EspCanvasView(ctx).apply { render3DArenaGrid = true } }
        )

        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .background(Color(0xCC121218), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text       = "FPS: ${metrics.fps.toInt()}  |  Entities: ${snapshot.entities.size}  |  Yaw: ${SimulationEngine.cameraYaw.toInt()}°",
                fontSize   = 11.sp,
                color      = AccentCyan,
                fontWeight = FontWeight.Medium
            )
        }

        if (sessionState == SessionState.STOPPED) {
            Button(
                onClick  = { SimulationEngine.startSession() },
                modifier = Modifier.align(Alignment.Center),
                colors   = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Start Research Simulation")
            }
        }
    }
}
