package com.memorylab.mods.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.memorylab.mods.OperationLog
import com.memorylab.mods.SimulationEngine
import com.memorylab.mods.config.GameConfig

/**
 * Android IPC Receiver to listen for simulation data broadcasts.
 * Line limit: < 150 lines.
 */
class SimulationDataReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            GameConfig.ACTION_PING_SIMULATION,
            GameConfig.FALLBACK_ACTION_PING_SIMULATION -> {
                OperationLog.info("IPC", "Simulation provider ping received for ${GameConfig.activeName}")
            }
            GameConfig.ACTION_SIMULATION_DATA,
            GameConfig.FALLBACK_ACTION_SIMULATION_DATA -> {
                val entityFloats = intent.getFloatArrayExtra("ENTITY_DATA")
                val cameraFloats = intent.getFloatArrayExtra("CAMERA_DATA")
                val entityCount  = intent.getIntExtra("ENTITY_COUNT", 0)

                if (entityFloats != null && entityFloats.isNotEmpty()) {
                    SimulationEngine.processExternalBroadcast(entityFloats, cameraFloats, entityCount)
                } else {
                    OperationLog.info("IPC", "Simulation data stream received from ${GameConfig.activeName} (empty payload)")
                }
            }
        }
    }
}
