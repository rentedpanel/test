package com.memorylab.mods.root

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Premium Magisk-style Live System Root Checker Card with animated verification state.
 */
@Composable
fun RootEngineCard(
    isRootGranted: Boolean,
    activeEngineName: String,
    onGrantSuClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var isChecking by remember { mutableStateOf(false) }

    // Infinite rotation animation for checking state
    val infiniteTransition = rememberInfiniteTransition(label = "root_check")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isRootGranted) HealthGreen.copy(alpha = 0.4f) else Color(0xFFFFA502).copy(alpha = 0.4f),
                RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.elevatedCardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Section: Animated Left Icon & Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Left Animated Circular Icon
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .background(
                                color = when {
                                    isChecking -> AccentCyan.copy(alpha = 0.2f)
                                    isRootGranted -> HealthGreen.copy(alpha = 0.2f)
                                    else -> Color(0xFFFF5252).copy(alpha = 0.2f)
                                },
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        val iconModifier = if (isChecking) Modifier.rotate(rotation).size(26.dp) else Modifier.size(26.dp)
                        Icon(
                            imageVector = when {
                                isChecking -> Icons.Default.Refresh
                                isRootGranted -> Icons.Default.CheckCircle
                                else -> Icons.Default.Close
                            },
                            contentDescription = null,
                            tint = when {
                                isChecking -> AccentCyan
                                isRootGranted -> HealthGreen
                                else -> Color(0xFFFF5252)
                            },
                            modifier = iconModifier
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "System Root Checker",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                        Text(
                            text = when {
                                isChecking -> "Verifying Superuser Binaries..."
                                isRootGranted -> "Device is Properly Rooted ✓"
                                else -> "Device is Not Rooted / SU Denied"
                            },
                            fontSize = 12.sp,
                            color = when {
                                isChecking -> AccentCyan
                                isRootGranted -> HealthGreen
                                else -> Color(0xFFFF5252)
                            }
                        )
                    }
                }
            }

            // Bottom Status Summary & Check Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "ROOT PRIVILEGE STATUS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (isRootGranted) "SU Binary Active ($activeEngineName)" else "No Root Shell Access Detected",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isRootGranted) HealthGreen else TextPrimary
                    )
                }

                Button(
                    onClick = {
                        if (!isChecking) {
                            scope.launch {
                                isChecking = true
                                delay(1200) // Simulate thorough system check animation
                                onGrantSuClick()
                                isChecking = false
                            }
                        }
                    },
                    enabled = !isChecking,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRootGranted) HealthGreen.copy(alpha = 0.2f) else Color(0xFFFFA502),
                        contentColor = if (isRootGranted) HealthGreen else Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = if (isChecking) Icons.Default.Refresh else if (isRootGranted) Icons.Default.CheckCircle else Icons.Default.Security,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp).let { if (isChecking) it.rotate(rotation) else it },
                        tint = if (isRootGranted) HealthGreen else Color.Black
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isChecking) "Checking..." else if (isRootGranted) "Re-Verify" else "Check Root",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
