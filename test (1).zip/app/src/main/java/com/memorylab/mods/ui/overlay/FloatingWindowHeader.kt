package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.theme.TextPrimary

/**
 * Top title & drag header bar for the floating window menu.
 * Line limit: < 150 lines.
 */
@Composable
fun FloatingWindowHeader(
    title: String,
    onToggleSidebar: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    onDragDelta: ((Float, Float) -> Unit)?,
    onLocalDrag: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(34.dp)
            .background(MockupSidebarBg)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    if (onDragDelta != null) {
                        onDragDelta(dragAmount.x, dragAmount.y)
                    } else {
                        onLocalDrag(dragAmount.x, dragAmount.y)
                    }
                }
            }
            .padding(horizontal = 8.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f, fill = false),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector        = Icons.Default.Menu,
                contentDescription = "Toggle Sidebar",
                tint               = MockupAccentPurple,
                modifier           = Modifier
                    .size(26.dp)
                    .clickable { onToggleSidebar() }
                    .padding(4.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text       = title,
                fontSize   = 11.sp,
                fontWeight = FontWeight.Bold,
                color      = TextPrimary,
                maxLines   = 1,
                overflow   = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Box(
                modifier         = Modifier
                    .size(20.dp)
                    .background(Color.White.copy(alpha = 0.08f), CircleShape)
                    .clickable { onMinimize() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Minimize, contentDescription = "Minimize", tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(10.dp))
            }

            Box(
                modifier         = Modifier
                    .size(20.dp)
                    .background(Color(0xFFFF5252).copy(alpha = 0.2f), CircleShape)
                    .clickable { onClose() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close Floating Menu", tint = Color(0xFFFF5252), modifier = Modifier.size(12.dp))
            }
        }
    }
}
