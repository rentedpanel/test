package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.CrosshairStyle
import com.memorylab.mods.EspController
import com.memorylab.mods.ui.components.AppSleekSlider
import com.memorylab.mods.ui.theme.TextPrimary
import com.memorylab.mods.ui.theme.TextSecondary

/**
 * Targeting & Aim Crosshair tab inside floating menu.
 * Contains 4 single-selection aim options and size seekbar slider.
 * Line limit: < 150 lines.
 */
@Composable
fun TabTargeting(modifier: Modifier = Modifier) {
    val settings by EspController.settings.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(6.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text("CENTER AIM RETICLE OPTIONS", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MockupAccentPurple)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors   = CardDefaults.cardColors(containerColor = MockupCardBg),
            shape    = RoundedCornerShape(6.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                Text("Select Reticle Style", fontSize = 9.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(3.dp))

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    val entries = CrosshairStyle.entries
                    val row1 = entries.take(2)
                    val row2 = entries.drop(2)

                    listOf(row1, row2).forEach { rowStyles ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            rowStyles.forEach { style ->
                                val isSelected = settings.crosshairStyle == style
                                FilterChip(
                                    selected = isSelected,
                                    onClick  = { EspController.setCrosshairStyle(style) },
                                    label    = {
                                        Text(
                                            text = style.displayName,
                                            fontSize = 8.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            maxLines = 1,
                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                        )
                                    },
                                    colors   = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MockupAccentPurple,
                                        selectedLabelColor     = androidx.compose.ui.graphics.Color.White,
                                        containerColor          = MockupWindowBg,
                                        labelColor              = TextPrimary
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                HorizontalDivider(color = MockupTrackOff)
                Spacer(modifier = Modifier.height(4.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Aim Reticle Size (Scale)", fontSize = 9.sp, color = TextPrimary)
                    Text("${settings.crosshairSize.toInt()} px", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MockupAccentPurple)
                }

                AppSleekSlider(
                    value              = settings.crosshairSize,
                    onValueChange      = { EspController.setCrosshairSize(it) },
                    valueRange         = 6f..40f,
                    activeTrackColor   = MockupAccentPurple,
                    inactiveTrackColor = MockupTrackOff,
                    thumbColor         = MockupAccentPurple
                )
            }
        }

        Text("FOV & RANGE CONFIGURATION", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MockupAccentPurple)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors   = CardDefaults.cardColors(containerColor = MockupCardBg),
            shape    = RoundedCornerShape(6.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Field of View (FOV)", fontSize = 9.sp, color = TextPrimary)
                    Text("${settings.maxDistance.toInt()}m", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MockupAccentPurple)
                }
                AppSleekSlider(
                    value              = settings.maxDistance,
                    onValueChange      = { EspController.setMaxDistance(it) },
                    valueRange         = 50f..500f,
                    activeTrackColor   = MockupAccentPurple,
                    inactiveTrackColor = MockupTrackOff,
                    thumbColor         = MockupAccentPurple
                )
            }
        }
    }
}

