package com.memorylab.mods.ui.overlay

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.EspController
import com.memorylab.mods.TracerOrigin
import com.memorylab.mods.ui.theme.TextPrimary
import com.memorylab.mods.ui.theme.TextSecondary

/**
 * Visuals tab inside floating menu (Boxes, Lines, Names, Health, Distance, Snapline Origin).
 * Line limit: < 150 lines.
 */
@Composable
fun TabVisuals(modifier: Modifier = Modifier) {
    val settings by EspController.settings.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(6.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text("2D SPATIAL OVERLAY ELEMENTS", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MockupAccentPurple)

        VisualToggleRow("2D Bounding Boxes", settings.showBoundingBox) { EspController.setBoundingBox(it) }
        VisualToggleRow("Snapline (Tracers)", settings.showTracerLine) { EspController.setTracerLine(it) }
        VisualToggleRow("Health (HP) Bars", settings.showHpBar) { EspController.setHpBar(it) }
        VisualToggleRow("Distance Labels", settings.showDistance) { EspController.setDistance(it) }

        Spacer(modifier = Modifier.height(2.dp))
        Text("SNAPLINE ORIGIN POSITION", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MockupAccentPurple)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TracerOrigin.entries.forEach { origin ->
                val isSelected = settings.tracerOrigin == origin
                FilterChip(
                    selected = isSelected,
                    onClick  = { EspController.setTracerOrigin(origin) },
                    label    = { Text(origin.displayName, fontSize = 8.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MockupAccentPurple,
                        selectedLabelColor     = androidx.compose.ui.graphics.Color.White,
                        containerColor          = MockupCardBg,
                        labelColor              = TextPrimary
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun VisualToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = MockupCardBg),
        shape    = RoundedCornerShape(6.dp)
    ) {
        Row(
            modifier              = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Text(title, fontSize = 10.sp, color = TextPrimary)
            Switch(
                checked         = checked,
                onCheckedChange = onCheckedChange,
                modifier        = Modifier.scale(0.65f),
                colors          = SwitchDefaults.colors(
                    checkedThumbColor   = MockupAccentPurple,
                    checkedTrackColor   = MockupTrackPurple.copy(alpha = 0.4f),
                    uncheckedThumbColor = MockupThumbOff,
                    uncheckedTrackColor = MockupTrackOff
                )
            )
        }
    }
}

