package com.memorylab.mods.engine

import com.memorylab.mods.*
import kotlin.math.cos
import kotlin.math.sin

/**
 * Utility class to generate synthetic FPS entities in a circular arena with 3D skeletons.
 * Line limit: < 150 lines.
 */
object SyntheticSceneGenerator {

    fun generate(time: Float, targetCount: Int, cameraPos: Vec3): List<ArenaEntity> {
        val list = mutableListOf<ArenaEntity>()

        for (i in 0 until targetCount) {
            val baseAngle    = (i.toFloat() / targetCount) * (2f * Math.PI.toFloat())
            val currentAngle = baseAngle + sin(time * 0.5f + i) * 0.4f
            val radius       = 5.5f + sin(time * 0.8f + i * 1.5f) * 2.2f
            val posX         = sin(currentAngle) * radius
            val posZ         = cos(currentAngle) * radius
            val posY         = 0f

            val walkBob  = sin(time * 3f + i) * 0.05f
            val footY    = posY
            val headY    = posY + 1.8f + walkBob
            val pelvisY  = posY + 0.95f + walkBob
            val neckY    = posY + 1.55f + walkBob
            val spineY   = posY + 1.25f + walkBob

            val worldPos = Vec3(posX, posY, posZ)
            val headPos  = Vec3(posX, headY, posZ)
            val footPos  = Vec3(posX, footY, posZ)

            val maxHp = 100f
            val hp    = (75f + sin(time * 0.4f + i * 2f) * 25f).coerceIn(10f, 100f)
            val team  = if (i % 2 == 0) TeamCategory.ALPHA else TeamCategory.BRAVO
            val isVis = (i % 4 != 0)

            val entity = ArenaEntity(
                id = 101 + i, name = if (team == TeamCategory.ALPHA) "ALPHA-0${i + 1}" else "BRAVO-0${i + 1}",
                worldPos = worldPos, headPos = headPos, footPos = footPos,
                health = hp, maxHealth = maxHp, team = team, isVisible = isVis, distance = cameraPos.distanceTo(worldPos),
                animationPhase = time + i
            )

            if (entity.isValid()) list.add(entity)
        }

        return list.sortedBy { it.distance }
    }
}
