package com.memorylab.mods

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.memorylab.mods.config.GameConfig
import com.memorylab.mods.main.MainAppContent
import com.memorylab.mods.service.OverlayController
import com.memorylab.mods.ui.theme.MemoryLabTheme

/**
 * Main Android Activity for MemoryLab Pro.
 * Line limit: < 150 lines.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { enableEdgeToEdge() } catch (_: Exception) {}

        try {
            GameConfig.init(applicationContext)
            NativeRootMemory.initLogger(applicationContext)
            EspController.init(applicationContext)
            SimulationEngine.startSession()
        } catch (_: Exception) {}

        val openSheetFromIntent = intent?.getBooleanExtra("OPEN_OVERLAY_SHEET", false) ?: false

        setContent {
            MemoryLabTheme {
                MainAppContent()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!OverlayController.isServiceRunning.value) {
            SimulationEngine.stopSession()
        }
    }
}
