package com.memorylab.mods

import android.opengl.Matrix

/**
 * 3D Vector for world coordinates, entity positions, and camera calculations.
 */
data class Vec3(
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f
) {
    operator fun plus(other: Vec3): Vec3 = Vec3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vec3): Vec3 = Vec3(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Float): Vec3 = Vec3(x * scalar, y * scalar, z * scalar)
    operator fun div(scalar: Float): Vec3 = if (scalar != 0f) Vec3(x / scalar, y / scalar, z / scalar) else Vec3()

    fun length(): Float = kotlin.math.sqrt(x * x + y * y + z * z)
    fun distanceTo(other: Vec3): Float = (this - other).length()

    fun normalized(): Vec3 {
        val len = length()
        return if (len > 0.0001f) this / len else Vec3(0f, 0f, 0f)
    }

    fun dot(other: Vec3): Float = x * other.x + y * other.y + z * other.z

    fun cross(other: Vec3): Vec3 = Vec3(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x
    )

    fun isValid(): Boolean =
        !x.isNaN() && !y.isNaN() && !z.isNaN() &&
        !x.isInfinite() && !y.isInfinite() && !z.isInfinite()
}

/**
 * 4D Homogeneous vector for clip space and perspective division.
 */
data class Vec4(
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f,
    val w: Float = 1f
) {
    fun toVec3(): Vec3 = if (w != 0f && !w.isNaN()) Vec3(x / w, y / w, z / w) else Vec3(x, y, z)

    fun isValid(): Boolean =
        !x.isNaN() && !y.isNaN() && !z.isNaN() && !w.isNaN() &&
        !x.isInfinite() && !y.isInfinite() && !z.isInfinite() && !w.isInfinite()
}

/**
 * Standard 4x4 OpenGL Matrix wrapper leveraging Android's official android.opengl.Matrix API.
 * Eliminates custom handwritten multiplication and projection algorithms.
 */
class Mat4(val data: FloatArray = FloatArray(16)) {

    init {
        require(data.size == 16) { "Mat4 data must be exactly 16 elements" }
    }

    operator fun get(index: Int): Float = data[index]
    operator fun get(row: Int, col: Int): Float = data[col * 4 + row]

    fun copy(): Mat4 = Mat4(data.copyOf())

    /**
     * Transforms a 3D point using standard Android OpenGL vector multiplication: Matrix.multiplyMV
     */
    fun transform(v: Vec3): Vec4 {
        val inVec = floatArrayOf(v.x, v.y, v.z, 1.0f)
        val outVec = FloatArray(4)
        Matrix.multiplyMV(outVec, 0, data, 0, inVec, 0)
        return Vec4(outVec[0], outVec[1], outVec[2], outVec[3])
    }

    /**
     * Matrix multiplication using standard Android OpenGL Matrix.multiplyMM
     */
    operator fun times(other: Mat4): Mat4 {
        val result = FloatArray(16)
        Matrix.multiplyMM(result, 0, this.data, 0, other.data, 0)
        return Mat4(result)
    }

    companion object {
        fun identity(): Mat4 {
            val m = FloatArray(16)
            Matrix.setIdentityM(m, 0)
            return Mat4(m)
        }

        fun createLookAt(eye: Vec3, target: Vec3, up: Vec3 = Vec3(0f, 1f, 0f)): Mat4 {
            val m = FloatArray(16)
            Matrix.setLookAtM(
                m, 0,
                eye.x, eye.y, eye.z,
                target.x, target.y, target.z,
                up.x, up.y, up.z
            )
            return Mat4(m)
        }

        fun createPerspective(
            fovYDegrees: Float,
            aspectRatio: Float,
            near: Float = 0.1f,
            far: Float = 500f
        ): Mat4 {
            val m = FloatArray(16)
            Matrix.perspectiveM(m, 0, fovYDegrees, aspectRatio, near, far)
            return Mat4(m)
        }
    }
}
