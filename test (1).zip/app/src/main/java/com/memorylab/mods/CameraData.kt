package com.memorylab.mods

/**
 * FPS research camera model containing position, orientation, matrices, and viewport.
 */
data class CameraData(
    val position: Vec3 = Vec3(0f, 1.7f, -12f),
    val target: Vec3 = Vec3(0f, 1.2f, 0f),
    val up: Vec3 = Vec3(0f, 1f, 0f),
    val yawDegrees: Float = 0f,
    val pitchDegrees: Float = 0f,
    val fovDegrees: Float = 70f,
    val viewMatrix: Mat4 = Mat4.identity(),
    val projMatrix: Mat4 = Mat4.identity(),
    val viewportWidth: Float = 1080f,
    val viewportHeight: Float = 1920f,
    val timestamp: Long = System.currentTimeMillis()
)
