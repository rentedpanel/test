package com.memorylab.mods.service

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.memorylab.mods.FloatingOverlayService
import com.memorylab.mods.OperationLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Global controller for overlay permissions, state, and foreground service lifecycle.
 * Line limit: < 150 lines.
 */
object OverlayController {
    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _isOverlayExpanded = MutableStateFlow(false)
    val isOverlayExpanded: StateFlow<Boolean> = _isOverlayExpanded.asStateFlow()

    fun canDrawOverlays(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else true
        } catch (_: Exception) { false }
    }

    fun requestOverlayPermissionIntent(context: Context): Intent {
        return Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
    }

    fun openOverlaySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallbackIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
            } catch (_: Exception) {}
        }
    }

    fun startOverlayService(context: Context) {
        try {
            val intent = Intent(context, FloatingOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            _isServiceRunning.value = true
        } catch (e: Exception) {
            OperationLog.error("Overlay", "Failed to start service: ${e.message}")
            _isServiceRunning.value = false
        }
    }

    fun stopOverlayService(context: Context) {
        try {
            val intent = Intent(context, FloatingOverlayService::class.java)
            context.stopService(intent)
        } catch (e: Exception) {
            OperationLog.error("Overlay", "Failed to stop service: ${e.message}")
        } finally {
            _isServiceRunning.value = false
        }
    }

    internal fun setServiceState(running: Boolean) {
        _isServiceRunning.value = running
    }

    fun toggleOverlayExpanded() {
        _isOverlayExpanded.value = !_isOverlayExpanded.value
    }
}
