package com.memorylab.mods

import android.os.Build

/**
 * JNI bridge and native library lifecycle controller for MemoryLab Pro.
 * Line limit: < 150 lines.
 */
object NativeMemory {

    private var isNativeLoaded: Boolean = false
    private var loadError: String? = null

    init {
        try {
            System.loadLibrary("memorylab_native")
            isNativeLoaded = true
        } catch (e: UnsatisfiedLinkError) {
            isNativeLoaded = false
            loadError = e.message ?: "Native library not pre-linked in host environment"
        } catch (t: Throwable) {
            isNativeLoaded = false
            loadError = t.message
        }
    }

    fun isLoaded(): Boolean = isNativeLoaded

    fun getStatusSummary(): String {
        return if (isNativeLoaded) {
            "Native C++17 Core Active (ABI: ${Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"})"
        } else {
            "Native Emulated / Pure-Math Engine Active (${loadError ?: "Fallback Mode"})"
        }
    }

    fun initializeLab(): NativeResult<Boolean> {
        return if (isNativeLoaded) {
            try {
                val ok = nativeInitializeLab()
                NativeResult.ok(ok, "Native C++17 laboratory core initialized")
            } catch (t: Throwable) {
                NativeResult.error(101, "JNI invocation failure: ${t.message}")
            }
        } else {
            NativeResult.ok(true, "Pure-math engine initialized (host environment fallback)")
        }
    }

    fun getVersion(): String {
        return if (isNativeLoaded) {
            try { nativeGetVersion() } catch (t: Throwable) { "MemoryLab Pro C++17 Core (JNI fallback)" }
        } else {
            "MemoryLab Pro Pure Math Core (Kotlin/JVM Engine)"
        }
    }

    // Native external declarations
    @JvmStatic external fun nativeGetVersion(): String
    @JvmStatic external fun nativeInitializeLab(): Boolean
    @JvmStatic external fun nativeUpdateSimulationStep(deltaSec: Float, targetCount: Int, camYaw: Float, camPitch: Float, camDist: Float, camFov: Float, aspect: Float): Int
    @JvmStatic external fun nativeGetEntityCount(): Int
    @JvmStatic external fun nativeGetLiveEntities(outBuffer: FloatArray): Int
    @JvmStatic external fun nativeGetCameraMatrices(outViewMatrix: FloatArray, outProjMatrix: FloatArray): Boolean
    @JvmStatic external fun nativeProjectWorldToScreen(worldX: Float, worldY: Float, worldZ: Float, viewMat: FloatArray, projMat: FloatArray, screenWidth: Int, screenHeight: Int, outCoords: FloatArray): Boolean
    @JvmStatic external fun nativeAttachLiveProcess(packageName: String): Int
    @JvmStatic external fun nativeReadLiveFrame(outBuffer: FloatArray): Int
    @JvmStatic external fun nativeDetachLiveProcess()
    @JvmStatic external fun nativeGetLiveState(): Int
}
