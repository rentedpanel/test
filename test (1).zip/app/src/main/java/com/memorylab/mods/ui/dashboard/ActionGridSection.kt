package com.memorylab.mods.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memorylab.mods.ui.components.ActionCardButton
import com.memorylab.mods.ui.theme.TextPrimary

/**
 * Navigation grid section displaying quick-access research module cards.
 * Line limit: < 150 lines.
 */
@Composable
fun ActionGridSection(
    onNavigateTo: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text       = "Research & Telemetry Modules",
            fontSize   = 16.sp,
            fontWeight = FontWeight.Bold,
            color      = TextPrimary,
            modifier   = Modifier.padding(bottom = 12.dp)
        )

        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionCardButton(
                title    = "ESP Lab",
                subtitle = "Spatial Overlay & 2D Bounds",
                icon     = Icons.Default.Visibility,
                onClick  = { onNavigateTo("esp_lab") },
                modifier = Modifier.weight(1f)
            )
            ActionCardButton(
                title    = "IL2CPP Hub",
                subtitle = "Metadata & Offset Scanner",
                icon     = Icons.Default.Code,
                onClick  = { onNavigateTo("il2cpp_research") },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionCardButton(
                title    = "Diagnostics",
                subtitle = "Native Memory & Syscall Audit",
                icon     = Icons.Default.Assessment,
                onClick  = { onNavigateTo("diagnostics") },
                modifier = Modifier.weight(1f)
            )
            ActionCardButton(
                title    = "Performance",
                subtitle = "FPS & Frame Timings",
                icon     = Icons.Default.Speed,
                onClick  = { onNavigateTo("performance") },
                modifier = Modifier.weight(1f)
            )
        }
    }
}
