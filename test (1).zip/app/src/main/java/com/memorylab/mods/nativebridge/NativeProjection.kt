package com.memorylab.mods.nativebridge

import com.memorylab.mods.*

/**
 * Native projection helper with high-performance pure-math fallback.
 * Line limit: < 150 lines.
 */
object NativeProjection {

    private val reusableOutCoords = FloatArray(3)

    fun project(
        worldPos: Vec3,
        viewMatrix: Mat4,
        projMatrix: Mat4,
        screenWidth: Int,
        screenHeight: Int
    ): ScreenPoint? {
        if (NativeMemory.isLoaded()) {
            try {
                val success = NativeMemory.nativeProjectWorldToScreen(
                    worldPos.x, worldPos.y, worldPos.z,
                    viewMatrix.data, projMatrix.data,
                    screenWidth, screenHeight,
                    reusableOutCoords
                )
                if (success) {
                    return ScreenPoint(reusableOutCoords[0], reusableOutCoords[1], reusableOutCoords[2])
                }
                return null
            } catch (_: Throwable) {}
        }
        return Projection.worldToScreen(
            worldPos, viewMatrix, projMatrix, screenWidth.toFloat(), screenHeight.toFloat()
        )
    }
}
