package com.memorylab.mods.view

import android.graphics.Color

/**
 * Dynamic 2D Coordinate Data Item for ESP overlay rendering.
 * Line limit: < 150 lines.
 */
data class EspRenderElement(
    val id: Int = 0,
    val left: Float = 0f,
    val top: Float = 0f,
    val right: Float = 0f,
    val bottom: Float = 0f,
    val label: String = "",
    val teamColor: Int = Color.CYAN,
    val tracerFromX: Float? = null,
    val tracerFromY: Float? = null
)
