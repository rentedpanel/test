package com.memorylab.mods.offsets

/**
 * Entity & Transform Offsets for Bounding Box & Coordinates.
 * Line limit: < 150 lines.
 */
object TransformOffsets {
    const val COMPONENT_GET_TRANSFORM_RVA: Long = 0x0A8357B8L
    const val COMPONENT_GET_TRANSFORM_OFFSET: Long = 0x0A8317B8L
    const val TRANSFORM_GET_POSITION_RVA: Long = 0x0A843A30L
    const val TRANSFORM_GET_POSITION_OFFSET: Long = 0x0A83FA30L
    const val TRANSFORM_GET_ROTATION_RVA: Long = 0x0A843C20L
    const val TRANSFORM_GET_ROTATION_OFFSET: Long = 0x0A83FC20L
    const val TRANSFORM_GET_FORWARD_RVA: Long = 0x0A844008L
    const val TRANSFORM_GET_FORWARD_OFFSET: Long = 0x0A840008L
    const val ENTITY_CACHED_TRANSFORM_OFFSET: Long = 0x58L
    const val ENTITY_UNIQUE_ID_OFFSET: Long = 0x60L
    const val ENTITY_GET_POSITION_RVA: Long = 0x08216BDCL
    const val ENTITY_GET_POSITION_OFFSET: Long = 0x08212BDCL
    const val ENTITY_GET_FORWARD_RVA: Long = 0x08216DACL
    const val ENTITY_GET_FORWARD_OFFSET: Long = 0x08212DACL
}
