package com.memorylab.mods.main

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.memorylab.mods.NativeRootMemory
import com.memorylab.mods.config.GameConfig
import com.memorylab.mods.nav.RootStatusBanner
import com.memorylab.mods.root.RootShellController
import com.memorylab.mods.service.OverlayController
import com.memorylab.mods.ui.*
import com.memorylab.mods.ui.theme.*
import kotlinx.coroutines.launch

/**
 * Main Application Layout featuring official Material 3 Navigation Drawer (Sidebar)
 * with a top header bar and hamburger menu icon on the top left.
 * Line count strictly <= 150 lines.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent() {
    val context = LocalContext.current
    val scope   = rememberCoroutineScope()
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }
    var showPermissionDialog by remember { mutableStateOf(false) }
    var pendingStartOverlay by remember { mutableStateOf(false) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val isServiceRunning by OverlayController.isServiceRunning.collectAsState()
    val isRootGranted    by RootShellController.isRootGranted.collectAsState()
    val targetPackage    by GameConfig.currentPackage.collectAsState()

    var targetPid by remember(targetPackage) {
        mutableStateOf(try { NativeRootMemory.nativeFindProcessPid(targetPackage).takeIf { it > 0 } } catch (_: Throwable) { null })
    }

    LaunchedEffect(Unit) { RootShellController.checkRootAccess() }

    val overlayPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (OverlayController.canDrawOverlays(context)) {
            OverlayController.startOverlayService(context)
            pendingStartOverlay = false
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val batteryOptimizationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(context.packageName)) {
                try {
                    val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = android.net.Uri.parse("package:${context.packageName}")
                    batteryOptimizationLauncher.launch(intent)
                } catch (_: Exception) {}
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val toggleFloatingWindow: () -> Unit = {
        if (OverlayController.canDrawOverlays(context)) {
            if (isServiceRunning) OverlayController.stopOverlayService(context)
            else OverlayController.startOverlayService(context)
        } else {
            pendingStartOverlay = true
            showPermissionDialog = true
        }
    }

    val navigationItems = listOf(Screen.Dashboard, Screen.Visuals, Screen.Engine, Screen.Metrics, Screen.Settings)

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DarkSurface,
                drawerContentColor = TextPrimary
            ) {
                Spacer(modifier = Modifier.height(28.dp))
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(if (isRootGranted) HealthGreen else Color(0xFFFFA502), androidx.compose.foundation.shape.CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "MemoryLab Pro",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                Text(
                    text = "v1.0.0-PRO • Native Engine",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = DarkSurfaceVariant)
                Spacer(modifier = Modifier.height(8.dp))

                navigationItems.forEach { screen ->
                    val selected = currentScreen.route == screen.route
                    NavigationDrawerItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title, tint = if (selected) AccentCyan else TextSecondary) },
                        label = { Text(screen.title, fontSize = 14.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, color = if (selected) AccentCyan else TextPrimary) },
                        selected = selected,
                        onClick = {
                            currentScreen = screen
                            scope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = DarkSurfaceVariant,
                            unselectedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("MemoryLab Pro", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 18.sp) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { if (drawerState.isClosed) drawerState.open() else drawerState.close() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Open Sidebar Navigation", tint = AccentCyan)
                        }
                    },
                    actions = {
                        IconButton(onClick = { /* Profile */ }) {
                            Icon(Icons.Default.AccountCircle, contentDescription = "User Profile", tint = AccentCyan)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
                )
            },
            containerColor = DarkBackground
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentScreen) {
                        is Screen.Dashboard -> DashboardScreen(onToggleFloatingWindow = toggleFloatingWindow, onNavigateTo = { r -> currentScreen = navigationItems.firstOrNull { it.route == r } ?: Screen.Dashboard })
                        is Screen.Visuals   -> EspLabScreen(onToggleFloatingWindow = toggleFloatingWindow)
                        is Screen.Engine    -> DiagnosticsScreen()
                        is Screen.Metrics   -> PerformanceScreen()
                        is Screen.Settings  -> Il2cppResearchScreen()
                    }

                    if (showPermissionDialog) {
                        AlertDialog(
                            onDismissRequest = { showPermissionDialog = false },
                            title = { Text("Display Over Other Apps Required", fontWeight = FontWeight.Bold, color = Color.White) },
                            text = { Text("Android requires 'Display over other apps' permission to render floating menu.", color = TextSecondary, fontSize = 13.sp) },
                            confirmButton = {
                                Button(onClick = {
                                    showPermissionDialog = false; pendingStartOverlay = true
                                    try { overlayPermissionLauncher.launch(OverlayController.requestOverlayPermissionIntent(context)) } catch (_: Exception) { OverlayController.openOverlaySettings(context) }
                                }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7))) { Text("Enable in Settings", color = Color.White) }
                            },
                            dismissButton = { TextButton(onClick = { showPermissionDialog = false }) { Text("Cancel", color = TextSecondary) } },
                            containerColor = Color(0xFF1E1E28)
                        )
                    }
                }
            }
        }
    }
}
