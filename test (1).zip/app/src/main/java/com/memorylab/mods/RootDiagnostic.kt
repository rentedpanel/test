package com.memorylab.mods

import android.os.Build
import java.io.File

data class RootDiagnosticReport(
    val hasRootBinary: Boolean,
    val detectedBinaryPath: String?,
    val hasSuInPath: Boolean,
    val buildTags: String,
    val isCustomSigned: Boolean,
    val isSeLinuxEnforcing: Boolean,
    val securityNotice: String
)

object RootDiagnostic {

    private val KNOWN_SU_PATHS = listOf(
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/data/local/su",
        "/su/bin/su"
    )

    fun checkSuBinary(): Boolean {
        return KNOWN_SU_PATHS.any { path ->
            try {
                File(path).exists()
            } catch (e: Exception) {
                false
            }
        }
    }

    fun generateReport(): RootDiagnosticReport {
        var foundPath: String? = null
        for (path in KNOWN_SU_PATHS) {
            try {
                if (File(path).exists()) {
                    foundPath = path
                    break
                }
            } catch (_: Exception) {}
        }

        val buildTags = Build.TAGS ?: ""
        val isCustomSigned = !buildTags.contains("release-keys")

        return RootDiagnosticReport(
            hasRootBinary = foundPath != null,
            detectedBinaryPath = foundPath,
            hasSuInPath = foundPath != null,
            buildTags = buildTags,
            isCustomSigned = isCustomSigned,
            isSeLinuxEnforcing = true, // Default safe assumption on modern Android
            securityNotice = "Notice: Root privileges are strictly optional. MemoryLab Pro's controlled simulation engine and ESP research operate entirely through standard Android application permissions and secure IPC protocols."
        )
    }
}
