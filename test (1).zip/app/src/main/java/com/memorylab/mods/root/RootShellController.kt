package com.memorylab.mods.root

import com.memorylab.mods.OperationLog
import com.memorylab.mods.RootExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * Controller managing Root shell verification & kernel direct memory access calls.
 * Line limit: < 150 lines.
 */
object RootShellController {

    private val _isRootGranted = MutableStateFlow(false)
    val isRootGranted: StateFlow<Boolean> = _isRootGranted.asStateFlow()

    private val _activeEngine = MutableStateFlow("Direct process_vm_readv")
    val activeEngine: StateFlow<String> = _activeEngine.asStateFlow()

    suspend fun checkRootAccess(): Boolean = withContext(Dispatchers.IO) {
        val granted = RootExecutor.requestRootAccess()
        _isRootGranted.value = granted
        if (granted) {
            OperationLog.success("RootShell", "Root SU privileges verified successfully")
        } else {
            OperationLog.warn("RootShell", "Root SU shell not available or permission denied")
        }
        granted
    }

    suspend fun requestSuPermission(): Boolean = withContext(Dispatchers.IO) {
        val granted = checkRootAccess()
        _isRootGranted.value = granted
        granted
    }
}
