#ifndef MEMORY_LAB_H
#define MEMORY_LAB_H

#include <jni.h>
#include <string>
#include <vector>
#include <cstdint>
#include "memory_offsets.h"
#include "il2cpp_offsets.h"
#include "root_memory_reader.h"

#define LOG_TAG "MemoryLabNative"

struct NativeLabStatus {
    bool isInitialized;
    int32_t activeEntities;
    float currentFps;
    int64_t lastTimestamp;
    std::string architecture;
    std::string buildType;
};

extern "C" {

// ── Existing Simulation-Mode JNI Exports ─────────────────────────────────────

JNIEXPORT jstring JNICALL
Java_com_memorylab_mods_NativeMemory_nativeGetVersion(JNIEnv* env, jclass clazz);

JNIEXPORT jboolean JNICALL
Java_com_memorylab_mods_NativeMemory_nativeInitializeLab(JNIEnv* env, jclass clazz);

JNIEXPORT jint JNICALL
Java_com_memorylab_mods_NativeMemory_nativeUpdateSimulationStep(
    JNIEnv* env,
    jclass clazz,
    jfloat deltaSec,
    jint targetCount,
    jfloat camYaw,
    jfloat camPitch,
    jfloat camDist,
    jfloat camFov,
    jfloat aspect
);

JNIEXPORT jint JNICALL
Java_com_memorylab_mods_NativeMemory_nativeGetEntityCount(JNIEnv* env, jclass clazz);

JNIEXPORT jint JNICALL
Java_com_memorylab_mods_NativeMemory_nativeGetLiveEntities(
    JNIEnv* env,
    jclass clazz,
    jfloatArray outBuffer
);

JNIEXPORT jboolean JNICALL
Java_com_memorylab_mods_NativeMemory_nativeGetCameraMatrices(
    JNIEnv* env,
    jclass clazz,
    jfloatArray outViewMatrix,
    jfloatArray outProjMatrix
);

// ── Live-Mode JNI Exports (Root Memory Reader Integration) ───────────────────

/**
 * Attaches to the target test process and begins structured pointer traversal.
 * @param packageName Target application package (e.g., "com.edgemake.firestrike")
 * @return ReaderState ordinal (-1=ERROR, 0-5=state levels)
 */
JNIEXPORT jint JNICALL
Java_com_memorylab_mods_NativeMemory_nativeAttachLiveProcess(
    JNIEnv* env,
    jclass clazz,
    jstring packageName
);

/**
 * Reads a single live frame from the attached process and populates the
 * shared entity buffer. Switches the engine to live-data mode automatically.
 * @return Number of entities read, or negative error code.
 */
JNIEXPORT jint JNICALL
Java_com_memorylab_mods_NativeMemory_nativeReadLiveFrame(
    JNIEnv* env,
    jclass clazz,
    jfloatArray outBuffer
);

/**
 * Detaches from the live process and returns to synthetic simulation mode.
 */
JNIEXPORT void JNICALL
Java_com_memorylab_mods_NativeMemory_nativeDetachLiveProcess(
    JNIEnv* env,
    jclass clazz
);

/**
 * Returns the current attachment state as an integer (ReaderState ordinal).
 */
JNIEXPORT jint JNICALL
Java_com_memorylab_mods_NativeMemory_nativeGetLiveState(
    JNIEnv* env,
    jclass clazz
);

}

#endif // MEMORY_LAB_H
