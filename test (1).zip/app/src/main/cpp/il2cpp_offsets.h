#ifndef IL2CPP_OFFSETS_H
#define IL2CPP_OFFSETS_H

#include <cstdint>
#include <cstddef>

/**
 * IL2CPP Runtime Structure Offsets & Game-Specific RVA Constants.
 * Line limit: < 150 lines.
 */
namespace Il2CppLayout {
    constexpr size_t kObject_Klass       = 0x00;
    constexpr size_t kObject_Monitor     = 0x08;
    constexpr size_t kObjectHeaderSize   = 0x10;

    constexpr size_t kClass_Image        = 0x00;
    constexpr size_t kClass_Name         = 0x10;
    constexpr size_t kClass_Namespace    = 0x18;
    constexpr size_t kClass_Parent       = 0x58;
    constexpr size_t kClass_Fields       = 0x80;
    constexpr size_t kClass_Methods      = 0x98;
    constexpr size_t kClass_StaticFields = 0xB8;
    constexpr size_t kClass_FieldCount   = 0x120;
    constexpr size_t kClass_InstanceSize  = 0xF4;

    constexpr size_t kDomain_Assemblies  = 0x18;
    constexpr size_t kGList_Data         = 0x00;
    constexpr size_t kGList_Next         = 0x08;
    constexpr size_t kGList_Prev         = 0x10;

    constexpr size_t kAssembly_Image     = 0x00;
    constexpr size_t kAssembly_AName     = 0x18;
    constexpr size_t kImage_Name         = 0x00;
    constexpr size_t kImage_Assembly     = 0x10;
    constexpr size_t kImage_TypeCount    = 0x18;
    constexpr size_t kImage_Token        = 0x28;

    constexpr size_t kArray_Bounds       = 0x10;
    constexpr size_t kArray_MaxLength   = 0x18;
    constexpr size_t kArray_FirstItem   = 0x20;
    constexpr size_t kString_Length      = 0x10;
    constexpr size_t kString_FirstChar   = 0x14;
    constexpr size_t kList_Items         = 0x10;
    constexpr size_t kList_Size          = 0x18;

    namespace Camera {
        constexpr uintptr_t kRVA_get_main                = 0x0A7EE7F0;
        constexpr uintptr_t kRVA_get_worldToCameraMatrix = 0x0A7EDE5C;
        constexpr uintptr_t kRVA_get_projectionMatrix    = 0x0A7EDF94;
        constexpr uintptr_t kRVA_WorldToScreenPoint      = 0x0A7EE474;
        constexpr uintptr_t kRVA_Screen_get_width        = 0x0A7FC138;
        constexpr uintptr_t kRVA_Screen_get_height       = 0x0A7FC160;
    }

    namespace Transform {
        constexpr uintptr_t kRVA_Component_get_transform = 0x0A8357B8;
        constexpr uintptr_t kRVA_get_position            = 0x0A843A30;
        constexpr uintptr_t kRVA_get_rotation             = 0x0A843C20;
        constexpr uintptr_t kRVA_get_forward              = 0x0A844008;
    }

    namespace Entity {
        constexpr size_t kField_CachedTransform = 0x58;
        constexpr size_t kField_UniqueID        = 0x60;
        constexpr uintptr_t kRVA_get_Position   = 0x08216BDC;
        constexpr uintptr_t kRVA_get_Forward    = 0x08216DAC;
    }

    namespace AttackableEntity {
        constexpr uintptr_t kRVA_get_IsDead            = 0x0703C914;
        constexpr uintptr_t kRVA_GetAttackableCenterWS = 0x0703C9E4;
        constexpr uintptr_t kRVA_IsVisible             = 0x0703CD3C;
    }

    namespace Player {
        constexpr uintptr_t kRVA_get_CurHP     = 0x070E6FA8;
        constexpr uintptr_t kRVA_get_MaxHP     = 0x070E70A0;
        constexpr uintptr_t kRVA_get_CurEP     = 0x07137F44;
        constexpr uintptr_t kRVA_get_NickName  = 0x0707D038;
        constexpr uintptr_t kRVA_get_IsSamoAI  = 0x0707CCC8;
    }

    namespace GameFacade {
        constexpr uintptr_t kRVA_CurrentLocalPlayer       = 0x07540158;
        constexpr uintptr_t kRVA_GetLocalPlayerOrObServer = 0x0753DFBC;
        constexpr uintptr_t kRVA_CurrentMatch             = 0x0753FD5C;
        constexpr uintptr_t kRVA_IsLocalTeammate          = 0x07540938;
        constexpr uintptr_t kRVA_IsSameTeam               = 0x07540A50;
        constexpr uintptr_t kRVA_CurrentLocalPlayerTeamIdx= 0x07541628;
    }

    namespace Animator {
        constexpr uintptr_t kRVA_GetBoneTransform         = 0x0A7D537C;
        constexpr uintptr_t kRVA_GetBoneTransformInternal = 0x0A7D56F0;
        constexpr int kBone_Hips          = 0;
        constexpr int kBone_LeftUpperLeg  = 1;
        constexpr int kBone_RightUpperLeg = 2;
        constexpr int kBone_LeftLowerLeg  = 3;
        constexpr int kBone_RightLowerLeg = 4;
        constexpr int kBone_LeftFoot      = 5;
        constexpr int kBone_RightFoot     = 6;
        constexpr int kBone_Spine         = 7;
        constexpr int kBone_Chest         = 8;
        constexpr int kBone_Neck          = 9;
        constexpr int kBone_Head          = 10;
        constexpr int kBone_LeftShoulder  = 11;
        constexpr int kBone_RightShoulder = 12;
        constexpr int kBone_LeftUpperArm  = 13;
        constexpr int kBone_RightUpperArm = 14;
        constexpr int kBone_LeftLowerArm  = 15;
        constexpr int kBone_RightLowerArm = 16;
        constexpr int kBone_LeftHand      = 17;
        constexpr int kBone_RightHand     = 18;
    }

    constexpr uintptr_t kMinValidAddress = 0x1000;
#if defined(__LP64__) || defined(_LP64)
    constexpr uintptr_t kMaxValidAddress = 0x7FFFFFFFFFFFULL;
#else
    constexpr uintptr_t kMaxValidAddress = 0xFFFFFFFFUL;
#endif
    constexpr size_t kMaxStringReadLen = 128;
    constexpr int kMaxEntityCount = 64;
    constexpr int kMaxPointerDepth = 16;
}

#endif // IL2CPP_OFFSETS_H
