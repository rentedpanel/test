#include "simulation_engine.h"
#include <cmath>

extern "C" {

JNIEXPORT jint JNICALL
Java_com_memorylab_mods_NativeSimulationEngine_nativeGenerateSyntheticEntities(
    JNIEnv* env,
    jclass /*clazz*/,
    jint count,
    jfloat centerDistance,
    jfloatArray outEntityBuffer
) {
    if (!outEntityBuffer || count <= 0) return 0;

    jsize bufLen = env->GetArrayLength(outEntityBuffer);
    const int stride = 10; // id, posX, posY, posZ, headY, footY, hp, maxHp, team, isVisible
    if (bufLen < count * stride) return -1;

    jfloat* buf = env->GetFloatArrayElements(outEntityBuffer, nullptr);

    for (int i = 0; i < count; ++i) {
        float angle = (float)i * (2.0f * 3.14159265f / (float)count);
        float radius = centerDistance + (float)(i % 3) * 3.0f;
        float x = std::sin(angle) * radius;
        float z = std::cos(angle) * radius;
        float y = 0.0f;

        int offset = i * stride;
        buf[offset + 0] = (float)(100 + i);        // ID
        buf[offset + 1] = x;                       // posX
        buf[offset + 2] = y;                       // posY
        buf[offset + 3] = z;                       // posZ
        buf[offset + 4] = y + 1.8f;                // headY
        buf[offset + 5] = y;                       // footY
        buf[offset + 6] = 75.0f + (float)(i % 25); // HP
        buf[offset + 7] = 100.0f;                  // Max HP
        buf[offset + 8] = (float)(i % 2);          // Team (0=Red, 1=Blue)
        buf[offset + 9] = (i % 3 != 0) ? 1.0f : 0.0f; // isVisible
    }

    env->ReleaseFloatArrayElements(outEntityBuffer, buf, 0);
    return count;
}

}
