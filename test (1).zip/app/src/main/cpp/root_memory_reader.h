#ifndef ROOT_MEMORY_READER_H
#define ROOT_MEMORY_READER_H

#include <jni.h>
#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <mutex>
#include <atomic>
#include <sys/types.h>
#include "memory_offsets.h"
#include "il2cpp_offsets.h"

/**
 * ============================================================================
 *        ROOT PROCESS MEMORY READER & IL2CPP POINTER TRAVERSAL ENGINE
 * ============================================================================
 *
 * Provides a complete, thread-safe pipeline for cross-process memory analysis
 * in our self-compiled local test build environment:
 *
 *  Layer 1 — Process Identification
 *    Resolves the target test application's PID by scanning /proc/<pid>/cmdline
 *    entries against the configured package name.
 *
 *  Layer 2 — Module Base Address Resolution
 *    Parses /proc/<pid>/maps to locate the runtime load address of the target
 *    shared object (libil2cpp.so) within the process's virtual memory space.
 *
 *  Layer 3 — Memory Read Primitives
 *    Implements bounds-checked cross-process reads via the process_vm_readv
 *    kernel syscall (Linux 3.2+, ARM64 #270) with automatic fallback to
 *    pread64 on /proc/<pid>/mem.
 *
 *  Layer 4 — IL2CPP Metadata Traversal
 *    Walks the IL2CPP runtime class hierarchy (Domain -> Assemblies -> Images
 *    -> Classes -> StaticFields) to locate game singleton instances and
 *    entity lists using the offsets defined in il2cpp_offsets.h.
 *
 *  Layer 5 — Entity Extraction & Camera Resolution
 *    Reads spatial coordinates (X, Y, Z), health metrics, team indices, and
 *    bone joint positions from live entity instances, packing results into
 *    NativeEntity structs (memory_offsets.h) for JNI transmission.
 */

// ─── Attachment State ────────────────────────────────────────────────────────

enum class ReaderState : int {
    DETACHED       = 0,
    PID_RESOLVED   = 1,
    BASE_RESOLVED  = 2,
    DOMAIN_FOUND   = 3,
    CLASS_RESOLVED = 4,
    FULLY_ATTACHED = 5,
    ERROR          = -1
};

struct AttachmentInfo {
    pid_t  pid            = -1;
    uintptr_t libBase     = 0;
    uintptr_t domainPtr   = 0;
    uintptr_t gameFacadeClass = 0;
    uintptr_t playerClass = 0;
    uintptr_t cameraClass = 0;
    uintptr_t localPlayerPtr  = 0;
    uint32_t  localTeamIndex  = 0;
    int       entityCount     = 0;
    ReaderState state     = ReaderState::DETACHED;
    std::string statusMsg;
    std::string packageName;
};

// ─── Core Reader Class ───────────────────────────────────────────────────────

class RootMemoryReader {
public:
    // --- Layer 1: Process Identification ---
    static pid_t findProcessId(const std::string& packageName);

    // --- Layer 2: Module Base Address ---
    static uintptr_t getModuleBaseAddress(pid_t pid, const std::string& moduleName);

    // --- Layer 3: Memory Read Primitives ---
    static bool readMemory(pid_t pid, uintptr_t remoteAddr, void* localBuf, size_t size);
    static uintptr_t readPointer(pid_t pid, uintptr_t address);

    template<typename T>
    static bool read(pid_t pid, uintptr_t address, T& out) {
        return readMemory(pid, address, &out, sizeof(T));
    }

    static bool readString(pid_t pid, uintptr_t address, char* outBuf, size_t maxLen);

    // --- Layer 4: IL2CPP Metadata Traversal ---
    static uintptr_t findIl2CppDomain(pid_t pid, uintptr_t libBase);
    static uintptr_t findClassByName(pid_t pid, uintptr_t domainPtr,
                                      const char* namespaceName, const char* className,
                                      const char* imageName = nullptr);
    static uintptr_t readStaticFields(pid_t pid, uintptr_t classPtr);

    // --- Layer 5: Full Attachment & Entity Extraction ---
    static bool attachToProcess(const std::string& packageName, AttachmentInfo& info);
    static int  readLiveEntities(const AttachmentInfo& info,
                                  std::vector<NativeEntity>& outEntities,
                                  NativeMatrix4x4& outViewMat,
                                  NativeMatrix4x4& outProjMat);

    // --- Shared Attachment State (Engine-wide Singleton) ---
    static AttachmentInfo& getSharedAttachment();
    static std::mutex& getSharedMutex();

    // --- Thread-Safe Audit Logger ---
    static bool initAuditLogger(const std::string& filesDirPath);
    static void writeAuditLog(const char* levelTag, const char* fmt, ...);

    // --- Pointer Validation ---
    static bool isValidPointer(uintptr_t ptr);
    static bool probeElfHeader(pid_t pid, uintptr_t base);
};

#endif // ROOT_MEMORY_READER_H
