#ifndef SIMULATION_ENGINE_H
#define SIMULATION_ENGINE_H

#include <jni.h>
#include <string>
#include <vector>

struct NativeEntityRecord {
    int32_t id;
    float posX, posY, posZ;
    float headX, headY, headZ;
    float footX, footY, footZ;
    float health;
    float maxHealth;
    int32_t team;
    bool isVisible;
};

extern "C" {
    JNIEXPORT jint JNICALL
    Java_com_memorylab_mods_NativeSimulationEngine_nativeGenerateSyntheticEntities(
        JNIEnv* env,
        jclass clazz,
        jint count,
        jfloat centerDistance,
        jfloatArray outEntityBuffer
    );
}

#endif // SIMULATION_ENGINE_H
