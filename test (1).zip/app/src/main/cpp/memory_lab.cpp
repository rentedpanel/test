#include "memory_lab.h"
#include "memory_math.h"
#include <android/log.h>
#include <chrono>
#include <mutex>
#include <vector>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::mutex g_stateMutex;
static bool g_initialized = false;
static float g_simulationTime = 0.0f;
static std::vector<NativeEntity> g_liveEntities;
static NativeMatrix4x4 g_cachedViewMatrix;
static NativeMatrix4x4 g_cachedProjMatrix;
static bool g_isLiveMode = false;

extern "C" {

JNIEXPORT jstring JNICALL Java_com_memorylab_mods_NativeMemory_nativeGetVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF("MemoryLab C++17 Core v1.1.0");
}

JNIEXPORT jboolean JNICALL Java_com_memorylab_mods_NativeMemory_nativeInitializeLab(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(g_stateMutex);
    g_initialized = true;
    g_simulationTime = 0.0f;
    g_liveEntities.clear();
    nativeSetIdentity(g_cachedViewMatrix);
    nativeSetIdentity(g_cachedProjMatrix);
    return JNI_TRUE;
}

JNIEXPORT jint JNICALL Java_com_memorylab_mods_NativeMemory_nativeUpdateSimulationStep(JNIEnv*, jclass, jfloat deltaSec, jint targetCount, jfloat camYaw, jfloat camPitch, jfloat camDist, jfloat camFov, jfloat aspect) {
    std::lock_guard<std::mutex> lock(g_stateMutex);
    g_simulationTime += deltaSec;
    float time = g_simulationTime;

    float radYaw = camYaw * NATIVE_DEG2RAD;
    float radPitch = camPitch * NATIVE_DEG2RAD;
    NativeVector3 eyePos{std::sin(radYaw) * std::cos(radPitch) * camDist, -std::sin(radPitch) * camDist + 1.8f, -std::cos(radYaw) * std::cos(radPitch) * camDist};
    NativeVector3 targetPos{0.0f, 1.2f, 0.0f}, upPos{0.0f, 1.0f, 0.0f};

    nativeComputeLookAt(eyePos, targetPos, upPos, g_cachedViewMatrix);
    nativeComputePerspective(camFov, aspect, 0.1f, 500.0f, g_cachedProjMatrix);

    int count = std::max(1, std::min((int)targetCount, 64));
    g_liveEntities.resize(count);

    for (int i = 0; i < count; ++i) {
        NativeEntity& ent = g_liveEntities[i];
        ent.id = 100 + i;
        float baseAngle = ((float)i / (float)count) * (2.0f * NATIVE_PI);
        float currentAngle = baseAngle + std::sin(time * 0.5f + (float)i) * 0.4f;
        float radius = 5.5f + std::sin(time * 0.8f + (float)i * 1.5f) * 2.2f;

        float posX = std::sin(currentAngle) * radius, posZ = std::cos(currentAngle) * radius;
        ent.worldPosition = {posX, 0.0f, posZ};
        ent.headPosition  = {posX, 1.8f, posZ};
        ent.footPosition  = {posX, 0.0f, posZ};
        ent.health = 100.0f; ent.maxHealth = 100.0f; ent.team = i % 2; ent.isVisible = 1; ent.isAlive = 1;
    }
    return (jint)g_liveEntities.size();
}

JNIEXPORT jint JNICALL Java_com_memorylab_mods_NativeMemory_nativeGetEntityCount(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(g_stateMutex);
    return (jint)g_liveEntities.size();
}

JNIEXPORT jint JNICALL Java_com_memorylab_mods_NativeMemory_nativeGetLiveEntities(JNIEnv* env, jclass, jfloatArray outBuffer) {
    if (!outBuffer) return 0;
    std::lock_guard<std::mutex> lock(g_stateMutex);
    int entityCount = (int)g_liveEntities.size();
    if (entityCount <= 0) return 0;

    jfloat* buf = env->GetFloatArrayElements(outBuffer, nullptr);
    if (!buf) return -2;

    for (int i = 0; i < entityCount; ++i) {
        const NativeEntity& ent = g_liveEntities[i];
        int off = i * NativeMemoryLayout::TOTAL_ENTITY_STRIDE_FLOATS;
        buf[off + 0] = (float)ent.id; buf[off + 1] = ent.worldPosition.x; buf[off + 2] = ent.worldPosition.y; buf[off + 3] = ent.worldPosition.z;
        buf[off + 4] = ent.headPosition.y; buf[off + 5] = ent.footPosition.y; buf[off + 6] = ent.health; buf[off + 7] = ent.maxHealth;
        buf[off + 8] = (float)ent.team; buf[off + 9] = (float)ent.isVisible;
    }
    env->ReleaseFloatArrayElements(outBuffer, buf, 0);
    return entityCount;
}

JNIEXPORT jboolean JNICALL Java_com_memorylab_mods_NativeMemory_nativeGetCameraMatrices(JNIEnv* env, jclass, jfloatArray outView, jfloatArray outProj) {
    if (!outView || !outProj) return JNI_FALSE;
    std::lock_guard<std::mutex> lock(g_stateMutex);
    jfloat* vm = env->GetFloatArrayElements(outView, nullptr);
    jfloat* pm = env->GetFloatArrayElements(outProj, nullptr);
    for (int i = 0; i < 16; ++i) { vm[i] = g_cachedViewMatrix.m[i]; pm[i] = g_cachedProjMatrix.m[i]; }
    env->ReleaseFloatArrayElements(outView, vm, 0);
    env->ReleaseFloatArrayElements(outProj, pm, 0);
    return JNI_TRUE;
}
}
