#include "root_diagnostic.h"
#include <unistd.h>
#include <sys/stat.h>

static const char* SU_PATHS[] = {
    "/system/bin/su",
    "/system/xbin/su",
    "/sbin/su",
    "/system/sd/xbin/su",
    "/system/bin/failsafe/su",
    "/data/local/xbin/su",
    "/data/local/bin/su",
    "/data/local/su",
    "/su/bin/su"
};

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_memorylab_mods_NativeRootDiagnostic_nativeCheckSuBinary(JNIEnv* /*env*/, jclass /*clazz*/) {
    for (const char* path : SU_PATHS) {
        struct stat st;
        if (stat(path, &st) == 0) {
            return JNI_TRUE;
        }
    }
    return JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_memorylab_mods_NativeRootDiagnostic_nativeGetSecuritySummary(JNIEnv* env, jclass /*clazz*/) {
    std::string summary = "SELinux Enforced / Sandbox Protected / Non-Root Research Environment";
    return env->NewStringUTF(summary.c_str());
}

}
