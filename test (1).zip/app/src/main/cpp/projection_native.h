#ifndef PROJECTION_NATIVE_H
#define PROJECTION_NATIVE_H

#include <jni.h>
#include <cmath>

struct NativeVec3 {
    float x, y, z;
};

struct NativeVec4 {
    float x, y, z, w;
};

struct NativeMat4 {
    float m[16]; // column-major or row-major
};

extern "C" {
    JNIEXPORT jboolean JNICALL
    Java_com_memorylab_mods_NativeProjection_nativeProjectWorldToScreen(
        JNIEnv* env,
        jclass clazz,
        jfloat worldX, jfloat worldY, jfloat worldZ,
        jfloatArray viewMatrix,
        jfloatArray projMatrix,
        jint screenWidth, jint screenHeight,
        jfloatArray outScreenCoords
    );
}

#endif // PROJECTION_NATIVE_H
