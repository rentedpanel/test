#include "root_memory_reader.h"
#include "memory/audit_logger.h"
#include <android/log.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/uio.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define LOG_TAG "RootMemoryReader"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

static AttachmentInfo s_sharedAttachment;
static std::mutex s_sharedMutex;

AttachmentInfo& RootMemoryReader::getSharedAttachment() { return s_sharedAttachment; }
std::mutex& RootMemoryReader::getSharedMutex() { return s_sharedMutex; }

bool RootMemoryReader::initAuditLogger(const std::string& filesDirPath) {
    return AuditLogger::init(filesDirPath);
}

void RootMemoryReader::writeAuditLog(const char* levelTag, const char* fmt, ...) {
    char buffer[1024];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);
    AuditLogger::writeLog(levelTag, "%s", buffer);
}

pid_t RootMemoryReader::findProcessId(const std::string& packageName) {
    DIR* dir = opendir("/proc");
    if (!dir) return -1;
    pid_t targetPid = -1;
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (entry->d_type != DT_DIR && entry->d_type != DT_UNKNOWN) continue;
        bool isNumeric = true;
        for (const char* p = entry->d_name; *p; ++p) { if (!isdigit(*p)) { isNumeric = false; break; } }
        if (!isNumeric) continue;

        char cmdlinePath[64];
        snprintf(cmdlinePath, sizeof(cmdlinePath), "/proc/%s/cmdline", entry->d_name);
        FILE* fp = fopen(cmdlinePath, "r");
        if (!fp) continue;
        char cmdline[256] = {0};
        size_t bytesRead = fread(cmdline, 1, sizeof(cmdline) - 1, fp);
        fclose(fp);
        if (bytesRead == 0) continue;

        if (strncmp(cmdline, packageName.c_str(), packageName.length()) == 0) {
            targetPid = static_cast<pid_t>(atoi(entry->d_name));
            break;
        }
    }
    closedir(dir);
    return targetPid;
}

uintptr_t RootMemoryReader::getModuleBaseAddress(pid_t pid, const std::string& moduleName) {
    if (pid <= 0) return 0;
    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", pid);
    FILE* fp = fopen(mapsPath, "r");
    if (!fp) return 0;

    uintptr_t baseAddr = 0;
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, moduleName.c_str())) {
            baseAddr = static_cast<uintptr_t>(strtoull(line, nullptr, 16));
            break;
        }
    }
    fclose(fp);
    return baseAddr;
}

bool RootMemoryReader::readMemory(pid_t pid, uintptr_t address, void* buffer, size_t size) {
    if (pid <= 0 || !buffer || size == 0) return false;
    struct iovec local[1], remote[1];
    local[0].iov_base = buffer; local[0].iov_len = size;
    remote[0].iov_base = reinterpret_cast<void*>(address); remote[0].iov_len = size;
    ssize_t bytesRead = process_vm_readv(pid, local, 1, remote, 1, 0);
    return (bytesRead == static_cast<ssize_t>(size));
}

bool RootMemoryReader::probeElfHeader(pid_t pid, uintptr_t base) {
    if (pid <= 0 || base == 0) return false;
    unsigned char elfMagic[4] = {0};
    if (!readMemory(pid, base, elfMagic, 4)) return false;
    return (elfMagic[0] == 0x7f && elfMagic[1] == 'E' && elfMagic[2] == 'L' && elfMagic[3] == 'F');
}

bool RootMemoryReader::attachToProcess(const std::string& packageName, AttachmentInfo& outInfo) {
    outInfo.packageName = packageName;
    outInfo.pid = findProcessId(packageName);
    if (outInfo.pid <= 0) { outInfo.state = ReaderState::ERROR; return false; }
    outInfo.libBase = getModuleBaseAddress(outInfo.pid, "libil2cpp.so");
    if (outInfo.libBase == 0) { outInfo.state = ReaderState::PID_RESOLVED; return false; }
    outInfo.state = ReaderState::FULLY_ATTACHED;
    return true;
}

int RootMemoryReader::readLiveEntities(const AttachmentInfo& info, std::vector<NativeEntity>& outEntities, NativeMatrix4x4& outView, NativeMatrix4x4& outProj) {
    if (info.pid <= 0 || info.libBase == 0) return -1;
    (void)outView;
    (void)outProj;
    outEntities.clear();
    return 0;
}

extern "C" {

JNIEXPORT jint JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeFindProcessPid(JNIEnv* env, jclass, jstring packageName) {
    if (!packageName) return -1;
    const char* pkg = env->GetStringUTFChars(packageName, nullptr);
    pid_t pid = RootMemoryReader::findProcessId(pkg ? pkg : "");
    if (pkg) env->ReleaseStringUTFChars(packageName, pkg);
    return (jint)pid;
}

JNIEXPORT jlong JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeGetModuleBase(JNIEnv* env, jclass, jint pid, jstring moduleName) {
    if (!moduleName) return 0;
    const char* mod = env->GetStringUTFChars(moduleName, nullptr);
    uintptr_t base = RootMemoryReader::getModuleBaseAddress((pid_t)pid, mod ? mod : "libil2cpp.so");
    if (mod) env->ReleaseStringUTFChars(moduleName, mod);
    return (jlong)base;
}

JNIEXPORT jboolean JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeReadMemoryBytes(JNIEnv* env, jclass, jint pid, jlong address, jbyteArray outBuf, jint size) {
    if (!outBuf || size <= 0) return JNI_FALSE;
    jbyte* buf = env->GetByteArrayElements(outBuf, nullptr);
    if (!buf) return JNI_FALSE;
    bool success = RootMemoryReader::readMemory((pid_t)pid, (uintptr_t)address, buf, (size_t)size);
    env->ReleaseByteArrayElements(outBuf, buf, 0);
    return success ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeReadMemoryFloats(JNIEnv* env, jclass, jint pid, jlong address, jfloatArray outBuf, jint count) {
    if (!outBuf || count <= 0) return JNI_FALSE;
    jfloat* buf = env->GetFloatArrayElements(outBuf, nullptr);
    if (!buf) return JNI_FALSE;
    bool success = RootMemoryReader::readMemory((pid_t)pid, (uintptr_t)address, buf, (size_t)(count * sizeof(float)));
    env->ReleaseFloatArrayElements(outBuf, buf, 0);
    return success ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeProbeProcess(JNIEnv*, jclass, jint pid, jlong libil2cppBase) {
    bool ok = RootMemoryReader::probeElfHeader((pid_t)pid, (uintptr_t)libil2cppBase);
    return ok ? 1 : -2;
}

JNIEXPORT jint JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeAttachToProcess(JNIEnv* env, jclass, jstring packageName) {
    if (!packageName) return -1;
    const char* pkg = env->GetStringUTFChars(packageName, nullptr);
    AttachmentInfo& info = RootMemoryReader::getSharedAttachment();
    bool ok = RootMemoryReader::attachToProcess(pkg ? pkg : "", info);
    if (pkg) env->ReleaseStringUTFChars(packageName, pkg);
    return ok ? (jint)info.state : -1;
}

JNIEXPORT jboolean JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeGetAttachmentStatus(JNIEnv* env, jclass, jintArray outStatus) {
    if (!outStatus) return JNI_FALSE;
    jint* st = env->GetIntArrayElements(outStatus, nullptr);
    if (!st) return JNI_FALSE;
    const AttachmentInfo& info = RootMemoryReader::getSharedAttachment();
    st[0] = (jint)info.state;
    st[1] = (jint)info.pid;
    st[2] = (jint)info.entityCount;
    env->ReleaseIntArrayElements(outStatus, st, 0);
    return JNI_TRUE;
}

JNIEXPORT jstring JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeGetStatusMessage(JNIEnv* env, jclass) {
    const AttachmentInfo& info = RootMemoryReader::getSharedAttachment();
    return env->NewStringUTF(info.statusMsg.c_str());
}

JNIEXPORT jint JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeReadLiveEntities(JNIEnv*, jclass, jfloatArray) {
    const AttachmentInfo& info = RootMemoryReader::getSharedAttachment();
    std::vector<NativeEntity> entities;
    NativeMatrix4x4 view, proj;
    return RootMemoryReader::readLiveEntities(info, entities, view, proj);
}

JNIEXPORT jboolean JNICALL Java_com_memorylab_mods_NativeRootMemory_nativeInitLogger(JNIEnv* env, jclass, jstring filesDirPath) {
    if (!filesDirPath) return JNI_FALSE;
    const char* path = env->GetStringUTFChars(filesDirPath, nullptr);
    bool ok = RootMemoryReader::initAuditLogger(path ? path : "");
    if (path) env->ReleaseStringUTFChars(filesDirPath, path);
    return ok ? JNI_TRUE : JNI_FALSE;
}

}
