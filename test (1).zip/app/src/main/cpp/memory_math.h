#ifndef MEMORY_MATH_H
#define MEMORY_MATH_H

#include "memory_lab.h"
#include <cmath>

static constexpr float NATIVE_PI = 3.14159265358979323846f;
static constexpr float NATIVE_DEG2RAD = NATIVE_PI / 180.0f;

void nativeSetIdentity(NativeMatrix4x4& mat);
void nativeComputeLookAt(const NativeVector3& eye, const NativeVector3& target, const NativeVector3& up, NativeMatrix4x4& outMat);
void nativeComputePerspective(float fovDegrees, float aspect, float nearPlane, float farPlane, NativeMatrix4x4& outMat);

#endif // MEMORY_MATH_H
