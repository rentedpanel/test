#ifndef ROOT_DIAGNOSTIC_H
#define ROOT_DIAGNOSTIC_H

#include <jni.h>
#include <string>

extern "C" {
    JNIEXPORT jboolean JNICALL
    Java_com_memorylab_mods_NativeRootDiagnostic_nativeCheckSuBinary(JNIEnv* env, jclass clazz);

    JNIEXPORT jstring JNICALL
    Java_com_memorylab_mods_NativeRootDiagnostic_nativeGetSecuritySummary(JNIEnv* env, jclass clazz);
}

#endif // ROOT_DIAGNOSTIC_H
