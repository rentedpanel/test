#include "memory_math.h"

void nativeSetIdentity(NativeMatrix4x4& mat) {
    for (int i = 0; i < 16; ++i) {
        mat.m[i] = (i % 5 == 0) ? 1.0f : 0.0f;
    }
}

void nativeComputeLookAt(
    const NativeVector3& eye,
    const NativeVector3& target,
    const NativeVector3& up,
    NativeMatrix4x4& outMat
) {
    float fx = target.x - eye.x;
    float fy = target.y - eye.y;
    float fz = target.z - eye.z;
    float fLen = std::sqrt(fx * fx + fy * fy + fz * fz);
    if (fLen > 0.00001f) { fx /= fLen; fy /= fLen; fz /= fLen; } else { fx = 0.0f; fy = 0.0f; fz = 1.0f; }

    float rx = fy * up.z - fz * up.y;
    float ry = fz * up.x - fx * up.z;
    float rz = fx * up.y - fy * up.x;
    float rLen = std::sqrt(rx * rx + ry * ry + rz * rz);
    if (rLen > 0.00001f) { rx /= rLen; ry /= rLen; rz /= rLen; } else { rx = 1.0f; ry = 0.0f; rz = 0.0f; }

    float ux = ry * fz - rz * fy;
    float uy = rz * fx - rx * fz;
    float uz = rx * fy - ry * fx;

    outMat.m[0]  = rx;  outMat.m[1]  = ux;  outMat.m[2]  = -fx; outMat.m[3]  = 0.0f;
    outMat.m[4]  = ry;  outMat.m[5]  = uy;  outMat.m[6]  = -fy; outMat.m[7]  = 0.0f;
    outMat.m[8]  = rz;  outMat.m[9]  = uz;  outMat.m[10] = -fz; outMat.m[11] = 0.0f;
    outMat.m[12] = -(rx * eye.x + ry * eye.y + rz * eye.z);
    outMat.m[13] = -(ux * eye.x + uy * eye.y + uz * eye.z);
    outMat.m[14] =  (fx * eye.x + fy * eye.y + fz * eye.z);
    outMat.m[15] = 1.0f;
}

void nativeComputePerspective(
    float fovDegrees,
    float aspect,
    float nearPlane,
    float farPlane,
    NativeMatrix4x4& outMat
) {
    nativeSetIdentity(outMat);
    float top = nearPlane * std::tan(fovDegrees * 0.5f * NATIVE_DEG2RAD);
    float bottom = -top;
    float right = top * aspect;
    float left = -right;

    float invWidth = 1.0f / (right - left);
    float invHeight = 1.0f / (top - bottom);
    float invDepth = 1.0f / (farPlane - nearPlane);

    outMat.m[0] = 2.0f * nearPlane * invWidth;
    outMat.m[5] = 2.0f * nearPlane * invHeight;
    outMat.m[8] = (right + left) * invWidth;
    outMat.m[9] = (top + bottom) * invHeight;
    outMat.m[10] = -(farPlane + nearPlane) * invDepth;
    outMat.m[11] = -1.0f;
    outMat.m[14] = -2.0f * farPlane * nearPlane * invDepth;
    outMat.m[15] = 0.0f;
}
