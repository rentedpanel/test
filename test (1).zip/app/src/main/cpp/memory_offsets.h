#ifndef MEMORY_OFFSETS_H
#define MEMORY_OFFSETS_H

#include <cstdint>
#include <cstddef>

/**
 * ============================================================================
 *               NATIVE MEMORY OFFSETS & DATA STRUCTURE LAYOUT
 * ============================================================================
 * 
 * Location: app/src/main/cpp/memory_offsets.h
 * 
 * Defines standard C++17 POD (Plain Old Data) structures with explicit byte alignments
 * and offsets for single-process memory traversal, coordinate projections, and
 * real-time ESP visualization.
 */

#pragma pack(push, 1)

/**
 * 3D Vector with Cartesian spatial coordinates (x, y, z).
 * Size: 12 bytes
 */
struct NativeVector3 {
    float x; // Offset: 0x00
    float y; // Offset: 0x04
    float z; // Offset: 0x08
};

/**
 * 2D Screen Vector (x, y).
 * Size: 8 bytes
 */
struct NativeVector2 {
    float x; // Offset: 0x00
    float y; // Offset: 0x04
};

/**
 * 4x4 Transformation Matrix (column-major order matching OpenGL & Android Canvas).
 * Size: 64 bytes (16 floats)
 */
struct NativeMatrix4x4 {
    float m[16]; // Offset: 0x00 - 0x3F
};

/**
 * Complete 14-Joint 3D Bone Skeleton Structure for an entity.
 * Size: 14 * 12 = 168 bytes
 */
struct NativeSkeletonBones {
    NativeVector3 head;          // Offset: 0x00 (0)
    NativeVector3 neck;          // Offset: 0x0C (12)
    NativeVector3 spine;         // Offset: 0x18 (24)
    NativeVector3 pelvis;        // Offset: 0x24 (36)
    NativeVector3 leftShoulder;  // Offset: 0x30 (48)
    NativeVector3 rightShoulder; // Offset: 0x3C (60)
    NativeVector3 leftElbow;     // Offset: 0x48 (72)
    NativeVector3 rightElbow;    // Offset: 0x54 (84)
    NativeVector3 leftHand;      // Offset: 0x60 (96)
    NativeVector3 rightHand;     // Offset: 0x6C (108)
    NativeVector3 leftHip;       // Offset: 0x78 (120)
    NativeVector3 rightHip;      // Offset: 0x84 (132)
    NativeVector3 leftKnee;      // Offset: 0x90 (144)
    NativeVector3 rightKnee;     // Offset: 0x9C (156)
    NativeVector3 leftFoot;      // Offset: 0xA8 (168)
    NativeVector3 rightFoot;     // Offset: 0xB4 (180)
};

/**
 * Native Entity representation containing spatial coordinates, health stats,
 * and 3D skeleton joints within unified process memory.
 */
struct NativeEntity {
    int32_t id;                       // Offset: 0x000 (4 bytes)
    NativeVector3 worldPosition;       // Offset: 0x004 (12 bytes)
    NativeVector3 headPosition;        // Offset: 0x010 (12 bytes)
    NativeVector3 footPosition;        // Offset: 0x01C (12 bytes)
    float health;                      // Offset: 0x028 (4 bytes)
    float maxHealth;                   // Offset: 0x02C (4 bytes)
    int32_t team;                      // Offset: 0x030 (4 bytes: 0=Alpha, 1=Bravo)
    uint8_t isVisible;                 // Offset: 0x034 (1 byte)
    uint8_t isAlive;                   // Offset: 0x035 (1 byte)
    uint8_t padding[2];                // Offset: 0x036 (2 bytes padding for alignment)
    NativeSkeletonBones skeleton;      // Offset: 0x038 (192 bytes)
};

#pragma pack(pop)

/**
 * Compile-time Offset and Structure Layout Verification.
 * Guarantees binary integrity across NDK compilers and architectures.
 */
namespace NativeMemoryLayout {
    static_assert(sizeof(NativeVector3) == 12, "NativeVector3 must be 12 bytes");
    static_assert(sizeof(NativeMatrix4x4) == 64, "NativeMatrix4x4 must be 64 bytes");
    static_assert(offsetof(NativeEntity, worldPosition) == 4, "worldPosition offset mismatch");
    static_assert(offsetof(NativeEntity, headPosition) == 16, "headPosition offset mismatch");
    static_assert(offsetof(NativeEntity, health) == 40, "health offset mismatch");
    static_assert(offsetof(NativeEntity, maxHealth) == 44, "maxHealth offset mismatch");
    static_assert(offsetof(NativeEntity, team) == 48, "team offset mismatch");
    static_assert(offsetof(NativeEntity, isVisible) == 52, "isVisible offset mismatch");
    static_assert(offsetof(NativeEntity, skeleton) == 56, "skeleton offset mismatch");

    // Float stride for JNI packed buffer transmission:
    // Basic attributes (10 floats): id, posX, posY, posZ, headY, footY, hp, maxHp, team, isVisible
    // Skeleton attributes (48 floats): 16 joints * 3 coordinates (x, y, z)
    // Total float stride per entity = 58 floats
    constexpr int BASIC_STRIDE_FLOATS = 10;
    constexpr int SKELETON_JOINTS_COUNT = 16;
    constexpr int SKELETON_STRIDE_FLOATS = SKELETON_JOINTS_COUNT * 3; // 48
    constexpr int TOTAL_ENTITY_STRIDE_FLOATS = BASIC_STRIDE_FLOATS + SKELETON_STRIDE_FLOATS; // 58
}

#endif // MEMORY_OFFSETS_H
