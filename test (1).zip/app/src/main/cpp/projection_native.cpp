#include "projection_native.h"
#include <vector>

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_memorylab_mods_NativeProjection_nativeProjectWorldToScreen(
    JNIEnv* env,
    jclass /*clazz*/,
    jfloat worldX, jfloat worldY, jfloat worldZ,
    jfloatArray viewMatrixArr,
    jfloatArray projMatrixArr,
    jint screenWidth, jint screenHeight,
    jfloatArray outScreenCoordsArr
) {
    if (!viewMatrixArr || !projMatrixArr || !outScreenCoordsArr) {
        return JNI_FALSE;
    }

    jfloat* vm = env->GetFloatArrayElements(viewMatrixArr, nullptr);
    jfloat* pm = env->GetFloatArrayElements(projMatrixArr, nullptr);
    jfloat* outCoords = env->GetFloatArrayElements(outScreenCoordsArr, nullptr);

    // Compute View transform: eyePos = View * (worldX, worldY, worldZ, 1.0)
    // Assuming standard OpenGL column-major matrix
    float eyeX = vm[0] * worldX + vm[4] * worldY + vm[8]  * worldZ + vm[12];
    float eyeY = vm[1] * worldX + vm[5] * worldY + vm[9]  * worldZ + vm[13];
    float eyeZ = vm[2] * worldX + vm[6] * worldY + vm[10] * worldZ + vm[14];
    float eyeW = vm[3] * worldX + vm[7] * worldY + vm[11] * worldZ + vm[15];

    // Compute Clip coordinates: clip = Proj * eye
    float clipX = pm[0] * eyeX + pm[4] * eyeY + pm[8]  * eyeZ + pm[12] * eyeW;
    float clipY = pm[1] * eyeX + pm[5] * eyeY + pm[9]  * eyeZ + pm[13] * eyeW;
    float clipZ = pm[2] * eyeX + pm[6] * eyeY + pm[10] * eyeZ + pm[14] * eyeW;
    float clipW = pm[3] * eyeX + pm[7] * eyeY + pm[11] * eyeZ + pm[15] * eyeW;

    // Check near plane and behind camera (w <= 0.001f)
    if (clipW <= 0.001f) {
        env->ReleaseFloatArrayElements(viewMatrixArr, vm, JNI_ABORT);
        env->ReleaseFloatArrayElements(projMatrixArr, pm, JNI_ABORT);
        env->ReleaseFloatArrayElements(outScreenCoordsArr, outCoords, 0);
        return JNI_FALSE;
    }

    // Normalized Device Coordinates (NDC)
    float ndcX = clipX / clipW;
    float ndcY = clipY / clipW;
    float ndcZ = clipZ / clipW;

    // Reject out-of-bounds coordinates outside frustum if strictly outside
    if (ndcX < -2.0f || ndcX > 2.0f || ndcY < -2.0f || ndcY > 2.0f) {
        env->ReleaseFloatArrayElements(viewMatrixArr, vm, JNI_ABORT);
        env->ReleaseFloatArrayElements(projMatrixArr, pm, JNI_ABORT);
        env->ReleaseFloatArrayElements(outScreenCoordsArr, outCoords, 0);
        return JNI_FALSE;
    }

    // Map NDC (-1 to 1) to Screen Coordinates (0 to Width, 0 to Height)
    // Note: In screen space, Y points downwards
    float screenX = (ndcX + 1.0f) * 0.5f * (float)screenWidth;
    float screenY = (1.0f - ndcY) * 0.5f * (float)screenHeight;

    outCoords[0] = screenX;
    outCoords[1] = screenY;
    outCoords[2] = clipW; // distance/depth

    env->ReleaseFloatArrayElements(viewMatrixArr, vm, JNI_ABORT);
    env->ReleaseFloatArrayElements(projMatrixArr, pm, JNI_ABORT);
    env->ReleaseFloatArrayElements(outScreenCoordsArr, outCoords, 0);
    return JNI_TRUE;
}

}
