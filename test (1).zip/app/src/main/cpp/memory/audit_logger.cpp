#include "audit_logger.h"
#include <android/log.h>
#include <ctime>

#define LOG_TAG "AuditLogger"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static std::mutex s_auditLogMutex;
static std::string s_auditLogPath = "";

bool AuditLogger::init(const std::string& filesDirPath) {
    std::lock_guard<std::mutex> lock(s_auditLogMutex);
    if (filesDirPath.empty()) return false;
    s_auditLogPath = filesDirPath + "/MemoryLab_Audit.txt";

    FILE* fp = fopen(s_auditLogPath.c_str(), "a");
    if (fp) {
        time_t now = time(nullptr);
        char timeBuf[64];
        strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S", localtime(&now));
        fprintf(fp, "\n[%s] [INIT] Native Audit Logger Initialized at %s\n", timeBuf, s_auditLogPath.c_str());
        fclose(fp);
    }
    LOGI("[Audit] Initialized audit log at: %s", s_auditLogPath.c_str());
    return true;
}

void AuditLogger::writeLog(const char* levelTag, const char* fmt, ...) {
    char buffer[1024];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    LOGI("[%s] %s", levelTag ? levelTag : "INFO", buffer);
    std::lock_guard<std::mutex> lock(s_auditLogMutex);
    if (s_auditLogPath.empty()) return;

    FILE* fp = fopen(s_auditLogPath.c_str(), "a");
    if (!fp) return;
    time_t now = time(nullptr);
    char timeBuf[32];
    strftime(timeBuf, sizeof(timeBuf), "%H:%M:%S", localtime(&now));
    fprintf(fp, "[%s] [%s] %s\n", timeBuf, levelTag ? levelTag : "INFO", buffer);
    fclose(fp);
}
