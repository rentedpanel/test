#ifndef AUDIT_LOGGER_H
#define AUDIT_LOGGER_H

#include <string>
#include <mutex>
#include <cstdio>
#include <cstdarg>

class AuditLogger {
public:
    static bool init(const std::string& filesDirPath);
    static void writeLog(const char* levelTag, const char* fmt, ...);
};

#endif // AUDIT_LOGGER_H
