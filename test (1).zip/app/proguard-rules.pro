# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in C:\Users\...\Android\Sdk/tools/proguard/proguard-android.txt

-keep class com.memorylab.mods.NativeMemory { *; }
-keep class com.memorylab.mods.NativeProjection { *; }
-keep class com.memorylab.mods.NativeSimulationEngine { *; }
-keep class com.memorylab.mods.NativeRootDiagnostic { *; }

# Keep all JNI native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep Compose models and data classes
-keep class com.memorylab.mods.ArenaEntity { *; }
-keep class com.memorylab.mods.CameraData { *; }
-keep class com.memorylab.mods.ScreenPoint { *; }
-keep class com.memorylab.mods.ScreenBox { *; }
-keep class com.memorylab.mods.Vec3 { *; }
-keep class com.memorylab.mods.Mat4 { *; }
-keep class com.memorylab.mods.EspSettings { *; }
