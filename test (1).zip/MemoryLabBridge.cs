using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ============================================================================
///                     MEMORYLAB PRO - UNITY DATA BRIDGE
/// ============================================================================
/// 
/// Attach this script to any active GameObject in your Unity scene (e.g., GameManager).
/// It captures live entity coordinates, 16-joint bone skeletons, and camera matrices,
/// then broadcasts them via Android IPC Intent to MemoryLab Pro for real-time ESP overlay.
/// 
/// Target Android Intent Actions:
/// - "com.memorylab.ACTION_SIMULATION_DATA"
/// - "<PackageName>.ACTION_SIMULATION_DATA"
/// </summary>
public class MemoryLabBridge : MonoBehaviour
{
    [Header("Broadcast Settings")]
    [Tooltip("Target package action or com.memorylab universal action")]
    public string intentAction = "com.memorylab.ACTION_SIMULATION_DATA";
    
    [Tooltip("Target broadcast rate in frames per second")]
    [Range(15, 120)]
    public int broadcastFps = 60;

    [Header("Entity Filtering")]
    [Tooltip("GameObject tag to identify players/enemies")]
    public string entityTag = "Player";
    
    [Tooltip("Maximum detection distance in game units")]
    public float maxDetectionDistance = 250f;

    // Stride constants matching MemoryLab Pro C++ memory_offsets.h
    private const int BASIC_STRIDE_FLOATS = 10;
    private const int SKELETON_JOINTS_COUNT = 16;
    private const int TOTAL_ENTITY_STRIDE = BASIC_STRIDE_FLOATS + (SKELETON_JOINTS_COUNT * 3); // 58 floats

    private float _timer = 0f;
    private float _interval = 0.0166f;

#if UNITY_ANDROID && !UNITY_EDITOR
    private AndroidJavaObject _currentActivity;
    private AndroidJavaClass _unityPlayer;
#endif

    private void Awake()
    {
        _interval = 1f / broadcastFps;
#if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            _unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            _currentActivity = _unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            Debug.Log("[MemoryLabBridge] Android JNI initialized successfully.");
        }
        catch (Exception ex)
        {
            Debug.LogError("[MemoryLabBridge] Failed to get Android activity: " + ex.Message);
        }
#endif
    }

    private void OnValidate()
    {
        _interval = 1f / Mathf.Max(1, broadcastFps);
    }

    private void LateUpdate()
    {
        _timer += Time.unscaledDeltaTime;
        if (_timer < _interval) return;
        _timer = 0f;

        Camera mainCam = Camera.main;
        if (mainCam == null) return;

        // 1. Gather all active entities
        GameObject[] taggedEntities = GameObject.FindGameObjectsWithTag(entityTag);
        if (taggedEntities == null || taggedEntities.Length == 0) return;

        Vector3 camPos = mainCam.transform.position;
        List<float> entityDataList = new List<float>(taggedEntities.Length * TOTAL_ENTITY_STRIDE);
        int validCount = 0;

        for (int i = 0; i < taggedEntities.Length; i++)
        {
            GameObject obj = taggedEntities[i];
            if (obj == null || !obj.activeInHierarchy) continue;

            Vector3 worldPos = obj.transform.position;
            float dist = Vector3.Distance(camPos, worldPos);
            if (dist > maxDetectionDistance) continue;

            // Health & Team detection
            float health = 100f;
            float maxHealth = 100f;
            int team = 1; // 0 = Alpha (Friendly), 1 = Bravo (Enemy)
            bool isVisible = true;

            // Attempt to retrieve Animator for 3D Bone Skeleton
            Animator anim = obj.GetComponentInChildren<Animator>();
            Vector3 headPos = (anim != null && anim.isHuman) 
                ? anim.GetBoneTransform(HumanBodyBones.Head)?.position ?? (worldPos + Vector3.up * 1.8f)
                : (worldPos + Vector3.up * 1.8f);
            Vector3 footPos = worldPos;

            // --- 1. Basic entity attributes (10 floats) ---
            int id = obj.GetInstanceID();
            entityDataList.Add((float)id);
            entityDataList.Add(worldPos.x);
            entityDataList.Add(worldPos.y);
            entityDataList.Add(worldPos.z);
            entityDataList.Add(headPos.y);
            entityDataList.Add(footPos.y);
            entityDataList.Add(health);
            entityDataList.Add(maxHealth);
            entityDataList.Add((float)team);
            entityDataList.Add(isVisible ? 1f : 0f);

            // --- 2. 16 Humanoid Bone Joints (48 floats) ---
            AppendSkeletonJoints(anim, worldPos, headPos, entityDataList);

            validCount++;
        }

        if (validCount == 0) return;

        // 2. Prepare Camera Data (Matrices + Viewport)
        // Stride: 3 (Pos) + 3 (Yaw, Pitch, FOV) + 2 (Viewport W, H) + 16 (ViewMatrix) + 16 (ProjMatrix) = 40 floats
        float[] cameraData = new float[40];
        cameraData[0] = camPos.x;
        cameraData[1] = camPos.y;
        cameraData[2] = camPos.z;
        cameraData[3] = mainCam.transform.eulerAngles.y; // Yaw
        cameraData[4] = mainCam.transform.eulerAngles.x; // Pitch
        cameraData[5] = mainCam.fieldOfView;
        cameraData[6] = (float)Screen.width;
        cameraData[7] = (float)Screen.height;

        Matrix4x4 viewMat = mainCam.worldToCameraMatrix;
        Matrix4x4 projMat = mainCam.projectionMatrix;

        for (int m = 0; m < 16; m++)
        {
            cameraData[8 + m] = viewMat[m];
            cameraData[24 + m] = projMat[m];
        }

        // 3. Broadcast to MemoryLab Pro via Android Intent
        BroadcastToMemoryLab(validCount, entityDataList.ToArray(), cameraData);
    }

    private void AppendSkeletonJoints(Animator anim, Vector3 root, Vector3 head, List<float> list)
    {
        if (anim != null && anim.isHuman)
        {
            HumanBodyBones[] bones = new HumanBodyBones[]
            {
                HumanBodyBones.Head,           // 0
                HumanBodyBones.Neck,           // 1
                HumanBodyBones.Spine,          // 2
                HumanBodyBones.Hips,           // 3 (Pelvis)
                HumanBodyBones.LeftUpperArm,   // 4 (Shoulder)
                HumanBodyBones.RightUpperArm,  // 5 (Shoulder)
                HumanBodyBones.LeftLowerArm,   // 6 (Elbow)
                HumanBodyBones.RightLowerArm,  // 7 (Elbow)
                HumanBodyBones.LeftHand,       // 8
                HumanBodyBones.RightHand,      // 9
                HumanBodyBones.LeftUpperLeg,   // 10 (Hip)
                HumanBodyBones.RightUpperLeg,  // 11 (Hip)
                HumanBodyBones.LeftLowerLeg,   // 12 (Knee)
                HumanBodyBones.RightLowerLeg,  // 13 (Knee)
                HumanBodyBones.LeftFoot,       // 14
                HumanBodyBones.RightFoot       // 15
            };

            foreach (var b in bones)
            {
                Transform t = anim.GetBoneTransform(b);
                Vector3 p = (t != null) ? t.position : root;
                list.Add(p.x);
                list.Add(p.y);
                list.Add(p.z);
            }
        }
        else
        {
            float neckY = head.y - 0.25f;
            float spineY = head.y - 0.55f;
            float pelvisY = root.y + 0.95f;

            AddVec(list, head);
            AddVec(list, new Vector3(root.x, neckY, root.z));
            AddVec(list, new Vector3(root.x, spineY, root.z));
            AddVec(list, new Vector3(root.x, pelvisY, root.z));
            
            AddVec(list, new Vector3(root.x - 0.35f, neckY, root.z));
            AddVec(list, new Vector3(root.x + 0.35f, neckY, root.z));
            AddVec(list, new Vector3(root.x - 0.35f, neckY - 0.35f, root.z));
            AddVec(list, new Vector3(root.x + 0.35f, neckY - 0.35f, root.z));
            AddVec(list, new Vector3(root.x - 0.35f, neckY - 0.65f, root.z));
            AddVec(list, new Vector3(root.x + 0.35f, neckY - 0.65f, root.z));
            
            AddVec(list, new Vector3(root.x - 0.20f, pelvisY, root.z));
            AddVec(list, new Vector3(root.x + 0.20f, pelvisY, root.z));
            AddVec(list, new Vector3(root.x - 0.20f, pelvisY - 0.45f, root.z));
            AddVec(list, new Vector3(root.x + 0.20f, pelvisY - 0.45f, root.z));
            AddVec(list, new Vector3(root.x - 0.20f, root.y, root.z));
            AddVec(list, new Vector3(root.x + 0.20f, root.y, root.z));
        }
    }

    private void AddVec(List<float> list, Vector3 v)
    {
        list.Add(v.x);
        list.Add(v.y);
        list.Add(v.z);
    }

    private void BroadcastToMemoryLab(int entityCount, float[] entityData, float[] cameraData)
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        if (_currentActivity == null) return;

        try
        {
            using (AndroidJavaObject intent = new AndroidJavaObject("android.content.Intent", intentAction))
            {
                intent.Call<AndroidJavaObject>("putExtra", "ENTITY_COUNT", entityCount);
                intent.Call<AndroidJavaObject>("putExtra", "ENTITY_DATA", entityData);
                intent.Call<AndroidJavaObject>("putExtra", "CAMERA_DATA", cameraData);
                intent.Call<AndroidJavaObject>("putExtra", "TIMESTAMP", DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
                _currentActivity.Call("sendBroadcast", intent);
            }
        }
        catch (Exception ex)
        {
            Debug.LogWarning("[MemoryLabBridge] Broadcast error: " + ex.Message);
        }
#endif
    }
}
