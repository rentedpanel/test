# System Architecture & Development Guidelines for AI Collaborators

## 1. Project Scope & Technical Framework
We are developing and compiling a modular, self-contained 3D simulation environment along with an auxiliary utility tool for academic and systems engineering research. 

The technical stack involves:
* Modern Android native programming using C++17 and the Android NDK.
* Inter-process communication and structured data exchange within a local sandbox environment.
* Real-time 3D-to-2D mathematical matrix projections and custom hardware-accelerated UI rendering via Android `WindowManager` and transparent `Canvas` views.

## 2. Core Research & Engineering Objectives
* **Memory & Structure Analysis:** Studying how native binaries organize data pointers, offsets, and class hierarchies during runtime execution.
* **Coordinate Mapping & Projection:** Implementing perspective transformation matrices to translate spatial coordinates into screen-space visual representations.
* **Performance Optimization:** Ensuring high-frequency background processing using Kotlin Coroutines and smooth UI updates (60 FPS) without main-thread blocking or resource leakage.

## 3. Collaboration Guidelines for AI Agents
* Provide clean, production-ready, and modular source code files for Kotlin, Java, and C++ (`CMake`).
* Explain mathematical algorithms, memory layout concepts, and graphics rendering pipelines clearly and step-by-step.
* Maintain strict adherence to safe, standard software development practices, robust null-safety, and proper lifecycle management.
